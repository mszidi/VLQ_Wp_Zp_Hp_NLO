# This file was automatically created by FeynRules 2.3.47
# Mathematica version: 9.0 for Linux x86 (64-bit) (November 20, 2012)
# Date: Tue 30 May 2023 19:46:05



from object_library import all_parameters, Parameter


from function_library import complexconjugate, re, im, csc, sec, acsc, asec, cot

# This is a default parameter object representing 0.
ZERO = Parameter(name = 'ZERO',
                 nature = 'internal',
                 type = 'real',
                 value = '0.0',
                 texname = '0')

# This is a default parameter object representing the renormalization scale (MU_R).
MU_R = Parameter(name = 'MU_R',
                 nature = 'external',
                 type = 'real',
                 value = 91.188,
                 texname = '\\text{\\mu_r}',
                 lhablock = 'LOOP',
                 lhacode = [1])

# User-defined parameters.
kpBHL1 = Parameter(name = 'kpBHL1',
                   nature = 'external',
                   type = 'real',
                   value = 0.206506,
                   texname = '\\text{kpBHL1}',
                   lhablock = 'KPBHL',
                   lhacode = [ 1 ])

kpBHL2 = Parameter(name = 'kpBHL2',
                   nature = 'external',
                   type = 'real',
                   value = 0.206507,
                   texname = '\\text{kpBHL2}',
                   lhablock = 'KPBHL',
                   lhacode = [ 2 ])

kpBHL3 = Parameter(name = 'kpBHL3',
                   nature = 'external',
                   type = 'real',
                   value = 0.206508,
                   texname = '\\text{kpBHL3}',
                   lhablock = 'KPBHL',
                   lhacode = [ 3 ])

kpBHpL1 = Parameter(name = 'kpBHpL1',
                    nature = 'external',
                    type = 'real',
                    value = 0.765435,
                    texname = '\\text{kpBHpL1}',
                    lhablock = 'KPBHPL',
                    lhacode = [ 1 ])

kpBHpL2 = Parameter(name = 'kpBHpL2',
                    nature = 'external',
                    type = 'real',
                    value = 0.765436,
                    texname = '\\text{kpBHpL2}',
                    lhablock = 'KPBHPL',
                    lhacode = [ 2 ])

kpBHpL3 = Parameter(name = 'kpBHpL3',
                    nature = 'external',
                    type = 'real',
                    value = 0.765437,
                    texname = '\\text{kpBHpL3}',
                    lhablock = 'KPBHPL',
                    lhacode = [ 3 ])

kpBWL1 = Parameter(name = 'kpBWL1',
                   nature = 'external',
                   type = 'real',
                   value = 0.0500042,
                   texname = '\\text{kpBWL1}',
                   lhablock = 'KPBWL',
                   lhacode = [ 1 ])

kpBWL2 = Parameter(name = 'kpBWL2',
                   nature = 'external',
                   type = 'real',
                   value = 0.0500043,
                   texname = '\\text{kpBWL2}',
                   lhablock = 'KPBWL',
                   lhacode = [ 2 ])

kpBWL3 = Parameter(name = 'kpBWL3',
                   nature = 'external',
                   type = 'real',
                   value = 0.0500044,
                   texname = '\\text{kpBWL3}',
                   lhablock = 'KPBWL',
                   lhacode = [ 3 ])

kpBWpL1 = Parameter(name = 'kpBWpL1',
                    nature = 'external',
                    type = 'real',
                    value = 0.91559,
                    texname = '\\text{kpBWpL1}',
                    lhablock = 'KPBWPL',
                    lhacode = [ 1 ])

kpBWpL2 = Parameter(name = 'kpBWpL2',
                    nature = 'external',
                    type = 'real',
                    value = 0.915591,
                    texname = '\\text{kpBWpL2}',
                    lhablock = 'KPBWPL',
                    lhacode = [ 2 ])

kpBWpL3 = Parameter(name = 'kpBWpL3',
                    nature = 'external',
                    type = 'real',
                    value = 0.915592,
                    texname = '\\text{kpBWpL3}',
                    lhablock = 'KPBWPL',
                    lhacode = [ 3 ])

kpBZL1 = Parameter(name = 'kpBZL1',
                   nature = 'external',
                   type = 'real',
                   value = 0.0523313,
                   texname = '\\text{kpBZL1}',
                   lhablock = 'KPBZL',
                   lhacode = [ 1 ])

kpBZL2 = Parameter(name = 'kpBZL2',
                   nature = 'external',
                   type = 'real',
                   value = 0.0523312,
                   texname = '\\text{kpBZL2}',
                   lhablock = 'KPBZL',
                   lhacode = [ 2 ])

kpBZL3 = Parameter(name = 'kpBZL3',
                   nature = 'external',
                   type = 'real',
                   value = 0.0523311,
                   texname = '\\text{kpBZL3}',
                   lhablock = 'KPBZL',
                   lhacode = [ 3 ])

kpBZpL1 = Parameter(name = 'kpBZpL1',
                    nature = 'external',
                    type = 'real',
                    value = 1.1683,
                    texname = '\\text{kpBZpL1}',
                    lhablock = 'KPBZPL',
                    lhacode = [ 1 ])

kpBZpL2 = Parameter(name = 'kpBZpL2',
                    nature = 'external',
                    type = 'real',
                    value = 1.1682,
                    texname = '\\text{kpBZpL2}',
                    lhablock = 'KPBZPL',
                    lhacode = [ 2 ])

kpBZpL3 = Parameter(name = 'kpBZpL3',
                    nature = 'external',
                    type = 'real',
                    value = 1.1681,
                    texname = '\\text{kpBZpL3}',
                    lhablock = 'KPBZPL',
                    lhacode = [ 3 ])

kpTHL1 = Parameter(name = 'kpTHL1',
                   nature = 'external',
                   type = 'real',
                   value = 0.206506,
                   texname = '\\text{kpTHL1}',
                   lhablock = 'KPTHL',
                   lhacode = [ 1 ])

kpTHL2 = Parameter(name = 'kpTHL2',
                   nature = 'external',
                   type = 'real',
                   value = 0.206507,
                   texname = '\\text{kpTHL2}',
                   lhablock = 'KPTHL',
                   lhacode = [ 2 ])

kpTHL3 = Parameter(name = 'kpTHL3',
                   nature = 'external',
                   type = 'real',
                   value = 0.206508,
                   texname = '\\text{kpTHL3}',
                   lhablock = 'KPTHL',
                   lhacode = [ 3 ])

kpTHpL1 = Parameter(name = 'kpTHpL1',
                    nature = 'external',
                    type = 'real',
                    value = 0.765435,
                    texname = '\\text{kpTHpL1}',
                    lhablock = 'KPTHPL',
                    lhacode = [ 1 ])

kpTHpL2 = Parameter(name = 'kpTHpL2',
                    nature = 'external',
                    type = 'real',
                    value = 0.765436,
                    texname = '\\text{kpTHpL2}',
                    lhablock = 'KPTHPL',
                    lhacode = [ 2 ])

kpTHpL3 = Parameter(name = 'kpTHpL3',
                    nature = 'external',
                    type = 'real',
                    value = 0.765437,
                    texname = '\\text{kpTHpL3}',
                    lhablock = 'KPTHPL',
                    lhacode = [ 3 ])

kpTHpR1 = Parameter(name = 'kpTHpR1',
                    nature = 'external',
                    type = 'real',
                    value = 1,
                    texname = '\\text{kpTHpR1}',
                    lhablock = 'KPTHPR',
                    lhacode = [ 1 ])

kpTHpR2 = Parameter(name = 'kpTHpR2',
                    nature = 'external',
                    type = 'real',
                    value = 1,
                    texname = '\\text{kpTHpR2}',
                    lhablock = 'KPTHPR',
                    lhacode = [ 2 ])

kpTHpR3 = Parameter(name = 'kpTHpR3',
                    nature = 'external',
                    type = 'real',
                    value = 1,
                    texname = '\\text{kpTHpR3}',
                    lhablock = 'KPTHPR',
                    lhacode = [ 3 ])

kpTHR1 = Parameter(name = 'kpTHR1',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{kpTHR1}',
                   lhablock = 'KPTHR',
                   lhacode = [ 1 ])

kpTHR2 = Parameter(name = 'kpTHR2',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{kpTHR2}',
                   lhablock = 'KPTHR',
                   lhacode = [ 2 ])

kpTHR3 = Parameter(name = 'kpTHR3',
                   nature = 'external',
                   type = 'real',
                   value = 0.0356763,
                   texname = '\\text{kpTHR3}',
                   lhablock = 'KPTHR',
                   lhacode = [ 3 ])

kpTWL1 = Parameter(name = 'kpTWL1',
                   nature = 'external',
                   type = 'real',
                   value = 0.0500042,
                   texname = '\\text{kpTWL1}',
                   lhablock = 'KPTWL',
                   lhacode = [ 1 ])

kpTWL2 = Parameter(name = 'kpTWL2',
                   nature = 'external',
                   type = 'real',
                   value = 0.0500043,
                   texname = '\\text{kpTWL2}',
                   lhablock = 'KPTWL',
                   lhacode = [ 2 ])

kpTWL3 = Parameter(name = 'kpTWL3',
                   nature = 'external',
                   type = 'real',
                   value = 0.0500044,
                   texname = '\\text{kpTWL3}',
                   lhablock = 'KPTWL',
                   lhacode = [ 3 ])

kpTWpL1 = Parameter(name = 'kpTWpL1',
                    nature = 'external',
                    type = 'real',
                    value = 0.91559,
                    texname = '\\text{kpTWpL1}',
                    lhablock = 'KPTWPL',
                    lhacode = [ 1 ])

kpTWpL2 = Parameter(name = 'kpTWpL2',
                    nature = 'external',
                    type = 'real',
                    value = 0.915591,
                    texname = '\\text{kpTWpL2}',
                    lhablock = 'KPTWPL',
                    lhacode = [ 2 ])

kpTWpL3 = Parameter(name = 'kpTWpL3',
                    nature = 'external',
                    type = 'real',
                    value = 0.915592,
                    texname = '\\text{kpTWpL3}',
                    lhablock = 'KPTWPL',
                    lhacode = [ 3 ])

kpTZL1 = Parameter(name = 'kpTZL1',
                   nature = 'external',
                   type = 'real',
                   value = 0.0523313,
                   texname = '\\text{kpTZL1}',
                   lhablock = 'KPTZL',
                   lhacode = [ 1 ])

kpTZL2 = Parameter(name = 'kpTZL2',
                   nature = 'external',
                   type = 'real',
                   value = 0.0523312,
                   texname = '\\text{kpTZL2}',
                   lhablock = 'KPTZL',
                   lhacode = [ 2 ])

kpTZL3 = Parameter(name = 'kpTZL3',
                   nature = 'external',
                   type = 'real',
                   value = 0.0523311,
                   texname = '\\text{kpTZL3}',
                   lhablock = 'KPTZL',
                   lhacode = [ 3 ])

kpTZpL1 = Parameter(name = 'kpTZpL1',
                    nature = 'external',
                    type = 'real',
                    value = 1.1683,
                    texname = '\\text{kpTZpL1}',
                    lhablock = 'KPTZPL',
                    lhacode = [ 1 ])

kpTZpL2 = Parameter(name = 'kpTZpL2',
                    nature = 'external',
                    type = 'real',
                    value = 1.1682,
                    texname = '\\text{kpTZpL2}',
                    lhablock = 'KPTZPL',
                    lhacode = [ 2 ])

kpTZpL3 = Parameter(name = 'kpTZpL3',
                    nature = 'external',
                    type = 'real',
                    value = 1.1681,
                    texname = '\\text{kpTZpL3}',
                    lhablock = 'KPTZPL',
                    lhacode = [ 3 ])

xiZp = Parameter(name = 'xiZp',
                 nature = 'external',
                 type = 'real',
                 value = 1.,
                 texname = '\\text{xiZp}',
                 lhablock = 'NFACTORBP',
                 lhacode = [ 1 ])

thZp = Parameter(name = 'thZp',
                 nature = 'external',
                 type = 'real',
                 value = 1.,
                 texname = '\\text{thZp}',
                 lhablock = 'NFACTORBP',
                 lhacode = [ 2 ])

xiWp = Parameter(name = 'xiWp',
                 nature = 'external',
                 type = 'real',
                 value = 1.,
                 texname = '\\text{xiWp}',
                 lhablock = 'NFACTORBP',
                 lhacode = [ 3 ])

thWp = Parameter(name = 'thWp',
                 nature = 'external',
                 type = 'real',
                 value = 1.,
                 texname = '\\text{thWp}',
                 lhablock = 'NFACTORBP',
                 lhacode = [ 4 ])

xiHp = Parameter(name = 'xiHp',
                 nature = 'external',
                 type = 'real',
                 value = 0.701649,
                 texname = '\\text{xiHp}',
                 lhablock = 'NFACTORBP',
                 lhacode = [ 5 ])

aEWM1 = Parameter(name = 'aEWM1',
                  nature = 'external',
                  type = 'real',
                  value = 127.9,
                  texname = '\\text{aEWM1}',
                  lhablock = 'SMINPUTS',
                  lhacode = [ 1 ])

Gf = Parameter(name = 'Gf',
               nature = 'external',
               type = 'real',
               value = 0.0000116637,
               texname = 'G_f',
               lhablock = 'SMINPUTS',
               lhacode = [ 2 ])

aS = Parameter(name = 'aS',
               nature = 'external',
               type = 'real',
               value = 0.1184,
               texname = '\\alpha _s',
               lhablock = 'SMINPUTS',
               lhacode = [ 3 ])

ymb = Parameter(name = 'ymb',
                nature = 'external',
                type = 'real',
                value = 4.7,
                texname = '\\text{ymb}',
                lhablock = 'YUKAWA',
                lhacode = [ 5 ])

ymt = Parameter(name = 'ymt',
                nature = 'external',
                type = 'real',
                value = 172.76,
                texname = '\\text{ymt}',
                lhablock = 'YUKAWA',
                lhacode = [ 6 ])

MZ = Parameter(name = 'MZ',
               nature = 'external',
               type = 'real',
               value = 91.1876,
               texname = '\\text{MZ}',
               lhablock = 'MASS',
               lhacode = [ 23 ])

MW = Parameter(name = 'MW',
               nature = 'external',
               type = 'real',
               value = 80.379,
               texname = '\\text{MW}',
               lhablock = 'MASS',
               lhacode = [ 24 ])

MT = Parameter(name = 'MT',
               nature = 'external',
               type = 'real',
               value = 172.76,
               texname = '\\text{MT}',
               lhablock = 'MASS',
               lhacode = [ 6 ])

MB = Parameter(name = 'MB',
               nature = 'external',
               type = 'real',
               value = 4.7,
               texname = '\\text{MB}',
               lhablock = 'MASS',
               lhacode = [ 5 ])

MH = Parameter(name = 'MH',
               nature = 'external',
               type = 'real',
               value = 125.25,
               texname = '\\text{MH}',
               lhablock = 'MASS',
               lhacode = [ 25 ])

MZp = Parameter(name = 'MZp',
                nature = 'external',
                type = 'real',
                value = 800.,
                texname = '\\text{MZp}',
                lhablock = 'MASS',
                lhacode = [ 100023 ])

MWp = Parameter(name = 'MWp',
                nature = 'external',
                type = 'real',
                value = 800.,
                texname = '\\text{MWp}',
                lhablock = 'MASS',
                lhacode = [ 100024 ])

MHp = Parameter(name = 'MHp',
                nature = 'external',
                type = 'real',
                value = 800.,
                texname = '\\text{MHp}',
                lhablock = 'MASS',
                lhacode = [ 100025 ])

MTP = Parameter(name = 'MTP',
                nature = 'external',
                type = 'real',
                value = 1000.,
                texname = '\\text{MTP}',
                lhablock = 'MASS',
                lhacode = [ 100006 ])

MBP = Parameter(name = 'MBP',
                nature = 'external',
                type = 'real',
                value = 1000.,
                texname = '\\text{MBP}',
                lhablock = 'MASS',
                lhacode = [ 100005 ])

WZ = Parameter(name = 'WZ',
               nature = 'external',
               type = 'real',
               value = 2.4952,
               texname = '\\text{WZ}',
               lhablock = 'DECAY',
               lhacode = [ 23 ])

WW = Parameter(name = 'WW',
               nature = 'external',
               type = 'real',
               value = 2.085,
               texname = '\\text{WW}',
               lhablock = 'DECAY',
               lhacode = [ 24 ])

WT = Parameter(name = 'WT',
               nature = 'external',
               type = 'real',
               value = 1.50833649,
               texname = '\\text{WT}',
               lhablock = 'DECAY',
               lhacode = [ 6 ])

WH = Parameter(name = 'WH',
               nature = 'external',
               type = 'real',
               value = 0.00407,
               texname = '\\text{WH}',
               lhablock = 'DECAY',
               lhacode = [ 25 ])

WZp = Parameter(name = 'WZp',
                nature = 'external',
                type = 'real',
                value = 23.10052,
                texname = '\\text{WZp}',
                lhablock = 'DECAY',
                lhacode = [ 100023 ])

WWp = Parameter(name = 'WWp',
                nature = 'external',
                type = 'real',
                value = 26.2937,
                texname = '\\text{WWp}',
                lhablock = 'DECAY',
                lhacode = [ 100024 ])

WHp = Parameter(name = 'WHp',
                nature = 'external',
                type = 'real',
                value = 56.45662,
                texname = '\\text{WHp}',
                lhablock = 'DECAY',
                lhacode = [ 100025 ])

WTP = Parameter(name = 'WTP',
                nature = 'external',
                type = 'real',
                value = 3.46865,
                texname = '\\text{WTP}',
                lhablock = 'DECAY',
                lhacode = [ 100006 ])

WBP = Parameter(name = 'WBP',
                nature = 'external',
                type = 'real',
                value = 3.46865,
                texname = '\\text{WBP}',
                lhablock = 'DECAY',
                lhacode = [ 100005 ])

gAd = Parameter(name = 'gAd',
                nature = 'internal',
                type = 'real',
                value = '0.25',
                texname = '\\text{gAd}')

gAl = Parameter(name = 'gAl',
                nature = 'internal',
                type = 'real',
                value = '0.25',
                texname = '\\text{gAl}')

gAnl = Parameter(name = 'gAnl',
                 nature = 'internal',
                 type = 'real',
                 value = '-0.25',
                 texname = '\\text{gAnl}')

gAu = Parameter(name = 'gAu',
                nature = 'internal',
                type = 'real',
                value = '-0.25',
                texname = '\\text{gAu}')

gVnl = Parameter(name = 'gVnl',
                 nature = 'internal',
                 type = 'real',
                 value = '0.25',
                 texname = '\\text{gVnl}')

sw2 = Parameter(name = 'sw2',
                nature = 'internal',
                type = 'real',
                value = '1 - MW**2/MZ**2',
                texname = '\\text{sw2}')

aEW = Parameter(name = 'aEW',
                nature = 'internal',
                type = 'real',
                value = '1/aEWM1',
                texname = '\\alpha _{\\text{EW}}')

G = Parameter(name = 'G',
              nature = 'internal',
              type = 'real',
              value = '2*cmath.sqrt(aS)*cmath.sqrt(cmath.pi)',
              texname = 'G')

cw = Parameter(name = 'cw',
               nature = 'internal',
               type = 'real',
               value = 'cmath.sqrt(1 - sw2)',
               texname = 'c_w')

gVd = Parameter(name = 'gVd',
                nature = 'internal',
                type = 'real',
                value = '-0.25 + sw2/3.',
                texname = '\\text{gVd}')

gVl = Parameter(name = 'gVl',
                nature = 'internal',
                type = 'real',
                value = '-0.25 + sw2',
                texname = '\\text{gVl}')

gVu = Parameter(name = 'gVu',
                nature = 'internal',
                type = 'real',
                value = '0.25 - (2*sw2)/3.',
                texname = '\\text{gVu}')

sw = Parameter(name = 'sw',
               nature = 'internal',
               type = 'real',
               value = 'cmath.sqrt(sw2)',
               texname = 's_w')

ee = Parameter(name = 'ee',
               nature = 'internal',
               type = 'real',
               value = '2*cmath.sqrt(aEW)*cmath.sqrt(cmath.pi)',
               texname = 'e')

g1 = Parameter(name = 'g1',
               nature = 'internal',
               type = 'real',
               value = 'ee/cw',
               texname = 'g_1')

gw = Parameter(name = 'gw',
               nature = 'internal',
               type = 'real',
               value = 'ee/sw',
               texname = 'g_w')

vev = Parameter(name = 'vev',
                nature = 'internal',
                type = 'real',
                value = '(2*MW*sw)/ee',
                texname = '\\text{vev}')

lam = Parameter(name = 'lam',
                nature = 'internal',
                type = 'real',
                value = 'MH**2/(2.*vev**2)',
                texname = '\\text{lam}')

yb = Parameter(name = 'yb',
               nature = 'internal',
               type = 'real',
               value = '(ymb*cmath.sqrt(2))/vev',
               texname = '\\text{yb}')

yt = Parameter(name = 'yt',
               nature = 'internal',
               type = 'real',
               value = '(ymt*cmath.sqrt(2))/vev',
               texname = '\\text{yt}')

muH = Parameter(name = 'muH',
                nature = 'internal',
                type = 'real',
                value = 'cmath.sqrt(lam*vev**2)',
                texname = '\\mu')

