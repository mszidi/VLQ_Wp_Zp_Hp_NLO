# This file was automatically created by FeynRules 2.3.47
# Mathematica version: 9.0 for Linux x86 (64-bit) (November 20, 2012)
# Date: Sun 20 Jul 2025 09:54:34


from object_library import all_couplings, Coupling

from function_library import complexconjugate, re, im, csc, sec, acsc, asec, cot



R2GC_100_1 = Coupling(name = 'R2GC_100_1',
                      value = '(cw*ee**2*complex(0,1)*G**2)/(288.*cmath.pi**2*sw) - (ee**2*complex(0,1)*G**2*sw)/(864.*cw*cmath.pi**2)',
                      order = {'QCD':2,'QED':2})

R2GC_100_2 = Coupling(name = 'R2GC_100_2',
                      value = '(cw*ee**2*complex(0,1)*G**2)/(144.*cmath.pi**2*sw) - (5*ee**2*complex(0,1)*G**2*sw)/(432.*cw*cmath.pi**2)',
                      order = {'QCD':2,'QED':2})

R2GC_101_3 = Coupling(name = 'R2GC_101_3',
                      value = '-(cw*ee*complex(0,1)*G**3)/(192.*cmath.pi**2*sw) + (ee*complex(0,1)*G**3*sw)/(576.*cw*cmath.pi**2)',
                      order = {'QCD':3,'QED':1})

R2GC_101_4 = Coupling(name = 'R2GC_101_4',
                      value = '(cw*ee*complex(0,1)*G**3)/(192.*cmath.pi**2*sw) - (5*ee*complex(0,1)*G**3*sw)/(576.*cw*cmath.pi**2)',
                      order = {'QCD':3,'QED':1})

R2GC_102_5 = Coupling(name = 'R2GC_102_5',
                      value = '(-3*cw*ee*complex(0,1)*G**3)/(64.*cmath.pi**2*sw) - (3*ee*complex(0,1)*G**3*sw)/(64.*cw*cmath.pi**2)',
                      order = {'QCD':3,'QED':1})

R2GC_102_6 = Coupling(name = 'R2GC_102_6',
                      value = '(3*cw*ee*complex(0,1)*G**3)/(64.*cmath.pi**2*sw) + (3*ee*complex(0,1)*G**3*sw)/(64.*cw*cmath.pi**2)',
                      order = {'QCD':3,'QED':1})

R2GC_103_7 = Coupling(name = 'R2GC_103_7',
                      value = '(ee*complex(0,1)*G**3*gAd*xiZp)/(16.*cw*cmath.pi**2*sw)',
                      order = {'HvB':1,'QCD':3})

R2GC_103_8 = Coupling(name = 'R2GC_103_8',
                      value = '(ee*complex(0,1)*G**3*gAu*xiZp)/(16.*cw*cmath.pi**2*sw)',
                      order = {'HvB':1,'QCD':3})

R2GC_104_9 = Coupling(name = 'R2GC_104_9',
                      value = '-(ee**2*complex(0,1)*G**2*gVd*xiZp)/(72.*cw*cmath.pi**2*sw)',
                      order = {'HvB':1,'QCD':2,'QED':1})

R2GC_104_10 = Coupling(name = 'R2GC_104_10',
                       value = '(ee**2*complex(0,1)*G**2*gVu*xiZp)/(36.*cw*cmath.pi**2*sw)',
                       order = {'HvB':1,'QCD':2,'QED':1})

R2GC_105_11 = Coupling(name = 'R2GC_105_11',
                       value = '(ee*complex(0,1)*G**3*gVd*xiZp)/(48.*cw*cmath.pi**2*sw)',
                       order = {'HvB':1,'QCD':3})

R2GC_105_12 = Coupling(name = 'R2GC_105_12',
                       value = '(ee*complex(0,1)*G**3*gVu*xiZp)/(48.*cw*cmath.pi**2*sw)',
                       order = {'HvB':1,'QCD':3})

R2GC_106_13 = Coupling(name = 'R2GC_106_13',
                       value = '-(cw*ee*complex(0,1)*G**2)/(12.*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*sw)/(36.*cw*cmath.pi**2)',
                       order = {'QCD':2,'QED':1})

R2GC_107_14 = Coupling(name = 'R2GC_107_14',
                       value = '-(ee*complex(0,1)*G**2*gAu*xiZp)/(6.*cw*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*gVu*xiZp)/(6.*cw*cmath.pi**2*sw)',
                       order = {'HvB':1,'QCD':2})

R2GC_108_15 = Coupling(name = 'R2GC_108_15',
                       value = '(ee*complex(0,1)*G**2*gAu*xiZp)/(6.*cw*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*gVu*xiZp)/(6.*cw*cmath.pi**2*sw)',
                       order = {'HvB':1,'QCD':2})

R2GC_109_16 = Coupling(name = 'R2GC_109_16',
                       value = '(cw*ee*complex(0,1)*G**2)/(12.*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*sw)/(36.*cw*cmath.pi**2)',
                       order = {'QCD':2,'QED':1})

R2GC_111_17 = Coupling(name = 'R2GC_111_17',
                       value = '-(ee*complex(0,1)*G**2*gAd*xiZp)/(6.*cw*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*gVd*xiZp)/(6.*cw*cmath.pi**2*sw)',
                       order = {'HvB':1,'QCD':2})

R2GC_112_18 = Coupling(name = 'R2GC_112_18',
                       value = '(ee*complex(0,1)*G**2*gAd*xiZp)/(6.*cw*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*gVd*xiZp)/(6.*cw*cmath.pi**2*sw)',
                       order = {'HvB':1,'QCD':2})

R2GC_113_19 = Coupling(name = 'R2GC_113_19',
                       value = '(ee**2*complex(0,1)*G**2)/(96.*cmath.pi**2*sw**2)',
                       order = {'QCD':2,'QED':2})

R2GC_113_20 = Coupling(name = 'R2GC_113_20',
                       value = '(ee**2*complex(0,1)*G**2*kpTWL3**2)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_113_21 = Coupling(name = 'R2GC_113_21',
                       value = '(ee**2*complex(0,1)*G**2*kpBWL2**2)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_113_22 = Coupling(name = 'R2GC_113_22',
                       value = '(ee**2*complex(0,1)*G**2*kpBWL3**2)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_113_23 = Coupling(name = 'R2GC_113_23',
                       value = '(ee**2*complex(0,1)*G**2*kpBWL1**2)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_113_24 = Coupling(name = 'R2GC_113_24',
                       value = '(ee**2*complex(0,1)*G**2*kpTWL1**2)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_113_25 = Coupling(name = 'R2GC_113_25',
                       value = '(ee**2*complex(0,1)*G**2*kpTWL2**2)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_114_26 = Coupling(name = 'R2GC_114_26',
                       value = '(ee**2*complex(0,1)*G**2*xiWp)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvB':1,'QCD':2,'QED':1})

R2GC_114_27 = Coupling(name = 'R2GC_114_27',
                       value = '(ee**2*complex(0,1)*G**2*kpTWL3*kpTWpL3)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_114_28 = Coupling(name = 'R2GC_114_28',
                       value = '(ee**2*complex(0,1)*G**2*kpBWL2*kpBWpL2)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_114_29 = Coupling(name = 'R2GC_114_29',
                       value = '(ee**2*complex(0,1)*G**2*kpBWL3*kpBWpL3)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_114_30 = Coupling(name = 'R2GC_114_30',
                       value = '(ee**2*complex(0,1)*G**2*kpBWL1*kpBWpL1)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_114_31 = Coupling(name = 'R2GC_114_31',
                       value = '(ee**2*complex(0,1)*G**2*kpTWL1*kpTWpL1)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_114_32 = Coupling(name = 'R2GC_114_32',
                       value = '(ee**2*complex(0,1)*G**2*kpTWL2*kpTWpL2)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_115_33 = Coupling(name = 'R2GC_115_33',
                       value = '(ee**2*complex(0,1)*G**2*xiWp**2)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_115_34 = Coupling(name = 'R2GC_115_34',
                       value = '(ee**2*complex(0,1)*G**2*kpTWpL3**2)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_115_35 = Coupling(name = 'R2GC_115_35',
                       value = '(ee**2*complex(0,1)*G**2*kpBWpL2**2)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_115_36 = Coupling(name = 'R2GC_115_36',
                       value = '(ee**2*complex(0,1)*G**2*kpBWpL3**2)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_115_37 = Coupling(name = 'R2GC_115_37',
                       value = '(ee**2*complex(0,1)*G**2*kpBWpL1**2)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_115_38 = Coupling(name = 'R2GC_115_38',
                       value = '(ee**2*complex(0,1)*G**2*kpTWpL1**2)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_115_39 = Coupling(name = 'R2GC_115_39',
                       value = '(ee**2*complex(0,1)*G**2*kpTWpL2**2)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_119_40 = Coupling(name = 'R2GC_119_40',
                       value = '-(complex(0,1)*G**2*yb**2)/(16.*cmath.pi**2)',
                       order = {'QCD':2,'QED':2})

R2GC_119_41 = Coupling(name = 'R2GC_119_41',
                       value = '-(complex(0,1)*G**2*yt**2)/(16.*cmath.pi**2)',
                       order = {'QCD':2,'QED':2})

R2GC_119_42 = Coupling(name = 'R2GC_119_42',
                       value = '-(complex(0,1)*G**2*kpBHL3**2)/(8.*cmath.pi**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_119_43 = Coupling(name = 'R2GC_119_43',
                       value = '-(complex(0,1)*G**2*kpBHL1**2)/(8.*cmath.pi**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_119_44 = Coupling(name = 'R2GC_119_44',
                       value = '-(complex(0,1)*G**2*kpBHL2**2)/(8.*cmath.pi**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_119_45 = Coupling(name = 'R2GC_119_45',
                       value = '-(complex(0,1)*G**2*kpTHL2**2)/(8.*cmath.pi**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_119_46 = Coupling(name = 'R2GC_119_46',
                       value = '-(complex(0,1)*G**2*kpTHL3**2)/(8.*cmath.pi**2) - (complex(0,1)*G**2*kpTHR3**2)/(8.*cmath.pi**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_119_47 = Coupling(name = 'R2GC_119_47',
                       value = '-(complex(0,1)*G**2*kpTHL1**2)/(8.*cmath.pi**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_120_48 = Coupling(name = 'R2GC_120_48',
                       value = '-(complex(0,1)*G**2*xiHp*yt)/(8.*cmath.pi**2*cmath.sqrt(2))',
                       order = {'HvB':1,'QCD':2,'QED':1})

R2GC_120_49 = Coupling(name = 'R2GC_120_49',
                       value = '-(complex(0,1)*G**2*kpBHL3*kpBHpL3)/(8.*cmath.pi**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_120_50 = Coupling(name = 'R2GC_120_50',
                       value = '-(complex(0,1)*G**2*kpBHL1*kpBHpL1)/(8.*cmath.pi**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_120_51 = Coupling(name = 'R2GC_120_51',
                       value = '-(complex(0,1)*G**2*kpBHL2*kpBHpL2)/(8.*cmath.pi**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_120_52 = Coupling(name = 'R2GC_120_52',
                       value = '-(complex(0,1)*G**2*kpTHL2*kpTHpL2)/(8.*cmath.pi**2)',
                       order = {'HvB':1,'HvQ':1,'QCD':2})

R2GC_120_53 = Coupling(name = 'R2GC_120_53',
                       value = '-(complex(0,1)*G**2*kpTHL3*kpTHpL3)/(8.*cmath.pi**2) - (complex(0,1)*G**2*kpTHpR3*kpTHR3)/(8.*cmath.pi**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_120_54 = Coupling(name = 'R2GC_120_54',
                       value = '-(complex(0,1)*G**2*kpTHL1*kpTHpL1)/(8.*cmath.pi**2)',
                       order = {'HvB':1,'HvQ':1,'QCD':2})

R2GC_121_55 = Coupling(name = 'R2GC_121_55',
                       value = '-(complex(0,1)*G**2*xiHp**2)/(8.*cmath.pi**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_121_56 = Coupling(name = 'R2GC_121_56',
                       value = '-(complex(0,1)*G**2*kpBHpL3**2)/(8.*cmath.pi**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_121_57 = Coupling(name = 'R2GC_121_57',
                       value = '-(complex(0,1)*G**2*kpBHpL1**2)/(8.*cmath.pi**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_121_58 = Coupling(name = 'R2GC_121_58',
                       value = '-(complex(0,1)*G**2*kpBHpL2**2)/(8.*cmath.pi**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_121_59 = Coupling(name = 'R2GC_121_59',
                       value = '-(complex(0,1)*G**2*kpTHpL2**2)/(8.*cmath.pi**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_121_60 = Coupling(name = 'R2GC_121_60',
                       value = '-(complex(0,1)*G**2*kpTHpL3**2)/(8.*cmath.pi**2) - (complex(0,1)*G**2*kpTHpR3**2)/(8.*cmath.pi**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_121_61 = Coupling(name = 'R2GC_121_61',
                       value = '-(complex(0,1)*G**2*kpTHpL1**2)/(8.*cmath.pi**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_122_62 = Coupling(name = 'R2GC_122_62',
                       value = '(ee**2*complex(0,1)*G**2*gAd**2*xiZp**2)/(24.*cw**2*cmath.pi**2*sw**2) + (ee**2*complex(0,1)*G**2*gVd**2*xiZp**2)/(24.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_122_63 = Coupling(name = 'R2GC_122_63',
                       value = '(ee**2*complex(0,1)*G**2*gAu**2*xiZp**2)/(24.*cw**2*cmath.pi**2*sw**2) + (ee**2*complex(0,1)*G**2*gVu**2*xiZp**2)/(24.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_122_64 = Coupling(name = 'R2GC_122_64',
                       value = '(ee**2*complex(0,1)*G**2*kpBZpL3**2)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_122_65 = Coupling(name = 'R2GC_122_65',
                       value = '(ee**2*complex(0,1)*G**2*kpBZpL1**2)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_122_66 = Coupling(name = 'R2GC_122_66',
                       value = '(ee**2*complex(0,1)*G**2*kpBZpL2**2)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_122_67 = Coupling(name = 'R2GC_122_67',
                       value = '(ee**2*complex(0,1)*G**2*kpTZpL2**2)/(96.*cw**2*cmath.pi**2*sw**2) + (ee**2*complex(0,1)*G**2*kpTZpR2**2)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_122_68 = Coupling(name = 'R2GC_122_68',
                       value = '(ee**2*complex(0,1)*G**2*kpTZpL3**2)/(96.*cw**2*cmath.pi**2*sw**2) + (ee**2*complex(0,1)*G**2*kpTZpR3**2)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_122_69 = Coupling(name = 'R2GC_122_69',
                       value = '(ee**2*complex(0,1)*G**2*kpTZpL1**2)/(96.*cw**2*cmath.pi**2*sw**2) + (ee**2*complex(0,1)*G**2*kpTZpR1**2)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_123_70 = Coupling(name = 'R2GC_123_70',
                       value = '(ee**2*complex(0,1)*G**2*gAd*xiZp)/(96.*cw**2*cmath.pi**2) + (ee**2*complex(0,1)*G**2*gVd*xiZp)/(288.*cw**2*cmath.pi**2) + (ee**2*complex(0,1)*G**2*gAd*xiZp)/(96.*cmath.pi**2*sw**2) - (ee**2*complex(0,1)*G**2*gVd*xiZp)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvB':1,'QCD':2,'QED':1})

R2GC_123_71 = Coupling(name = 'R2GC_123_71',
                       value = '-(ee**2*complex(0,1)*G**2*gAu*xiZp)/(96.*cw**2*cmath.pi**2) - (5*ee**2*complex(0,1)*G**2*gVu*xiZp)/(288.*cw**2*cmath.pi**2) - (ee**2*complex(0,1)*G**2*gAu*xiZp)/(96.*cmath.pi**2*sw**2) + (ee**2*complex(0,1)*G**2*gVu*xiZp)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvB':1,'QCD':2,'QED':1})

R2GC_123_72 = Coupling(name = 'R2GC_123_72',
                       value = '(ee**2*complex(0,1)*G**2*kpBZL3*kpBZpL3)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_123_73 = Coupling(name = 'R2GC_123_73',
                       value = '(ee**2*complex(0,1)*G**2*kpBZL1*kpBZpL1)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_123_74 = Coupling(name = 'R2GC_123_74',
                       value = '(ee**2*complex(0,1)*G**2*kpBZL2*kpBZpL2)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_123_75 = Coupling(name = 'R2GC_123_75',
                       value = '(ee**2*complex(0,1)*G**2*kpTZL2*kpTZpL2)/(96.*cw**2*cmath.pi**2*sw**2) + (ee**2*complex(0,1)*G**2*kpTZpR2*kpTZR2)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_123_76 = Coupling(name = 'R2GC_123_76',
                       value = '(ee**2*complex(0,1)*G**2*kpTZL3*kpTZpL3)/(96.*cw**2*cmath.pi**2*sw**2) + (ee**2*complex(0,1)*G**2*kpTZpR3*kpTZR3)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_123_77 = Coupling(name = 'R2GC_123_77',
                       value = '(ee**2*complex(0,1)*G**2*kpTZL1*kpTZpL1)/(96.*cw**2*cmath.pi**2*sw**2) + (ee**2*complex(0,1)*G**2*kpTZpR1*kpTZR1)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_124_78 = Coupling(name = 'R2GC_124_78',
                       value = '(ee**2*complex(0,1)*G**2)/(288.*cmath.pi**2) + (cw**2*ee**2*complex(0,1)*G**2)/(192.*cmath.pi**2*sw**2) + (5*ee**2*complex(0,1)*G**2*sw**2)/(1728.*cw**2*cmath.pi**2)',
                       order = {'QCD':2,'QED':2})

R2GC_124_79 = Coupling(name = 'R2GC_124_79',
                       value = '-(ee**2*complex(0,1)*G**2)/(288.*cmath.pi**2) + (cw**2*ee**2*complex(0,1)*G**2)/(192.*cmath.pi**2*sw**2) + (17*ee**2*complex(0,1)*G**2*sw**2)/(1728.*cw**2*cmath.pi**2)',
                       order = {'QCD':2,'QED':2})

R2GC_124_80 = Coupling(name = 'R2GC_124_80',
                       value = '(ee**2*complex(0,1)*G**2*kpBZL3**2)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_124_81 = Coupling(name = 'R2GC_124_81',
                       value = '(ee**2*complex(0,1)*G**2*kpBZL1**2)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_124_82 = Coupling(name = 'R2GC_124_82',
                       value = '(ee**2*complex(0,1)*G**2*kpBZL2**2)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_124_83 = Coupling(name = 'R2GC_124_83',
                       value = '(ee**2*complex(0,1)*G**2*kpTZL2**2)/(96.*cw**2*cmath.pi**2*sw**2) + (ee**2*complex(0,1)*G**2*kpTZR2**2)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_124_84 = Coupling(name = 'R2GC_124_84',
                       value = '(ee**2*complex(0,1)*G**2*kpTZL3**2)/(96.*cw**2*cmath.pi**2*sw**2) + (ee**2*complex(0,1)*G**2*kpTZR3**2)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_124_85 = Coupling(name = 'R2GC_124_85',
                       value = '(ee**2*complex(0,1)*G**2*kpTZL1**2)/(96.*cw**2*cmath.pi**2*sw**2) + (ee**2*complex(0,1)*G**2*kpTZR1**2)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_140_86 = Coupling(name = 'R2GC_140_86',
                       value = '-G**4/(192.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_140_87 = Coupling(name = 'R2GC_140_87',
                       value = 'G**4/(64.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_141_88 = Coupling(name = 'R2GC_141_88',
                       value = '-(complex(0,1)*G**4)/(192.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_141_89 = Coupling(name = 'R2GC_141_89',
                       value = '(complex(0,1)*G**4)/(64.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_142_90 = Coupling(name = 'R2GC_142_90',
                       value = '(complex(0,1)*G**4)/(192.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_142_91 = Coupling(name = 'R2GC_142_91',
                       value = '-(complex(0,1)*G**4)/(64.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_143_92 = Coupling(name = 'R2GC_143_92',
                       value = '-(complex(0,1)*G**4)/(48.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_144_93 = Coupling(name = 'R2GC_144_93',
                       value = '(complex(0,1)*G**4)/(288.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_144_94 = Coupling(name = 'R2GC_144_94',
                       value = '-(complex(0,1)*G**4)/(32.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_145_95 = Coupling(name = 'R2GC_145_95',
                       value = '-(complex(0,1)*G**4)/(16.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_145_96 = Coupling(name = 'R2GC_145_96',
                       value = '(complex(0,1)*G**4)/(4.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_146_97 = Coupling(name = 'R2GC_146_97',
                       value = '(-3*complex(0,1)*G**4)/(64.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_146_98 = Coupling(name = 'R2GC_146_98',
                       value = '(-23*complex(0,1)*G**4)/(64.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_147_99 = Coupling(name = 'R2GC_147_99',
                       value = '(ee*complex(0,1)*G**2)/(18.*cmath.pi**2)',
                       order = {'QCD':2,'QED':1})

R2GC_148_100 = Coupling(name = 'R2GC_148_100',
                        value = '-(complex(0,1)*G**3)/(6.*cmath.pi**2)',
                        order = {'QCD':3})

R2GC_149_101 = Coupling(name = 'R2GC_149_101',
                        value = '(complex(0,1)*G**2)/(12.*cmath.pi**2)',
                        order = {'QCD':2})

R2GC_150_102 = Coupling(name = 'R2GC_150_102',
                        value = '-(ee*complex(0,1)*G**2)/(9.*cmath.pi**2)',
                        order = {'QCD':2,'QED':1})

R2GC_167_103 = Coupling(name = 'R2GC_167_103',
                        value = '-(ee*complex(0,1)*G**2)/(6.*cmath.pi**2*sw*cmath.sqrt(2))',
                        order = {'QCD':2,'QED':1})

R2GC_168_104 = Coupling(name = 'R2GC_168_104',
                        value = '-(ee*complex(0,1)*G**2*xiWp)/(6.*cmath.pi**2*sw*cmath.sqrt(2))',
                        order = {'HvB':1,'QCD':2})

R2GC_174_105 = Coupling(name = 'R2GC_174_105',
                        value = '(complex(0,1)*G**2*MB)/(6.*cmath.pi**2)',
                        order = {'QCD':2})

R2GC_176_106 = Coupling(name = 'R2GC_176_106',
                        value = '-(ee*complex(0,1)*G**2*sw)/(18.*cw*cmath.pi**2)',
                        order = {'QCD':2,'QED':1})

R2GC_179_107 = Coupling(name = 'R2GC_179_107',
                        value = '(complex(0,1)*G**2*yb)/(3.*cmath.pi**2*cmath.sqrt(2))',
                        order = {'QCD':2,'QED':1})

R2GC_183_108 = Coupling(name = 'R2GC_183_108',
                        value = '(complex(0,1)*G**2*kpBHL1)/(3.*cmath.pi**2)',
                        order = {'HvB':1,'QCD':2})

R2GC_184_109 = Coupling(name = 'R2GC_184_109',
                        value = '(complex(0,1)*G**2*kpBHL2)/(3.*cmath.pi**2)',
                        order = {'HvB':1,'QCD':2})

R2GC_185_110 = Coupling(name = 'R2GC_185_110',
                        value = '(complex(0,1)*G**2*kpBHL3)/(3.*cmath.pi**2)',
                        order = {'HvB':1,'QCD':2})

R2GC_186_111 = Coupling(name = 'R2GC_186_111',
                        value = '(complex(0,1)*G**2*kpBHpL1)/(3.*cmath.pi**2)',
                        order = {'HvB':1,'QCD':2})

R2GC_187_112 = Coupling(name = 'R2GC_187_112',
                        value = '(complex(0,1)*G**2*kpBHpL2)/(3.*cmath.pi**2)',
                        order = {'HvB':1,'QCD':2})

R2GC_188_113 = Coupling(name = 'R2GC_188_113',
                        value = '(complex(0,1)*G**2*kpBHpL3)/(3.*cmath.pi**2)',
                        order = {'HvB':1,'QCD':2})

R2GC_189_114 = Coupling(name = 'R2GC_189_114',
                        value = '(complex(0,1)*G**2*MBP)/(6.*cmath.pi**2)',
                        order = {'QCD':2})

R2GC_190_115 = Coupling(name = 'R2GC_190_115',
                        value = '-(ee*complex(0,1)*G**2*kpBWL1)/(6.*cmath.pi**2*sw*cmath.sqrt(2))',
                        order = {'HvQ':1,'QCD':2})

R2GC_191_116 = Coupling(name = 'R2GC_191_116',
                        value = '-(ee*complex(0,1)*G**2*kpBWL2)/(6.*cmath.pi**2*sw*cmath.sqrt(2))',
                        order = {'HvQ':1,'QCD':2})

R2GC_192_117 = Coupling(name = 'R2GC_192_117',
                        value = '-(ee*complex(0,1)*G**2*kpBWpL1)/(6.*cmath.pi**2*sw*cmath.sqrt(2))',
                        order = {'HvQ':1,'QCD':2})

R2GC_193_118 = Coupling(name = 'R2GC_193_118',
                        value = '-(ee*complex(0,1)*G**2*kpBWpL2)/(6.*cmath.pi**2*sw*cmath.sqrt(2))',
                        order = {'HvQ':1,'QCD':2})

R2GC_194_119 = Coupling(name = 'R2GC_194_119',
                        value = '-(ee*complex(0,1)*G**2*kpBZL1)/(12.*cw*cmath.pi**2*sw)',
                        order = {'HvQ':1,'QCD':2})

R2GC_195_120 = Coupling(name = 'R2GC_195_120',
                        value = '-(ee*complex(0,1)*G**2*kpBZL2)/(12.*cw*cmath.pi**2*sw)',
                        order = {'HvQ':1,'QCD':2})

R2GC_196_121 = Coupling(name = 'R2GC_196_121',
                        value = '-(ee*complex(0,1)*G**2*kpBZL3)/(12.*cw*cmath.pi**2*sw)',
                        order = {'HvQ':1,'QCD':2})

R2GC_197_122 = Coupling(name = 'R2GC_197_122',
                        value = '-(ee*complex(0,1)*G**2*kpBZpL1)/(12.*cw*cmath.pi**2*sw)',
                        order = {'HvQ':1,'QCD':2})

R2GC_198_123 = Coupling(name = 'R2GC_198_123',
                        value = '-(ee*complex(0,1)*G**2*kpBZpL2)/(12.*cw*cmath.pi**2*sw)',
                        order = {'HvQ':1,'QCD':2})

R2GC_199_124 = Coupling(name = 'R2GC_199_124',
                        value = '-(ee*complex(0,1)*G**2*kpBZpL3)/(12.*cw*cmath.pi**2*sw)',
                        order = {'HvQ':1,'QCD':2})

R2GC_203_125 = Coupling(name = 'R2GC_203_125',
                        value = '(complex(0,1)*G**2*MT)/(6.*cmath.pi**2)',
                        order = {'QCD':2})

R2GC_205_126 = Coupling(name = 'R2GC_205_126',
                        value = '-(ee*complex(0,1)*G**2*kpBWL3)/(6.*cmath.pi**2*sw*cmath.sqrt(2))',
                        order = {'HvQ':1,'QCD':2})

R2GC_206_127 = Coupling(name = 'R2GC_206_127',
                        value = '-(ee*complex(0,1)*G**2*kpBWpL3)/(6.*cmath.pi**2*sw*cmath.sqrt(2))',
                        order = {'HvQ':1,'QCD':2})

R2GC_208_128 = Coupling(name = 'R2GC_208_128',
                        value = '(ee*complex(0,1)*G**2*sw)/(9.*cw*cmath.pi**2)',
                        order = {'QCD':2,'QED':1})

R2GC_209_129 = Coupling(name = 'R2GC_209_129',
                        value = '(complex(0,1)*G**2*xiHp)/(3.*cmath.pi**2)',
                        order = {'HvB':1,'QCD':2})

R2GC_213_130 = Coupling(name = 'R2GC_213_130',
                        value = '(complex(0,1)*G**2*yt)/(3.*cmath.pi**2*cmath.sqrt(2))',
                        order = {'QCD':2,'QED':1})

R2GC_215_131 = Coupling(name = 'R2GC_215_131',
                        value = 'G**3/(24.*cmath.pi**2)',
                        order = {'QCD':3})

R2GC_215_132 = Coupling(name = 'R2GC_215_132',
                        value = '(11*G**3)/(64.*cmath.pi**2)',
                        order = {'QCD':3})

R2GC_216_133 = Coupling(name = 'R2GC_216_133',
                        value = '(5*complex(0,1)*G**4)/(48.*cmath.pi**2)',
                        order = {'QCD':4})

R2GC_216_134 = Coupling(name = 'R2GC_216_134',
                        value = '(19*complex(0,1)*G**4)/(32.*cmath.pi**2)',
                        order = {'QCD':4})

R2GC_217_135 = Coupling(name = 'R2GC_217_135',
                        value = '(23*complex(0,1)*G**4)/(192.*cmath.pi**2)',
                        order = {'QCD':4})

R2GC_218_136 = Coupling(name = 'R2GC_218_136',
                        value = '(31*complex(0,1)*G**4)/(64.*cmath.pi**2)',
                        order = {'QCD':4})

R2GC_219_137 = Coupling(name = 'R2GC_219_137',
                        value = '(-17*complex(0,1)*G**4)/(64.*cmath.pi**2)',
                        order = {'QCD':4})

R2GC_220_138 = Coupling(name = 'R2GC_220_138',
                        value = '(-7*complex(0,1)*G**4)/(32.*cmath.pi**2)',
                        order = {'QCD':4})

R2GC_221_139 = Coupling(name = 'R2GC_221_139',
                        value = '(7*complex(0,1)*G**4)/(64.*cmath.pi**2)',
                        order = {'QCD':4})

R2GC_225_140 = Coupling(name = 'R2GC_225_140',
                        value = '(complex(0,1)*G**2*kpTHL1)/(3.*cmath.pi**2)',
                        order = {'HvQ':1,'QCD':2})

R2GC_226_141 = Coupling(name = 'R2GC_226_141',
                        value = '(complex(0,1)*G**2*kpTHL2)/(3.*cmath.pi**2)',
                        order = {'HvQ':1,'QCD':2})

R2GC_227_142 = Coupling(name = 'R2GC_227_142',
                        value = '(complex(0,1)*G**2*kpTHL3)/(3.*cmath.pi**2)',
                        order = {'HvQ':1,'QCD':2})

R2GC_228_143 = Coupling(name = 'R2GC_228_143',
                        value = '(complex(0,1)*G**2*kpTHpL1)/(3.*cmath.pi**2)',
                        order = {'HvB':1,'QCD':2})

R2GC_229_144 = Coupling(name = 'R2GC_229_144',
                        value = '(complex(0,1)*G**2*kpTHpL2)/(3.*cmath.pi**2)',
                        order = {'HvB':1,'QCD':2})

R2GC_230_145 = Coupling(name = 'R2GC_230_145',
                        value = '(complex(0,1)*G**2*kpTHpL3)/(3.*cmath.pi**2)',
                        order = {'HvB':1,'QCD':2})

R2GC_231_146 = Coupling(name = 'R2GC_231_146',
                        value = '(complex(0,1)*G**2*kpTHpR3)/(3.*cmath.pi**2)',
                        order = {'HvB':1,'QCD':2})

R2GC_232_147 = Coupling(name = 'R2GC_232_147',
                        value = '(complex(0,1)*G**2*kpTHR3)/(3.*cmath.pi**2)',
                        order = {'HvB':1,'QCD':2})

R2GC_233_148 = Coupling(name = 'R2GC_233_148',
                        value = '(complex(0,1)*G**2*MTP)/(6.*cmath.pi**2)',
                        order = {'QCD':2})

R2GC_234_149 = Coupling(name = 'R2GC_234_149',
                        value = '-(ee*complex(0,1)*G**2*kpTWL1)/(6.*cmath.pi**2*sw*cmath.sqrt(2))',
                        order = {'HvQ':1,'QCD':2})

R2GC_235_150 = Coupling(name = 'R2GC_235_150',
                        value = '-(ee*complex(0,1)*G**2*kpTWL2)/(6.*cmath.pi**2*sw*cmath.sqrt(2))',
                        order = {'HvQ':1,'QCD':2})

R2GC_236_151 = Coupling(name = 'R2GC_236_151',
                        value = '-(ee*complex(0,1)*G**2*kpTWL3)/(6.*cmath.pi**2*sw*cmath.sqrt(2))',
                        order = {'HvQ':1,'QCD':2})

R2GC_237_152 = Coupling(name = 'R2GC_237_152',
                        value = '-(ee*complex(0,1)*G**2*kpTWpL1)/(6.*cmath.pi**2*sw*cmath.sqrt(2))',
                        order = {'HvQ':1,'QCD':2})

R2GC_238_153 = Coupling(name = 'R2GC_238_153',
                        value = '-(ee*complex(0,1)*G**2*kpTWpL2)/(6.*cmath.pi**2*sw*cmath.sqrt(2))',
                        order = {'HvQ':1,'QCD':2})

R2GC_239_154 = Coupling(name = 'R2GC_239_154',
                        value = '-(ee*complex(0,1)*G**2*kpTWpL3)/(6.*cmath.pi**2*sw*cmath.sqrt(2))',
                        order = {'HvQ':1,'QCD':2})

R2GC_240_155 = Coupling(name = 'R2GC_240_155',
                        value = '-(ee*complex(0,1)*G**2*kpTZL1)/(12.*cw*cmath.pi**2*sw)',
                        order = {'HvQ':1,'QCD':2})

R2GC_241_156 = Coupling(name = 'R2GC_241_156',
                        value = '-(ee*complex(0,1)*G**2*kpTZL2)/(12.*cw*cmath.pi**2*sw)',
                        order = {'HvQ':1,'QCD':2})

R2GC_242_157 = Coupling(name = 'R2GC_242_157',
                        value = '-(ee*complex(0,1)*G**2*kpTZL3)/(12.*cw*cmath.pi**2*sw)',
                        order = {'HvQ':1,'QCD':2})

R2GC_243_158 = Coupling(name = 'R2GC_243_158',
                        value = '-(ee*complex(0,1)*G**2*kpTZpL1)/(12.*cw*cmath.pi**2*sw)',
                        order = {'HvQ':1,'QCD':2})

R2GC_244_159 = Coupling(name = 'R2GC_244_159',
                        value = '-(ee*complex(0,1)*G**2*kpTZpL2)/(12.*cw*cmath.pi**2*sw)',
                        order = {'HvQ':1,'QCD':2})

R2GC_245_160 = Coupling(name = 'R2GC_245_160',
                        value = '-(ee*complex(0,1)*G**2*kpTZpL3)/(12.*cw*cmath.pi**2*sw)',
                        order = {'HvQ':1,'QCD':2})

R2GC_246_161 = Coupling(name = 'R2GC_246_161',
                        value = '-(ee*complex(0,1)*G**2*kpTZpR1)/(12.*cw*cmath.pi**2*sw)',
                        order = {'HvQ':1,'QCD':2})

R2GC_247_162 = Coupling(name = 'R2GC_247_162',
                        value = '-(ee*complex(0,1)*G**2*kpTZpR2)/(12.*cw*cmath.pi**2*sw)',
                        order = {'HvQ':1,'QCD':2})

R2GC_248_163 = Coupling(name = 'R2GC_248_163',
                        value = '-(ee*complex(0,1)*G**2*kpTZpR3)/(12.*cw*cmath.pi**2*sw)',
                        order = {'HvQ':1,'QCD':2})

R2GC_249_164 = Coupling(name = 'R2GC_249_164',
                        value = '-(ee*complex(0,1)*G**2*kpTZR1)/(12.*cw*cmath.pi**2*sw)',
                        order = {'HvQ':1,'QCD':2})

R2GC_250_165 = Coupling(name = 'R2GC_250_165',
                        value = '-(ee*complex(0,1)*G**2*kpTZR2)/(12.*cw*cmath.pi**2*sw)',
                        order = {'HvQ':1,'QCD':2})

R2GC_251_166 = Coupling(name = 'R2GC_251_166',
                        value = '-(ee*complex(0,1)*G**2*kpTZR3)/(12.*cw*cmath.pi**2*sw)',
                        order = {'HvQ':1,'QCD':2})

R2GC_83_167 = Coupling(name = 'R2GC_83_167',
                       value = '-(complex(0,1)*G**2)/(16.*cmath.pi**2)',
                       order = {'QCD':2})

R2GC_84_168 = Coupling(name = 'R2GC_84_168',
                       value = '-(complex(0,1)*G**2*MT*xiHp)/(8.*cmath.pi**2)',
                       order = {'HvB':1,'QCD':2})

R2GC_89_169 = Coupling(name = 'R2GC_89_169',
                       value = '(ee*complex(0,1)*G**2*gAd*xiZp)/(6.*cw*cmath.pi**2*sw)',
                       order = {'HvB':1,'QCD':2})

R2GC_90_170 = Coupling(name = 'R2GC_90_170',
                       value = '-(ee*complex(0,1)*G**2*gVd*xiZp)/(6.*cw*cmath.pi**2*sw)',
                       order = {'HvB':1,'QCD':2})

R2GC_95_171 = Coupling(name = 'R2GC_95_171',
                       value = '-(complex(0,1)*G**2*MB*yb)/(8.*cmath.pi**2*cmath.sqrt(2))',
                       order = {'QCD':2,'QED':1})

R2GC_95_172 = Coupling(name = 'R2GC_95_172',
                       value = '-(complex(0,1)*G**2*MT*yt)/(8.*cmath.pi**2*cmath.sqrt(2))',
                       order = {'QCD':2,'QED':1})

R2GC_96_173 = Coupling(name = 'R2GC_96_173',
                       value = '-(complex(0,1)*G**2*MB**2)/(8.*cmath.pi**2)',
                       order = {'QCD':2})

R2GC_96_174 = Coupling(name = 'R2GC_96_174',
                       value = '-(complex(0,1)*G**2*MBP**2)/(8.*cmath.pi**2)',
                       order = {'QCD':2})

R2GC_96_175 = Coupling(name = 'R2GC_96_175',
                       value = '-(complex(0,1)*G**2*MT**2)/(8.*cmath.pi**2)',
                       order = {'QCD':2})

R2GC_96_176 = Coupling(name = 'R2GC_96_176',
                       value = '-(complex(0,1)*G**2*MTP**2)/(8.*cmath.pi**2)',
                       order = {'QCD':2})

R2GC_97_177 = Coupling(name = 'R2GC_97_177',
                       value = '(complex(0,1)*G**2)/(48.*cmath.pi**2)',
                       order = {'QCD':2})

R2GC_98_178 = Coupling(name = 'R2GC_98_178',
                       value = '(ee**2*complex(0,1)*G**2)/(216.*cmath.pi**2)',
                       order = {'QCD':2,'QED':2})

R2GC_98_179 = Coupling(name = 'R2GC_98_179',
                       value = '(ee**2*complex(0,1)*G**2)/(54.*cmath.pi**2)',
                       order = {'QCD':2,'QED':2})

R2GC_99_180 = Coupling(name = 'R2GC_99_180',
                       value = '-(ee*complex(0,1)*G**3)/(144.*cmath.pi**2)',
                       order = {'QCD':3,'QED':1})

R2GC_99_181 = Coupling(name = 'R2GC_99_181',
                       value = '(ee*complex(0,1)*G**3)/(72.*cmath.pi**2)',
                       order = {'QCD':3,'QED':1})

UVGC_125_1 = Coupling(name = 'UVGC_125_1',
                      value = {-1:'(51*G**3)/(128.*cmath.pi**2)'},
                      order = {'QCD':3})

UVGC_126_2 = Coupling(name = 'UVGC_126_2',
                      value = {-1:'G**3/(128.*cmath.pi**2)'},
                      order = {'QCD':3})

UVGC_127_3 = Coupling(name = 'UVGC_127_3',
                      value = {-1:'(ee*complex(0,1)*G**2)/(36.*cmath.pi**2)'},
                      order = {'QCD':2,'QED':1})

UVGC_128_4 = Coupling(name = 'UVGC_128_4',
                      value = {-1:'(-13*complex(0,1)*G**3)/(48.*cmath.pi**2)'},
                      order = {'QCD':3})

UVGC_129_5 = Coupling(name = 'UVGC_129_5',
                      value = {-1:'-(complex(0,1)*G**2)/(12.*cmath.pi**2)'},
                      order = {'QCD':2})

UVGC_130_6 = Coupling(name = 'UVGC_130_6',
                      value = {-1:'(ee*complex(0,1)*G**2)/(18.*cmath.pi**2)'},
                      order = {'QCD':2,'QED':1})

UVGC_132_7 = Coupling(name = 'UVGC_132_7',
                      value = {-1:'-(ee*complex(0,1)*G**2)/(36.*cmath.pi**2)'},
                      order = {'QCD':2,'QED':1})

UVGC_135_8 = Coupling(name = 'UVGC_135_8',
                      value = {-1:'-(ee*complex(0,1)*G**2)/(18.*cmath.pi**2)'},
                      order = {'QCD':2,'QED':1})

UVGC_139_9 = Coupling(name = 'UVGC_139_9',
                      value = {-1:'(3*complex(0,1)*G**2)/(64.*cmath.pi**2)'},
                      order = {'QCD':2})

UVGC_139_10 = Coupling(name = 'UVGC_139_10',
                       value = {-1:'(-3*complex(0,1)*G**2)/(64.*cmath.pi**2)'},
                       order = {'QCD':2})

UVGC_140_11 = Coupling(name = 'UVGC_140_11',
                       value = {-1:'(3*G**4)/(512.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_140_12 = Coupling(name = 'UVGC_140_12',
                       value = {-1:'(-3*G**4)/(512.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_141_13 = Coupling(name = 'UVGC_141_13',
                       value = {-1:'(3*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_141_14 = Coupling(name = 'UVGC_141_14',
                       value = {-1:'(-3*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_143_15 = Coupling(name = 'UVGC_143_15',
                       value = {-1:'-(complex(0,1)*G**4)/(128.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_143_16 = Coupling(name = 'UVGC_143_16',
                       value = {-1:'(complex(0,1)*G**4)/(128.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_144_17 = Coupling(name = 'UVGC_144_17',
                       value = {-1:'(-3*complex(0,1)*G**4)/(256.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_144_18 = Coupling(name = 'UVGC_144_18',
                       value = {-1:'(3*complex(0,1)*G**4)/(256.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_145_19 = Coupling(name = 'UVGC_145_19',
                       value = {-1:'-(complex(0,1)*G**4)/(24.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_145_20 = Coupling(name = 'UVGC_145_20',
                       value = {-1:'(47*complex(0,1)*G**4)/(128.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_146_21 = Coupling(name = 'UVGC_146_21',
                       value = {-1:'(-253*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_146_22 = Coupling(name = 'UVGC_146_22',
                       value = {-1:'(5*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_149_23 = Coupling(name = 'UVGC_149_23',
                       value = {-1:'(complex(0,1)*G**2)/(12.*cmath.pi**2)'},
                       order = {'QCD':2})

UVGC_151_24 = Coupling(name = 'UVGC_151_24',
                       value = {-1:'( 0 if MB else (complex(0,1)*G**3)/(48.*cmath.pi**2) )'},
                       order = {'QCD':3})

UVGC_151_25 = Coupling(name = 'UVGC_151_25',
                       value = {-1:'(complex(0,1)*G**3)/(48.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_151_26 = Coupling(name = 'UVGC_151_26',
                       value = {-1:'(-19*complex(0,1)*G**3)/(128.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_151_27 = Coupling(name = 'UVGC_151_27',
                       value = {-1:'-(complex(0,1)*G**3)/(128.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_151_28 = Coupling(name = 'UVGC_151_28',
                       value = {-1:'(complex(0,1)*G**3)/(12.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_167_29 = Coupling(name = 'UVGC_167_29',
                       value = {-1:'(ee*complex(0,1)*G**2)/(24.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'QCD':2,'QED':1})

UVGC_167_30 = Coupling(name = 'UVGC_167_30',
                       value = {-1:'-(ee*complex(0,1)*G**2)/(12.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'QCD':2,'QED':1})

UVGC_168_31 = Coupling(name = 'UVGC_168_31',
                       value = {-1:'(ee*complex(0,1)*G**2*xiWp)/(24.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvB':1,'QCD':2})

UVGC_168_32 = Coupling(name = 'UVGC_168_32',
                       value = {-1:'-(ee*complex(0,1)*G**2*xiWp)/(12.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvB':1,'QCD':2})

UVGC_171_33 = Coupling(name = 'UVGC_171_33',
                       value = {-1:'( (complex(0,1)*G**2)/(6.*cmath.pi**2) if MB else -(complex(0,1)*G**2)/(12.*cmath.pi**2) ) + (complex(0,1)*G**2)/(12.*cmath.pi**2)',0:'( (5*complex(0,1)*G**2)/(12.*cmath.pi**2) - (complex(0,1)*G**2*reglog(MB/MU_R))/(2.*cmath.pi**2) if MB else (complex(0,1)*G**2)/(12.*cmath.pi**2) ) - (complex(0,1)*G**2)/(12.*cmath.pi**2)'},
                       order = {'QCD':2})

UVGC_172_34 = Coupling(name = 'UVGC_172_34',
                       value = {-1:'( (ee*complex(0,1)*G**2)/(18.*cmath.pi**2) if MB else -(ee*complex(0,1)*G**2)/(36.*cmath.pi**2) )',0:'( (5*ee*complex(0,1)*G**2)/(36.*cmath.pi**2) - (ee*complex(0,1)*G**2*reglog(MB/MU_R))/(6.*cmath.pi**2) if MB else (ee*complex(0,1)*G**2)/(36.*cmath.pi**2) ) - (ee*complex(0,1)*G**2)/(36.*cmath.pi**2)'},
                       order = {'QCD':2,'QED':1})

UVGC_173_35 = Coupling(name = 'UVGC_173_35',
                       value = {-1:'( -(complex(0,1)*G**3)/(6.*cmath.pi**2) if MB else (complex(0,1)*G**3)/(12.*cmath.pi**2) )',0:'( (-5*complex(0,1)*G**3)/(12.*cmath.pi**2) + (complex(0,1)*G**3*reglog(MB/MU_R))/(2.*cmath.pi**2) if MB else -(complex(0,1)*G**3)/(12.*cmath.pi**2) ) + (complex(0,1)*G**3)/(12.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_174_36 = Coupling(name = 'UVGC_174_36',
                       value = {-1:'( (complex(0,1)*G**2*MB)/(6.*cmath.pi**2) if MB else -(complex(0,1)*G**2*MB)/(12.*cmath.pi**2) ) + (complex(0,1)*G**2*MB)/(3.*cmath.pi**2)',0:'( (3*complex(0,1)*G**2*MB)/(4.*cmath.pi**2) - (complex(0,1)*G**2*MB*reglog(MB/MU_R))/cmath.pi**2 if MB else (complex(0,1)*G**2*MB)/(12.*cmath.pi**2) ) - (complex(0,1)*G**2*MB)/(12.*cmath.pi**2)'},
                       order = {'QCD':2})

UVGC_175_37 = Coupling(name = 'UVGC_175_37',
                       value = {-1:'( (cw*ee*complex(0,1)*G**2)/(12.*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*sw)/(36.*cw*cmath.pi**2) if MB else -(cw*ee*complex(0,1)*G**2)/(24.*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*sw)/(72.*cw*cmath.pi**2) ) + (cw*ee*complex(0,1)*G**2)/(24.*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*sw)/(72.*cw*cmath.pi**2)',0:'( (5*cw*ee*complex(0,1)*G**2)/(24.*cmath.pi**2*sw) + (5*ee*complex(0,1)*G**2*sw)/(72.*cw*cmath.pi**2) - (cw*ee*complex(0,1)*G**2*reglog(MB/MU_R))/(4.*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*sw*reglog(MB/MU_R))/(12.*cw*cmath.pi**2) if MB else (cw*ee*complex(0,1)*G**2)/(24.*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*sw)/(72.*cw*cmath.pi**2) ) - (cw*ee*complex(0,1)*G**2)/(24.*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*sw)/(72.*cw*cmath.pi**2)'},
                       order = {'QCD':2,'QED':1})

UVGC_176_38 = Coupling(name = 'UVGC_176_38',
                       value = {-1:'( -(ee*complex(0,1)*G**2*sw)/(18.*cw*cmath.pi**2) if MB else (ee*complex(0,1)*G**2*sw)/(36.*cw*cmath.pi**2) ) - (ee*complex(0,1)*G**2*sw)/(36.*cw*cmath.pi**2)',0:'( (-5*ee*complex(0,1)*G**2*sw)/(36.*cw*cmath.pi**2) + (ee*complex(0,1)*G**2*sw*reglog(MB/MU_R))/(6.*cw*cmath.pi**2) if MB else -(ee*complex(0,1)*G**2*sw)/(36.*cw*cmath.pi**2) ) + (ee*complex(0,1)*G**2*sw)/(36.*cw*cmath.pi**2)'},
                       order = {'QCD':2,'QED':1})

UVGC_177_39 = Coupling(name = 'UVGC_177_39',
                       value = {-1:'( (ee*complex(0,1)*G**2*gAd*xiZp)/(6.*cw*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*gVd*xiZp)/(6.*cw*cmath.pi**2*sw) if MB else -(ee*complex(0,1)*G**2*gAd*xiZp)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*gVd*xiZp)/(12.*cw*cmath.pi**2*sw) ) + (ee*complex(0,1)*G**2*gAd*xiZp)/(12.*cw*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*gVd*xiZp)/(12.*cw*cmath.pi**2*sw)',0:'( (5*ee*complex(0,1)*G**2*gAd*xiZp)/(12.*cw*cmath.pi**2*sw) - (5*ee*complex(0,1)*G**2*gVd*xiZp)/(12.*cw*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*gAd*xiZp*reglog(MB/MU_R))/(2.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*gVd*xiZp*reglog(MB/MU_R))/(2.*cw*cmath.pi**2*sw) if MB else (ee*complex(0,1)*G**2*gAd*xiZp)/(12.*cw*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*gVd*xiZp)/(12.*cw*cmath.pi**2*sw) ) - (ee*complex(0,1)*G**2*gAd*xiZp)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*gVd*xiZp)/(12.*cw*cmath.pi**2*sw)'},
                       order = {'HvB':1,'QCD':2})

UVGC_178_40 = Coupling(name = 'UVGC_178_40',
                       value = {-1:'( -(ee*complex(0,1)*G**2*gAd*xiZp)/(6.*cw*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*gVd*xiZp)/(6.*cw*cmath.pi**2*sw) if MB else (ee*complex(0,1)*G**2*gAd*xiZp)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*gVd*xiZp)/(12.*cw*cmath.pi**2*sw) ) - (ee*complex(0,1)*G**2*gAd*xiZp)/(12.*cw*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*gVd*xiZp)/(12.*cw*cmath.pi**2*sw)',0:'( (-5*ee*complex(0,1)*G**2*gAd*xiZp)/(12.*cw*cmath.pi**2*sw) - (5*ee*complex(0,1)*G**2*gVd*xiZp)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*gAd*xiZp*reglog(MB/MU_R))/(2.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*gVd*xiZp*reglog(MB/MU_R))/(2.*cw*cmath.pi**2*sw) if MB else -(ee*complex(0,1)*G**2*gAd*xiZp)/(12.*cw*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*gVd*xiZp)/(12.*cw*cmath.pi**2*sw) ) + (ee*complex(0,1)*G**2*gAd*xiZp)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*gVd*xiZp)/(12.*cw*cmath.pi**2*sw)'},
                       order = {'HvB':1,'QCD':2})

UVGC_179_41 = Coupling(name = 'UVGC_179_41',
                       value = {-1:'( (complex(0,1)*G**2*yb)/(6.*cmath.pi**2*cmath.sqrt(2)) if MB else -(complex(0,1)*G**2*yb)/(12.*cmath.pi**2*cmath.sqrt(2)) ) + (complex(0,1)*G**2*yb)/(3.*cmath.pi**2*cmath.sqrt(2))',0:'( (3*complex(0,1)*G**2*yb)/(4.*cmath.pi**2*cmath.sqrt(2)) - (complex(0,1)*G**2*yb*reglog(MB/MU_R))/(cmath.pi**2*cmath.sqrt(2)) if MB else (complex(0,1)*G**2*yb)/(12.*cmath.pi**2*cmath.sqrt(2)) ) - (complex(0,1)*G**2*yb)/(12.*cmath.pi**2*cmath.sqrt(2))'},
                       order = {'QCD':2,'QED':1})

UVGC_180_42 = Coupling(name = 'UVGC_180_42',
                       value = {-1:'(complex(0,1)*G**2)/(4.*cmath.pi**2)',0:'(complex(0,1)*G**2)/(3.*cmath.pi**2) - (complex(0,1)*G**2*reglog(MBP/MU_R))/(2.*cmath.pi**2)'},
                       order = {'QCD':2})

UVGC_181_43 = Coupling(name = 'UVGC_181_43',
                       value = {0:'(ee*complex(0,1)*G**2)/(9.*cmath.pi**2) - (ee*complex(0,1)*G**2*reglog(MBP/MU_R))/(6.*cmath.pi**2)'},
                       order = {'QCD':2,'QED':1})

UVGC_182_44 = Coupling(name = 'UVGC_182_44',
                       value = {0:'-(complex(0,1)*G**3)/(3.*cmath.pi**2) + (complex(0,1)*G**3*reglog(MBP/MU_R))/(2.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_183_45 = Coupling(name = 'UVGC_183_45',
                       value = {-1:'(complex(0,1)*G**2*kpBHL1)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpBHL1)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpBHL1*reglog(MBP/MU_R))/(4.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_183_46 = Coupling(name = 'UVGC_183_46',
                       value = {-1:'-(complex(0,1)*G**2*kpBHL1)/(24.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_183_47 = Coupling(name = 'UVGC_183_47',
                       value = {-1:'(complex(0,1)*G**2*kpBHL1)/(3.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_184_48 = Coupling(name = 'UVGC_184_48',
                       value = {-1:'(complex(0,1)*G**2*kpBHL2)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpBHL2)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpBHL2*reglog(MBP/MU_R))/(4.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_184_49 = Coupling(name = 'UVGC_184_49',
                       value = {-1:'-(complex(0,1)*G**2*kpBHL2)/(24.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_184_50 = Coupling(name = 'UVGC_184_50',
                       value = {-1:'(complex(0,1)*G**2*kpBHL2)/(3.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_185_51 = Coupling(name = 'UVGC_185_51',
                       value = {-1:'( (complex(0,1)*G**2*kpBHL3)/(12.*cmath.pi**2) if MB else -(complex(0,1)*G**2*kpBHL3)/(24.*cmath.pi**2) )',0:'( (5*complex(0,1)*G**2*kpBHL3)/(24.*cmath.pi**2) - (complex(0,1)*G**2*kpBHL3*reglog(MB/MU_R))/(4.*cmath.pi**2) if MB else (complex(0,1)*G**2*kpBHL3)/(24.*cmath.pi**2) ) - (complex(0,1)*G**2*kpBHL3)/(24.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_185_52 = Coupling(name = 'UVGC_185_52',
                       value = {-1:'(complex(0,1)*G**2*kpBHL3)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpBHL3)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpBHL3*reglog(MBP/MU_R))/(4.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_185_53 = Coupling(name = 'UVGC_185_53',
                       value = {-1:'(complex(0,1)*G**2*kpBHL3)/(3.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_186_54 = Coupling(name = 'UVGC_186_54',
                       value = {-1:'(complex(0,1)*G**2*kpBHpL1)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpBHpL1)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpBHpL1*reglog(MBP/MU_R))/(4.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_186_55 = Coupling(name = 'UVGC_186_55',
                       value = {-1:'-(complex(0,1)*G**2*kpBHpL1)/(24.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_186_56 = Coupling(name = 'UVGC_186_56',
                       value = {-1:'(complex(0,1)*G**2*kpBHpL1)/(3.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_187_57 = Coupling(name = 'UVGC_187_57',
                       value = {-1:'(complex(0,1)*G**2*kpBHpL2)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpBHpL2)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpBHpL2*reglog(MBP/MU_R))/(4.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_187_58 = Coupling(name = 'UVGC_187_58',
                       value = {-1:'-(complex(0,1)*G**2*kpBHpL2)/(24.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_187_59 = Coupling(name = 'UVGC_187_59',
                       value = {-1:'(complex(0,1)*G**2*kpBHpL2)/(3.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_188_60 = Coupling(name = 'UVGC_188_60',
                       value = {-1:'( (complex(0,1)*G**2*kpBHpL3)/(12.*cmath.pi**2) if MB else -(complex(0,1)*G**2*kpBHpL3)/(24.*cmath.pi**2) )',0:'( (5*complex(0,1)*G**2*kpBHpL3)/(24.*cmath.pi**2) - (complex(0,1)*G**2*kpBHpL3*reglog(MB/MU_R))/(4.*cmath.pi**2) if MB else (complex(0,1)*G**2*kpBHpL3)/(24.*cmath.pi**2) ) - (complex(0,1)*G**2*kpBHpL3)/(24.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_188_61 = Coupling(name = 'UVGC_188_61',
                       value = {-1:'(complex(0,1)*G**2*kpBHpL3)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpBHpL3)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpBHpL3*reglog(MBP/MU_R))/(4.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_188_62 = Coupling(name = 'UVGC_188_62',
                       value = {-1:'(complex(0,1)*G**2*kpBHpL3)/(3.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_189_63 = Coupling(name = 'UVGC_189_63',
                       value = {-1:'(complex(0,1)*G**2*MBP)/(2.*cmath.pi**2)',0:'(2*complex(0,1)*G**2*MBP)/(3.*cmath.pi**2) - (complex(0,1)*G**2*MBP*reglog(MBP/MU_R))/cmath.pi**2'},
                       order = {'QCD':2})

UVGC_190_64 = Coupling(name = 'UVGC_190_64',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBWL1)/(12.*cmath.pi**2*sw*cmath.sqrt(2))',0:'-(ee*complex(0,1)*G**2*kpBWL1)/(6.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*kpBWL1*reglog(MBP/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvQ':1,'QCD':2})

UVGC_190_65 = Coupling(name = 'UVGC_190_65',
                       value = {-1:'(ee*complex(0,1)*G**2*kpBWL1)/(24.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvQ':1,'QCD':2})

UVGC_190_66 = Coupling(name = 'UVGC_190_66',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBWL1)/(12.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvQ':1,'QCD':2})

UVGC_191_67 = Coupling(name = 'UVGC_191_67',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBWL2)/(12.*cmath.pi**2*sw*cmath.sqrt(2))',0:'-(ee*complex(0,1)*G**2*kpBWL2)/(6.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*kpBWL2*reglog(MBP/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvQ':1,'QCD':2})

UVGC_191_68 = Coupling(name = 'UVGC_191_68',
                       value = {-1:'(ee*complex(0,1)*G**2*kpBWL2)/(24.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvQ':1,'QCD':2})

UVGC_191_69 = Coupling(name = 'UVGC_191_69',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBWL2)/(12.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvQ':1,'QCD':2})

UVGC_192_70 = Coupling(name = 'UVGC_192_70',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBWpL1)/(12.*cmath.pi**2*sw*cmath.sqrt(2))',0:'-(ee*complex(0,1)*G**2*kpBWpL1)/(6.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*kpBWpL1*reglog(MBP/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvQ':1,'QCD':2})

UVGC_192_71 = Coupling(name = 'UVGC_192_71',
                       value = {-1:'(ee*complex(0,1)*G**2*kpBWpL1)/(24.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvQ':1,'QCD':2})

UVGC_192_72 = Coupling(name = 'UVGC_192_72',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBWpL1)/(12.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvQ':1,'QCD':2})

UVGC_193_73 = Coupling(name = 'UVGC_193_73',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBWpL2)/(12.*cmath.pi**2*sw*cmath.sqrt(2))',0:'-(ee*complex(0,1)*G**2*kpBWpL2)/(6.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*kpBWpL2*reglog(MBP/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvQ':1,'QCD':2})

UVGC_193_74 = Coupling(name = 'UVGC_193_74',
                       value = {-1:'(ee*complex(0,1)*G**2*kpBWpL2)/(24.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvQ':1,'QCD':2})

UVGC_193_75 = Coupling(name = 'UVGC_193_75',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBWpL2)/(12.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvQ':1,'QCD':2})

UVGC_194_76 = Coupling(name = 'UVGC_194_76',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBZL1)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpBZL1)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpBZL1*reglog(MBP/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_194_77 = Coupling(name = 'UVGC_194_77',
                       value = {-1:'(ee*complex(0,1)*G**2*kpBZL1)/(48.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_194_78 = Coupling(name = 'UVGC_194_78',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBZL1)/(24.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_195_79 = Coupling(name = 'UVGC_195_79',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBZL2)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpBZL2)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpBZL2*reglog(MBP/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_195_80 = Coupling(name = 'UVGC_195_80',
                       value = {-1:'(ee*complex(0,1)*G**2*kpBZL2)/(48.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_195_81 = Coupling(name = 'UVGC_195_81',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBZL2)/(24.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_196_82 = Coupling(name = 'UVGC_196_82',
                       value = {-1:'( -(ee*complex(0,1)*G**2*kpBZL3)/(24.*cw*cmath.pi**2*sw) if MB else (ee*complex(0,1)*G**2*kpBZL3)/(48.*cw*cmath.pi**2*sw) )',0:'( (-5*ee*complex(0,1)*G**2*kpBZL3)/(48.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpBZL3*reglog(MB/MU_R))/(8.*cw*cmath.pi**2*sw) if MB else -(ee*complex(0,1)*G**2*kpBZL3)/(48.*cw*cmath.pi**2*sw) ) + (ee*complex(0,1)*G**2*kpBZL3)/(48.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_196_83 = Coupling(name = 'UVGC_196_83',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBZL3)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpBZL3)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpBZL3*reglog(MBP/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_196_84 = Coupling(name = 'UVGC_196_84',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBZL3)/(24.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_197_85 = Coupling(name = 'UVGC_197_85',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBZpL1)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpBZpL1)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpBZpL1*reglog(MBP/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_197_86 = Coupling(name = 'UVGC_197_86',
                       value = {-1:'(ee*complex(0,1)*G**2*kpBZpL1)/(48.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_197_87 = Coupling(name = 'UVGC_197_87',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBZpL1)/(24.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_198_88 = Coupling(name = 'UVGC_198_88',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBZpL2)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpBZpL2)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpBZpL2*reglog(MBP/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_198_89 = Coupling(name = 'UVGC_198_89',
                       value = {-1:'(ee*complex(0,1)*G**2*kpBZpL2)/(48.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_198_90 = Coupling(name = 'UVGC_198_90',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBZpL2)/(24.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_199_91 = Coupling(name = 'UVGC_199_91',
                       value = {-1:'( -(ee*complex(0,1)*G**2*kpBZpL3)/(24.*cw*cmath.pi**2*sw) if MB else (ee*complex(0,1)*G**2*kpBZpL3)/(48.*cw*cmath.pi**2*sw) )',0:'( (-5*ee*complex(0,1)*G**2*kpBZpL3)/(48.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpBZpL3*reglog(MB/MU_R))/(8.*cw*cmath.pi**2*sw) if MB else -(ee*complex(0,1)*G**2*kpBZpL3)/(48.*cw*cmath.pi**2*sw) ) + (ee*complex(0,1)*G**2*kpBZpL3)/(48.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_199_92 = Coupling(name = 'UVGC_199_92',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBZpL3)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpBZpL3)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpBZpL3*reglog(MBP/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_199_93 = Coupling(name = 'UVGC_199_93',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBZpL3)/(24.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_200_94 = Coupling(name = 'UVGC_200_94',
                       value = {-1:'(complex(0,1)*G**2)/(4.*cmath.pi**2)',0:'(complex(0,1)*G**2)/(3.*cmath.pi**2) - (complex(0,1)*G**2*reglog(MT/MU_R))/(2.*cmath.pi**2)'},
                       order = {'QCD':2})

UVGC_201_95 = Coupling(name = 'UVGC_201_95',
                       value = {-1:'-(ee*complex(0,1)*G**2)/(9.*cmath.pi**2)',0:'(-2*ee*complex(0,1)*G**2)/(9.*cmath.pi**2) + (ee*complex(0,1)*G**2*reglog(MT/MU_R))/(3.*cmath.pi**2)'},
                       order = {'QCD':2,'QED':1})

UVGC_202_96 = Coupling(name = 'UVGC_202_96',
                       value = {-1:'-(complex(0,1)*G**3)/(6.*cmath.pi**2)',0:'-(complex(0,1)*G**3)/(3.*cmath.pi**2) + (complex(0,1)*G**3*reglog(MT/MU_R))/(2.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_203_97 = Coupling(name = 'UVGC_203_97',
                       value = {-1:'(complex(0,1)*G**2*MT)/(2.*cmath.pi**2)',0:'(2*complex(0,1)*G**2*MT)/(3.*cmath.pi**2) - (complex(0,1)*G**2*MT*reglog(MT/MU_R))/cmath.pi**2'},
                       order = {'QCD':2})

UVGC_204_98 = Coupling(name = 'UVGC_204_98',
                       value = {-1:'( -(ee*complex(0,1)*G**2)/(12.*cmath.pi**2*sw*cmath.sqrt(2)) if MB else (ee*complex(0,1)*G**2)/(24.*cmath.pi**2*sw*cmath.sqrt(2)) )',0:'( (-5*ee*complex(0,1)*G**2)/(24.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*reglog(MB/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2)) if MB else -(ee*complex(0,1)*G**2)/(24.*cmath.pi**2*sw*cmath.sqrt(2)) ) + (ee*complex(0,1)*G**2)/(24.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'QCD':2,'QED':1})

UVGC_204_99 = Coupling(name = 'UVGC_204_99',
                       value = {-1:'-(ee*complex(0,1)*G**2)/(12.*cmath.pi**2*sw*cmath.sqrt(2))',0:'-(ee*complex(0,1)*G**2)/(6.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*reglog(MT/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'QCD':2,'QED':1})

UVGC_205_100 = Coupling(name = 'UVGC_205_100',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpBWL3)/(12.*cmath.pi**2*sw*cmath.sqrt(2))',0:'-(ee*complex(0,1)*G**2*kpBWL3)/(6.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*kpBWL3*reglog(MBP/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_205_101 = Coupling(name = 'UVGC_205_101',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpBWL3)/(12.*cmath.pi**2*sw*cmath.sqrt(2))',0:'-(ee*complex(0,1)*G**2*kpBWL3)/(6.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*kpBWL3*reglog(MT/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_205_102 = Coupling(name = 'UVGC_205_102',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpBWL3)/(12.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_206_103 = Coupling(name = 'UVGC_206_103',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpBWpL3)/(12.*cmath.pi**2*sw*cmath.sqrt(2))',0:'-(ee*complex(0,1)*G**2*kpBWpL3)/(6.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*kpBWpL3*reglog(MBP/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_206_104 = Coupling(name = 'UVGC_206_104',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpBWpL3)/(12.*cmath.pi**2*sw*cmath.sqrt(2))',0:'-(ee*complex(0,1)*G**2*kpBWpL3)/(6.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*kpBWpL3*reglog(MT/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_206_105 = Coupling(name = 'UVGC_206_105',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpBWpL3)/(12.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_207_106 = Coupling(name = 'UVGC_207_106',
                        value = {-1:'-(cw*ee*complex(0,1)*G**2)/(8.*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*sw)/(24.*cw*cmath.pi**2)',0:'-(cw*ee*complex(0,1)*G**2)/(6.*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*sw)/(18.*cw*cmath.pi**2) + (cw*ee*complex(0,1)*G**2*reglog(MT/MU_R))/(4.*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*sw*reglog(MT/MU_R))/(12.*cw*cmath.pi**2)'},
                        order = {'QCD':2,'QED':1})

UVGC_208_107 = Coupling(name = 'UVGC_208_107',
                        value = {-1:'(ee*complex(0,1)*G**2*sw)/(6.*cw*cmath.pi**2)',0:'(2*ee*complex(0,1)*G**2*sw)/(9.*cw*cmath.pi**2) - (ee*complex(0,1)*G**2*sw*reglog(MT/MU_R))/(3.*cw*cmath.pi**2)'},
                        order = {'QCD':2,'QED':1})

UVGC_209_108 = Coupling(name = 'UVGC_209_108',
                        value = {-1:'(complex(0,1)*G**2*xiHp)/(2.*cmath.pi**2)',0:'(complex(0,1)*G**2*xiHp)/(3.*cmath.pi**2) - (complex(0,1)*G**2*xiHp*reglog(MT/MU_R))/(2.*cmath.pi**2)'},
                        order = {'HvB':1,'QCD':2})

UVGC_210_109 = Coupling(name = 'UVGC_210_109',
                        value = {-1:'( -(ee*complex(0,1)*G**2*xiWp)/(12.*cmath.pi**2*sw*cmath.sqrt(2)) if MB else (ee*complex(0,1)*G**2*xiWp)/(24.*cmath.pi**2*sw*cmath.sqrt(2)) )',0:'( (-5*ee*complex(0,1)*G**2*xiWp)/(24.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*xiWp*reglog(MB/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2)) if MB else -(ee*complex(0,1)*G**2*xiWp)/(24.*cmath.pi**2*sw*cmath.sqrt(2)) ) + (ee*complex(0,1)*G**2*xiWp)/(24.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvB':1,'QCD':2})

UVGC_210_110 = Coupling(name = 'UVGC_210_110',
                        value = {-1:'-(ee*complex(0,1)*G**2*xiWp)/(12.*cmath.pi**2*sw*cmath.sqrt(2))',0:'-(ee*complex(0,1)*G**2*xiWp)/(6.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*xiWp*reglog(MT/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvB':1,'QCD':2})

UVGC_211_111 = Coupling(name = 'UVGC_211_111',
                        value = {-1:'(ee*complex(0,1)*G**2*gAu*xiZp)/(4.*cw*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*gVu*xiZp)/(4.*cw*cmath.pi**2*sw)',0:'(ee*complex(0,1)*G**2*gAu*xiZp)/(3.*cw*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*gVu*xiZp)/(3.*cw*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*gAu*xiZp*reglog(MT/MU_R))/(2.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*gVu*xiZp*reglog(MT/MU_R))/(2.*cw*cmath.pi**2*sw)'},
                        order = {'HvB':1,'QCD':2})

UVGC_212_112 = Coupling(name = 'UVGC_212_112',
                        value = {-1:'-(ee*complex(0,1)*G**2*gAu*xiZp)/(4.*cw*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*gVu*xiZp)/(4.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*gAu*xiZp)/(3.*cw*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*gVu*xiZp)/(3.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*gAu*xiZp*reglog(MT/MU_R))/(2.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*gVu*xiZp*reglog(MT/MU_R))/(2.*cw*cmath.pi**2*sw)'},
                        order = {'HvB':1,'QCD':2})

UVGC_213_113 = Coupling(name = 'UVGC_213_113',
                        value = {-1:'(complex(0,1)*G**2*yt)/(2.*cmath.pi**2*cmath.sqrt(2))',0:'(complex(0,1)*G**2*yt*cmath.sqrt(2))/(3.*cmath.pi**2) - (complex(0,1)*G**2*yt*reglog(MT/MU_R))/(cmath.pi**2*cmath.sqrt(2))'},
                        order = {'QCD':2,'QED':1})

UVGC_214_114 = Coupling(name = 'UVGC_214_114',
                        value = {-1:'( 0 if MB else (complex(0,1)*G**2)/(24.*cmath.pi**2) ) - (complex(0,1)*G**2)/(24.*cmath.pi**2)',0:'( (complex(0,1)*G**2*reglog(MB/MU_R))/(12.*cmath.pi**2) if MB else 0 )'},
                        order = {'QCD':2})

UVGC_214_115 = Coupling(name = 'UVGC_214_115',
                        value = {-1:'-(complex(0,1)*G**2)/(24.*cmath.pi**2)',0:'(complex(0,1)*G**2*reglog(MBP/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':2})

UVGC_214_116 = Coupling(name = 'UVGC_214_116',
                        value = {-1:'-(complex(0,1)*G**2)/(24.*cmath.pi**2)',0:'(complex(0,1)*G**2*reglog(MT/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':2})

UVGC_214_117 = Coupling(name = 'UVGC_214_117',
                        value = {-1:'-(complex(0,1)*G**2)/(24.*cmath.pi**2)',0:'(complex(0,1)*G**2*reglog(MTP/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':2})

UVGC_215_118 = Coupling(name = 'UVGC_215_118',
                        value = {-1:'( 0 if MB else -G**3/(16.*cmath.pi**2) ) + G**3/(24.*cmath.pi**2)',0:'( -(G**3*reglog(MB/MU_R))/(12.*cmath.pi**2) if MB else 0 )'},
                        order = {'QCD':3})

UVGC_215_119 = Coupling(name = 'UVGC_215_119',
                        value = {-1:'G**3/(24.*cmath.pi**2)',0:'-(G**3*reglog(MBP/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':3})

UVGC_215_120 = Coupling(name = 'UVGC_215_120',
                        value = {-1:'-G**3/(48.*cmath.pi**2)'},
                        order = {'QCD':3})

UVGC_215_121 = Coupling(name = 'UVGC_215_121',
                        value = {-1:'G**3/(24.*cmath.pi**2)',0:'-(G**3*reglog(MT/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':3})

UVGC_215_122 = Coupling(name = 'UVGC_215_122',
                        value = {-1:'G**3/(24.*cmath.pi**2)',0:'-(G**3*reglog(MTP/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':3})

UVGC_216_123 = Coupling(name = 'UVGC_216_123',
                        value = {-1:'( 0 if MB else -(complex(0,1)*G**4)/(12.*cmath.pi**2) ) + (complex(0,1)*G**4)/(12.*cmath.pi**2)',0:'( -(complex(0,1)*G**4*reglog(MB/MU_R))/(12.*cmath.pi**2) if MB else 0 )'},
                        order = {'QCD':4})

UVGC_216_124 = Coupling(name = 'UVGC_216_124',
                        value = {-1:'(complex(0,1)*G**4)/(12.*cmath.pi**2)',0:'-(complex(0,1)*G**4*reglog(MBP/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_216_125 = Coupling(name = 'UVGC_216_125',
                        value = {-1:'(147*complex(0,1)*G**4)/(128.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_216_126 = Coupling(name = 'UVGC_216_126',
                        value = {-1:'(3*complex(0,1)*G**4)/(128.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_216_127 = Coupling(name = 'UVGC_216_127',
                        value = {-1:'(complex(0,1)*G**4)/(12.*cmath.pi**2)',0:'-(complex(0,1)*G**4*reglog(MT/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_216_128 = Coupling(name = 'UVGC_216_128',
                        value = {-1:'(complex(0,1)*G**4)/(12.*cmath.pi**2)',0:'-(complex(0,1)*G**4*reglog(MTP/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_217_129 = Coupling(name = 'UVGC_217_129',
                        value = {-1:'(147*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_217_130 = Coupling(name = 'UVGC_217_130',
                        value = {-1:'(21*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_218_131 = Coupling(name = 'UVGC_218_131',
                        value = {-1:'( 0 if MB else -(complex(0,1)*G**4)/(12.*cmath.pi**2) )',0:'( -(complex(0,1)*G**4*reglog(MB/MU_R))/(12.*cmath.pi**2) if MB else 0 )'},
                        order = {'QCD':4})

UVGC_218_132 = Coupling(name = 'UVGC_218_132',
                        value = {0:'-(complex(0,1)*G**4*reglog(MBP/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_218_133 = Coupling(name = 'UVGC_218_133',
                        value = {-1:'-(complex(0,1)*G**4)/(12.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_218_134 = Coupling(name = 'UVGC_218_134',
                        value = {-1:'(523*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_218_135 = Coupling(name = 'UVGC_218_135',
                        value = {-1:'(13*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_218_136 = Coupling(name = 'UVGC_218_136',
                        value = {0:'-(complex(0,1)*G**4*reglog(MT/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_218_137 = Coupling(name = 'UVGC_218_137',
                        value = {0:'-(complex(0,1)*G**4*reglog(MTP/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_219_138 = Coupling(name = 'UVGC_219_138',
                        value = {-1:'( 0 if MB else (complex(0,1)*G**4)/(12.*cmath.pi**2) ) - (complex(0,1)*G**4)/(24.*cmath.pi**2)',0:'( (complex(0,1)*G**4*reglog(MB/MU_R))/(12.*cmath.pi**2) if MB else 0 )'},
                        order = {'QCD':4})

UVGC_219_139 = Coupling(name = 'UVGC_219_139',
                        value = {-1:'-(complex(0,1)*G**4)/(24.*cmath.pi**2)',0:'(complex(0,1)*G**4*reglog(MBP/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_219_140 = Coupling(name = 'UVGC_219_140',
                        value = {-1:'(complex(0,1)*G**4)/(24.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_219_141 = Coupling(name = 'UVGC_219_141',
                        value = {-1:'(-341*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_219_142 = Coupling(name = 'UVGC_219_142',
                        value = {-1:'(-11*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_219_143 = Coupling(name = 'UVGC_219_143',
                        value = {-1:'-(complex(0,1)*G**4)/(24.*cmath.pi**2)',0:'(complex(0,1)*G**4*reglog(MT/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_219_144 = Coupling(name = 'UVGC_219_144',
                        value = {-1:'-(complex(0,1)*G**4)/(24.*cmath.pi**2)',0:'(complex(0,1)*G**4*reglog(MTP/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_220_145 = Coupling(name = 'UVGC_220_145',
                        value = {-1:'(-83*complex(0,1)*G**4)/(128.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_220_146 = Coupling(name = 'UVGC_220_146',
                        value = {-1:'(-5*complex(0,1)*G**4)/(128.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_221_147 = Coupling(name = 'UVGC_221_147',
                        value = {-1:'( 0 if MB else (complex(0,1)*G**4)/(12.*cmath.pi**2) )',0:'( (complex(0,1)*G**4*reglog(MB/MU_R))/(12.*cmath.pi**2) if MB else 0 )'},
                        order = {'QCD':4})

UVGC_221_148 = Coupling(name = 'UVGC_221_148',
                        value = {0:'(complex(0,1)*G**4*reglog(MBP/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_221_149 = Coupling(name = 'UVGC_221_149',
                        value = {-1:'(complex(0,1)*G**4)/(12.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_221_150 = Coupling(name = 'UVGC_221_150',
                        value = {-1:'(-85*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_221_151 = Coupling(name = 'UVGC_221_151',
                        value = {-1:'(-19*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_221_152 = Coupling(name = 'UVGC_221_152',
                        value = {0:'(complex(0,1)*G**4*reglog(MT/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_221_153 = Coupling(name = 'UVGC_221_153',
                        value = {0:'(complex(0,1)*G**4*reglog(MTP/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_222_154 = Coupling(name = 'UVGC_222_154',
                        value = {-1:'(complex(0,1)*G**2)/(4.*cmath.pi**2)',0:'(complex(0,1)*G**2)/(3.*cmath.pi**2) - (complex(0,1)*G**2*reglog(MTP/MU_R))/(2.*cmath.pi**2)'},
                        order = {'QCD':2})

UVGC_223_155 = Coupling(name = 'UVGC_223_155',
                        value = {0:'(-2*ee*complex(0,1)*G**2)/(9.*cmath.pi**2) + (ee*complex(0,1)*G**2*reglog(MTP/MU_R))/(3.*cmath.pi**2)'},
                        order = {'QCD':2,'QED':1})

UVGC_224_156 = Coupling(name = 'UVGC_224_156',
                        value = {0:'-(complex(0,1)*G**3)/(3.*cmath.pi**2) + (complex(0,1)*G**3*reglog(MTP/MU_R))/(2.*cmath.pi**2)'},
                        order = {'QCD':3})

UVGC_225_157 = Coupling(name = 'UVGC_225_157',
                        value = {-1:'(complex(0,1)*G**2*kpTHL1)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpTHL1)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpTHL1*reglog(MTP/MU_R))/(4.*cmath.pi**2)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_225_158 = Coupling(name = 'UVGC_225_158',
                        value = {-1:'-(complex(0,1)*G**2*kpTHL1)/(24.*cmath.pi**2)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_225_159 = Coupling(name = 'UVGC_225_159',
                        value = {-1:'(complex(0,1)*G**2*kpTHL1)/(3.*cmath.pi**2)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_226_160 = Coupling(name = 'UVGC_226_160',
                        value = {-1:'-(complex(0,1)*G**2*kpTHL2)/(24.*cmath.pi**2)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_226_161 = Coupling(name = 'UVGC_226_161',
                        value = {-1:'(complex(0,1)*G**2*kpTHL2)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpTHL2)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpTHL2*reglog(MTP/MU_R))/(4.*cmath.pi**2)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_226_162 = Coupling(name = 'UVGC_226_162',
                        value = {-1:'(complex(0,1)*G**2*kpTHL2)/(3.*cmath.pi**2)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_227_163 = Coupling(name = 'UVGC_227_163',
                        value = {-1:'(complex(0,1)*G**2*kpTHL3)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpTHL3)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpTHL3*reglog(MT/MU_R))/(4.*cmath.pi**2)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_227_164 = Coupling(name = 'UVGC_227_164',
                        value = {-1:'(complex(0,1)*G**2*kpTHL3)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpTHL3)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpTHL3*reglog(MTP/MU_R))/(4.*cmath.pi**2)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_227_165 = Coupling(name = 'UVGC_227_165',
                        value = {-1:'(complex(0,1)*G**2*kpTHL3)/(3.*cmath.pi**2)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_228_166 = Coupling(name = 'UVGC_228_166',
                        value = {-1:'(complex(0,1)*G**2*kpTHpL1)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpTHpL1)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpTHpL1*reglog(MTP/MU_R))/(4.*cmath.pi**2)'},
                        order = {'HvB':1,'QCD':2})

UVGC_228_167 = Coupling(name = 'UVGC_228_167',
                        value = {-1:'-(complex(0,1)*G**2*kpTHpL1)/(24.*cmath.pi**2)'},
                        order = {'HvB':1,'QCD':2})

UVGC_228_168 = Coupling(name = 'UVGC_228_168',
                        value = {-1:'(complex(0,1)*G**2*kpTHpL1)/(3.*cmath.pi**2)'},
                        order = {'HvB':1,'QCD':2})

UVGC_229_169 = Coupling(name = 'UVGC_229_169',
                        value = {-1:'-(complex(0,1)*G**2*kpTHpL2)/(24.*cmath.pi**2)'},
                        order = {'HvB':1,'QCD':2})

UVGC_229_170 = Coupling(name = 'UVGC_229_170',
                        value = {-1:'(complex(0,1)*G**2*kpTHpL2)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpTHpL2)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpTHpL2*reglog(MTP/MU_R))/(4.*cmath.pi**2)'},
                        order = {'HvB':1,'QCD':2})

UVGC_229_171 = Coupling(name = 'UVGC_229_171',
                        value = {-1:'(complex(0,1)*G**2*kpTHpL2)/(3.*cmath.pi**2)'},
                        order = {'HvB':1,'QCD':2})

UVGC_230_172 = Coupling(name = 'UVGC_230_172',
                        value = {-1:'(complex(0,1)*G**2*kpTHpL3)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpTHpL3)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpTHpL3*reglog(MT/MU_R))/(4.*cmath.pi**2)'},
                        order = {'HvB':1,'QCD':2})

UVGC_230_173 = Coupling(name = 'UVGC_230_173',
                        value = {-1:'(complex(0,1)*G**2*kpTHpL3)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpTHpL3)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpTHpL3*reglog(MTP/MU_R))/(4.*cmath.pi**2)'},
                        order = {'HvB':1,'QCD':2})

UVGC_230_174 = Coupling(name = 'UVGC_230_174',
                        value = {-1:'(complex(0,1)*G**2*kpTHpL3)/(3.*cmath.pi**2)'},
                        order = {'HvB':1,'QCD':2})

UVGC_231_175 = Coupling(name = 'UVGC_231_175',
                        value = {-1:'(complex(0,1)*G**2*kpTHpR3)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpTHpR3)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpTHpR3*reglog(MT/MU_R))/(4.*cmath.pi**2)'},
                        order = {'HvB':1,'QCD':2})

UVGC_231_176 = Coupling(name = 'UVGC_231_176',
                        value = {-1:'(complex(0,1)*G**2*kpTHpR3)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpTHpR3)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpTHpR3*reglog(MTP/MU_R))/(4.*cmath.pi**2)'},
                        order = {'HvB':1,'QCD':2})

UVGC_231_177 = Coupling(name = 'UVGC_231_177',
                        value = {-1:'(complex(0,1)*G**2*kpTHpR3)/(3.*cmath.pi**2)'},
                        order = {'HvB':1,'QCD':2})

UVGC_232_178 = Coupling(name = 'UVGC_232_178',
                        value = {-1:'(complex(0,1)*G**2*kpTHR3)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpTHR3)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpTHR3*reglog(MT/MU_R))/(4.*cmath.pi**2)'},
                        order = {'HvB':1,'QCD':2})

UVGC_232_179 = Coupling(name = 'UVGC_232_179',
                        value = {-1:'(complex(0,1)*G**2*kpTHR3)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpTHR3)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpTHR3*reglog(MTP/MU_R))/(4.*cmath.pi**2)'},
                        order = {'HvB':1,'QCD':2})

UVGC_232_180 = Coupling(name = 'UVGC_232_180',
                        value = {-1:'(complex(0,1)*G**2*kpTHR3)/(3.*cmath.pi**2)'},
                        order = {'HvB':1,'QCD':2})

UVGC_233_181 = Coupling(name = 'UVGC_233_181',
                        value = {-1:'(complex(0,1)*G**2*MTP)/(2.*cmath.pi**2)',0:'(2*complex(0,1)*G**2*MTP)/(3.*cmath.pi**2) - (complex(0,1)*G**2*MTP*reglog(MTP/MU_R))/cmath.pi**2'},
                        order = {'QCD':2})

UVGC_234_182 = Coupling(name = 'UVGC_234_182',
                        value = {-1:'(ee*complex(0,1)*G**2*kpTWL1)/(24.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_234_183 = Coupling(name = 'UVGC_234_183',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTWL1)/(12.*cmath.pi**2*sw*cmath.sqrt(2))',0:'-(ee*complex(0,1)*G**2*kpTWL1)/(6.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*kpTWL1*reglog(MTP/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_234_184 = Coupling(name = 'UVGC_234_184',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTWL1)/(12.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_235_185 = Coupling(name = 'UVGC_235_185',
                        value = {-1:'(ee*complex(0,1)*G**2*kpTWL2)/(24.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_235_186 = Coupling(name = 'UVGC_235_186',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTWL2)/(12.*cmath.pi**2*sw*cmath.sqrt(2))',0:'-(ee*complex(0,1)*G**2*kpTWL2)/(6.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*kpTWL2*reglog(MTP/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_235_187 = Coupling(name = 'UVGC_235_187',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTWL2)/(12.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_236_188 = Coupling(name = 'UVGC_236_188',
                        value = {-1:'( -(ee*complex(0,1)*G**2*kpTWL3)/(12.*cmath.pi**2*sw*cmath.sqrt(2)) if MB else (ee*complex(0,1)*G**2*kpTWL3)/(24.*cmath.pi**2*sw*cmath.sqrt(2)) )',0:'( (-5*ee*complex(0,1)*G**2*kpTWL3)/(24.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*kpTWL3*reglog(MB/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2)) if MB else -(ee*complex(0,1)*G**2*kpTWL3)/(24.*cmath.pi**2*sw*cmath.sqrt(2)) ) + (ee*complex(0,1)*G**2*kpTWL3)/(24.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_236_189 = Coupling(name = 'UVGC_236_189',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTWL3)/(12.*cmath.pi**2*sw*cmath.sqrt(2))',0:'-(ee*complex(0,1)*G**2*kpTWL3)/(6.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*kpTWL3*reglog(MTP/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_236_190 = Coupling(name = 'UVGC_236_190',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTWL3)/(12.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_237_191 = Coupling(name = 'UVGC_237_191',
                        value = {-1:'(ee*complex(0,1)*G**2*kpTWpL1)/(24.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_237_192 = Coupling(name = 'UVGC_237_192',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTWpL1)/(12.*cmath.pi**2*sw*cmath.sqrt(2))',0:'-(ee*complex(0,1)*G**2*kpTWpL1)/(6.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*kpTWpL1*reglog(MTP/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_237_193 = Coupling(name = 'UVGC_237_193',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTWpL1)/(12.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_238_194 = Coupling(name = 'UVGC_238_194',
                        value = {-1:'(ee*complex(0,1)*G**2*kpTWpL2)/(24.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_238_195 = Coupling(name = 'UVGC_238_195',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTWpL2)/(12.*cmath.pi**2*sw*cmath.sqrt(2))',0:'-(ee*complex(0,1)*G**2*kpTWpL2)/(6.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*kpTWpL2*reglog(MTP/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_238_196 = Coupling(name = 'UVGC_238_196',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTWpL2)/(12.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_239_197 = Coupling(name = 'UVGC_239_197',
                        value = {-1:'( -(ee*complex(0,1)*G**2*kpTWpL3)/(12.*cmath.pi**2*sw*cmath.sqrt(2)) if MB else (ee*complex(0,1)*G**2*kpTWpL3)/(24.*cmath.pi**2*sw*cmath.sqrt(2)) )',0:'( (-5*ee*complex(0,1)*G**2*kpTWpL3)/(24.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*kpTWpL3*reglog(MB/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2)) if MB else -(ee*complex(0,1)*G**2*kpTWpL3)/(24.*cmath.pi**2*sw*cmath.sqrt(2)) ) + (ee*complex(0,1)*G**2*kpTWpL3)/(24.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_239_198 = Coupling(name = 'UVGC_239_198',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTWpL3)/(12.*cmath.pi**2*sw*cmath.sqrt(2))',0:'-(ee*complex(0,1)*G**2*kpTWpL3)/(6.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*kpTWpL3*reglog(MTP/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_239_199 = Coupling(name = 'UVGC_239_199',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTWpL3)/(12.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_240_200 = Coupling(name = 'UVGC_240_200',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZL1)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpTZL1)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpTZL1*reglog(MTP/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_240_201 = Coupling(name = 'UVGC_240_201',
                        value = {-1:'(ee*complex(0,1)*G**2*kpTZL1)/(48.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_240_202 = Coupling(name = 'UVGC_240_202',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZL1)/(24.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_241_203 = Coupling(name = 'UVGC_241_203',
                        value = {-1:'(ee*complex(0,1)*G**2*kpTZL2)/(48.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_241_204 = Coupling(name = 'UVGC_241_204',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZL2)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpTZL2)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpTZL2*reglog(MTP/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_241_205 = Coupling(name = 'UVGC_241_205',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZL2)/(24.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_242_206 = Coupling(name = 'UVGC_242_206',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZL3)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpTZL3)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpTZL3*reglog(MT/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_242_207 = Coupling(name = 'UVGC_242_207',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZL3)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpTZL3)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpTZL3*reglog(MTP/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_242_208 = Coupling(name = 'UVGC_242_208',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZL3)/(24.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_243_209 = Coupling(name = 'UVGC_243_209',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZpL1)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpTZpL1)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpTZpL1*reglog(MTP/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_243_210 = Coupling(name = 'UVGC_243_210',
                        value = {-1:'(ee*complex(0,1)*G**2*kpTZpL1)/(48.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_243_211 = Coupling(name = 'UVGC_243_211',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZpL1)/(24.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_244_212 = Coupling(name = 'UVGC_244_212',
                        value = {-1:'(ee*complex(0,1)*G**2*kpTZpL2)/(48.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_244_213 = Coupling(name = 'UVGC_244_213',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZpL2)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpTZpL2)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpTZpL2*reglog(MTP/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_244_214 = Coupling(name = 'UVGC_244_214',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZpL2)/(24.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_245_215 = Coupling(name = 'UVGC_245_215',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZpL3)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpTZpL3)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpTZpL3*reglog(MT/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_245_216 = Coupling(name = 'UVGC_245_216',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZpL3)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpTZpL3)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpTZpL3*reglog(MTP/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_245_217 = Coupling(name = 'UVGC_245_217',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZpL3)/(24.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_246_218 = Coupling(name = 'UVGC_246_218',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZpR1)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpTZpR1)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpTZpR1*reglog(MTP/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_246_219 = Coupling(name = 'UVGC_246_219',
                        value = {-1:'(ee*complex(0,1)*G**2*kpTZpR1)/(48.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_246_220 = Coupling(name = 'UVGC_246_220',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZpR1)/(24.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_247_221 = Coupling(name = 'UVGC_247_221',
                        value = {-1:'(ee*complex(0,1)*G**2*kpTZpR2)/(48.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_247_222 = Coupling(name = 'UVGC_247_222',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZpR2)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpTZpR2)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpTZpR2*reglog(MTP/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_247_223 = Coupling(name = 'UVGC_247_223',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZpR2)/(24.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_248_224 = Coupling(name = 'UVGC_248_224',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZpR3)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpTZpR3)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpTZpR3*reglog(MT/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_248_225 = Coupling(name = 'UVGC_248_225',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZpR3)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpTZpR3)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpTZpR3*reglog(MTP/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_248_226 = Coupling(name = 'UVGC_248_226',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZpR3)/(24.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_249_227 = Coupling(name = 'UVGC_249_227',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZR1)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpTZR1)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpTZR1*reglog(MTP/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_249_228 = Coupling(name = 'UVGC_249_228',
                        value = {-1:'(ee*complex(0,1)*G**2*kpTZR1)/(48.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_249_229 = Coupling(name = 'UVGC_249_229',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZR1)/(24.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_250_230 = Coupling(name = 'UVGC_250_230',
                        value = {-1:'(ee*complex(0,1)*G**2*kpTZR2)/(48.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_250_231 = Coupling(name = 'UVGC_250_231',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZR2)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpTZR2)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpTZR2*reglog(MTP/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_250_232 = Coupling(name = 'UVGC_250_232',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZR2)/(24.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_251_233 = Coupling(name = 'UVGC_251_233',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZR3)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpTZR3)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpTZR3*reglog(MT/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_251_234 = Coupling(name = 'UVGC_251_234',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZR3)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpTZR3)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpTZR3*reglog(MTP/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_251_235 = Coupling(name = 'UVGC_251_235',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZR3)/(24.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

