# This file was automatically created by FeynRules 2.3.47
# Mathematica version: 9.0 for Linux x86 (64-bit) (November 20, 2012)
# Date: Tue 30 May 2023 20:04:56


from object_library import all_couplings, Coupling

from function_library import complexconjugate, re, im, csc, sec, acsc, asec, cot



R2GC_100_1 = Coupling(name = 'R2GC_100_1',
                      value = '-(ee**2*complex(0,1)*G**2*gVd*xiZp)/(72.*cw*cmath.pi**2*sw)',
                      order = {'HvB':1,'QCD':2,'QED':1})

R2GC_100_2 = Coupling(name = 'R2GC_100_2',
                      value = '(ee**2*complex(0,1)*G**2*gVu*xiZp)/(36.*cw*cmath.pi**2*sw)',
                      order = {'HvB':1,'QCD':2,'QED':1})

R2GC_101_3 = Coupling(name = 'R2GC_101_3',
                      value = '(ee*complex(0,1)*G**3*gVd*xiZp)/(48.*cw*cmath.pi**2*sw)',
                      order = {'HvB':1,'QCD':3})

R2GC_101_4 = Coupling(name = 'R2GC_101_4',
                      value = '(ee*complex(0,1)*G**3*gVu*xiZp)/(48.*cw*cmath.pi**2*sw)',
                      order = {'HvB':1,'QCD':3})

R2GC_102_5 = Coupling(name = 'R2GC_102_5',
                      value = '(cw*ee*complex(0,1)*G**2)/(12.*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*sw)/(36.*cw*cmath.pi**2)',
                      order = {'QCD':2,'QED':1})

R2GC_103_6 = Coupling(name = 'R2GC_103_6',
                      value = '-(ee*complex(0,1)*G**2*gAd*xiZp)/(6.*cw*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*gVd*xiZp)/(6.*cw*cmath.pi**2*sw)',
                      order = {'HvB':1,'QCD':2})

R2GC_104_7 = Coupling(name = 'R2GC_104_7',
                      value = '(ee*complex(0,1)*G**2*gAd*xiZp)/(6.*cw*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*gVd*xiZp)/(6.*cw*cmath.pi**2*sw)',
                      order = {'HvB':1,'QCD':2})

R2GC_105_8 = Coupling(name = 'R2GC_105_8',
                      value = '-(cw*ee*complex(0,1)*G**2)/(12.*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*sw)/(36.*cw*cmath.pi**2)',
                      order = {'QCD':2,'QED':1})

R2GC_106_9 = Coupling(name = 'R2GC_106_9',
                      value = '-(ee*complex(0,1)*G**2*gAu*xiZp)/(6.*cw*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*gVu*xiZp)/(6.*cw*cmath.pi**2*sw)',
                      order = {'HvB':1,'QCD':2})

R2GC_107_10 = Coupling(name = 'R2GC_107_10',
                       value = '(ee*complex(0,1)*G**2*gAu*xiZp)/(6.*cw*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*gVu*xiZp)/(6.*cw*cmath.pi**2*sw)',
                       order = {'HvB':1,'QCD':2})

R2GC_110_11 = Coupling(name = 'R2GC_110_11',
                       value = '(ee**2*complex(0,1)*G**2)/(96.*cmath.pi**2*sw**2)',
                       order = {'QCD':2,'QED':2})

R2GC_110_12 = Coupling(name = 'R2GC_110_12',
                       value = '(ee**2*complex(0,1)*G**2*kpTWL3**2)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_110_13 = Coupling(name = 'R2GC_110_13',
                       value = '(ee**2*complex(0,1)*G**2*kpBWL2**2)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_110_14 = Coupling(name = 'R2GC_110_14',
                       value = '(ee**2*complex(0,1)*G**2*kpBWL3**2)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_110_15 = Coupling(name = 'R2GC_110_15',
                       value = '(ee**2*complex(0,1)*G**2*kpBWL1**2)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_110_16 = Coupling(name = 'R2GC_110_16',
                       value = '(ee**2*complex(0,1)*G**2*kpTWL1**2)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_110_17 = Coupling(name = 'R2GC_110_17',
                       value = '(ee**2*complex(0,1)*G**2*kpTWL2**2)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_111_18 = Coupling(name = 'R2GC_111_18',
                       value = '(ee**2*complex(0,1)*G**2*xiWp)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvB':1,'QCD':2,'QED':1})

R2GC_111_19 = Coupling(name = 'R2GC_111_19',
                       value = '(ee**2*complex(0,1)*G**2*kpTWL3*kpTWpL3)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_111_20 = Coupling(name = 'R2GC_111_20',
                       value = '(ee**2*complex(0,1)*G**2*kpBWL2*kpBWpL2)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_111_21 = Coupling(name = 'R2GC_111_21',
                       value = '(ee**2*complex(0,1)*G**2*kpBWL3*kpBWpL3)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_111_22 = Coupling(name = 'R2GC_111_22',
                       value = '(ee**2*complex(0,1)*G**2*kpBWL1*kpBWpL1)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_111_23 = Coupling(name = 'R2GC_111_23',
                       value = '(ee**2*complex(0,1)*G**2*kpTWL1*kpTWpL1)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_111_24 = Coupling(name = 'R2GC_111_24',
                       value = '(ee**2*complex(0,1)*G**2*kpTWL2*kpTWpL2)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_112_25 = Coupling(name = 'R2GC_112_25',
                       value = '(ee**2*complex(0,1)*G**2*xiWp**2)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_112_26 = Coupling(name = 'R2GC_112_26',
                       value = '(ee**2*complex(0,1)*G**2*kpTWpL3**2)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_112_27 = Coupling(name = 'R2GC_112_27',
                       value = '(ee**2*complex(0,1)*G**2*kpBWpL2**2)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_112_28 = Coupling(name = 'R2GC_112_28',
                       value = '(ee**2*complex(0,1)*G**2*kpBWpL3**2)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_112_29 = Coupling(name = 'R2GC_112_29',
                       value = '(ee**2*complex(0,1)*G**2*kpBWpL1**2)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_112_30 = Coupling(name = 'R2GC_112_30',
                       value = '(ee**2*complex(0,1)*G**2*kpTWpL1**2)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_112_31 = Coupling(name = 'R2GC_112_31',
                       value = '(ee**2*complex(0,1)*G**2*kpTWpL2**2)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_116_32 = Coupling(name = 'R2GC_116_32',
                       value = '-(complex(0,1)*G**2*yt**2)/(16.*cmath.pi**2)',
                       order = {'QCD':2,'QED':2})

R2GC_116_33 = Coupling(name = 'R2GC_116_33',
                       value = '-(complex(0,1)*G**2*kpBHL3**2)/(8.*cmath.pi**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_116_34 = Coupling(name = 'R2GC_116_34',
                       value = '-(complex(0,1)*G**2*kpBHL1**2)/(8.*cmath.pi**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_116_35 = Coupling(name = 'R2GC_116_35',
                       value = '-(complex(0,1)*G**2*kpBHL2**2)/(8.*cmath.pi**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_116_36 = Coupling(name = 'R2GC_116_36',
                       value = '-(complex(0,1)*G**2*kpTHL2**2)/(8.*cmath.pi**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_116_37 = Coupling(name = 'R2GC_116_37',
                       value = '-(complex(0,1)*G**2*kpTHL3**2)/(8.*cmath.pi**2) - (complex(0,1)*G**2*kpTHR3**2)/(8.*cmath.pi**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_116_38 = Coupling(name = 'R2GC_116_38',
                       value = '-(complex(0,1)*G**2*kpTHL1**2)/(8.*cmath.pi**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_117_39 = Coupling(name = 'R2GC_117_39',
                       value = '-(complex(0,1)*G**2*xiHp*yt)/(8.*cmath.pi**2*cmath.sqrt(2))',
                       order = {'HvB':1,'QCD':2,'QED':1})

R2GC_117_40 = Coupling(name = 'R2GC_117_40',
                       value = '-(complex(0,1)*G**2*kpBHL3*kpBHpL3)/(8.*cmath.pi**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_117_41 = Coupling(name = 'R2GC_117_41',
                       value = '-(complex(0,1)*G**2*kpBHL1*kpBHpL1)/(8.*cmath.pi**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_117_42 = Coupling(name = 'R2GC_117_42',
                       value = '-(complex(0,1)*G**2*kpBHL2*kpBHpL2)/(8.*cmath.pi**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_117_43 = Coupling(name = 'R2GC_117_43',
                       value = '-(complex(0,1)*G**2*kpTHL2*kpTHpL2)/(8.*cmath.pi**2)',
                       order = {'HvB':1,'HvQ':1,'QCD':2})

R2GC_117_44 = Coupling(name = 'R2GC_117_44',
                       value = '-(complex(0,1)*G**2*kpTHL3*kpTHpL3)/(8.*cmath.pi**2) - (complex(0,1)*G**2*kpTHpR3*kpTHR3)/(8.*cmath.pi**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_117_45 = Coupling(name = 'R2GC_117_45',
                       value = '-(complex(0,1)*G**2*kpTHL1*kpTHpL1)/(8.*cmath.pi**2)',
                       order = {'HvB':1,'HvQ':1,'QCD':2})

R2GC_118_46 = Coupling(name = 'R2GC_118_46',
                       value = '-(complex(0,1)*G**2*xiHp**2)/(8.*cmath.pi**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_118_47 = Coupling(name = 'R2GC_118_47',
                       value = '-(complex(0,1)*G**2*kpBHpL3**2)/(8.*cmath.pi**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_118_48 = Coupling(name = 'R2GC_118_48',
                       value = '-(complex(0,1)*G**2*kpBHpL1**2)/(8.*cmath.pi**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_118_49 = Coupling(name = 'R2GC_118_49',
                       value = '-(complex(0,1)*G**2*kpBHpL2**2)/(8.*cmath.pi**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_118_50 = Coupling(name = 'R2GC_118_50',
                       value = '-(complex(0,1)*G**2*kpTHpL2**2)/(8.*cmath.pi**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_118_51 = Coupling(name = 'R2GC_118_51',
                       value = '-(complex(0,1)*G**2*kpTHpL3**2)/(8.*cmath.pi**2) - (complex(0,1)*G**2*kpTHpR3**2)/(8.*cmath.pi**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_118_52 = Coupling(name = 'R2GC_118_52',
                       value = '-(complex(0,1)*G**2*kpTHpL1**2)/(8.*cmath.pi**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_119_53 = Coupling(name = 'R2GC_119_53',
                       value = '(ee**2*complex(0,1)*G**2)/(288.*cmath.pi**2) + (cw**2*ee**2*complex(0,1)*G**2)/(192.*cmath.pi**2*sw**2) + (5*ee**2*complex(0,1)*G**2*sw**2)/(1728.*cw**2*cmath.pi**2)',
                       order = {'QCD':2,'QED':2})

R2GC_119_54 = Coupling(name = 'R2GC_119_54',
                       value = '-(ee**2*complex(0,1)*G**2)/(288.*cmath.pi**2) + (cw**2*ee**2*complex(0,1)*G**2)/(192.*cmath.pi**2*sw**2) + (17*ee**2*complex(0,1)*G**2*sw**2)/(1728.*cw**2*cmath.pi**2)',
                       order = {'QCD':2,'QED':2})

R2GC_119_55 = Coupling(name = 'R2GC_119_55',
                       value = '(ee**2*complex(0,1)*G**2*kpBZL3**2)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_119_56 = Coupling(name = 'R2GC_119_56',
                       value = '(ee**2*complex(0,1)*G**2*kpBZL1**2)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_119_57 = Coupling(name = 'R2GC_119_57',
                       value = '(ee**2*complex(0,1)*G**2*kpBZL2**2)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_119_58 = Coupling(name = 'R2GC_119_58',
                       value = '(ee**2*complex(0,1)*G**2*kpTZL2**2)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_119_59 = Coupling(name = 'R2GC_119_59',
                       value = '(ee**2*complex(0,1)*G**2*kpTZL3**2)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_119_60 = Coupling(name = 'R2GC_119_60',
                       value = '(ee**2*complex(0,1)*G**2*kpTZL1**2)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_120_61 = Coupling(name = 'R2GC_120_61',
                       value = '(ee**2*complex(0,1)*G**2*gAd*xiZp)/(96.*cw**2*cmath.pi**2) + (ee**2*complex(0,1)*G**2*gVd*xiZp)/(288.*cw**2*cmath.pi**2) + (ee**2*complex(0,1)*G**2*gAd*xiZp)/(96.*cmath.pi**2*sw**2) - (ee**2*complex(0,1)*G**2*gVd*xiZp)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvB':1,'QCD':2,'QED':1})

R2GC_120_62 = Coupling(name = 'R2GC_120_62',
                       value = '-(ee**2*complex(0,1)*G**2*gAu*xiZp)/(96.*cw**2*cmath.pi**2) - (5*ee**2*complex(0,1)*G**2*gVu*xiZp)/(288.*cw**2*cmath.pi**2) - (ee**2*complex(0,1)*G**2*gAu*xiZp)/(96.*cmath.pi**2*sw**2) + (ee**2*complex(0,1)*G**2*gVu*xiZp)/(96.*cmath.pi**2*sw**2)',
                       order = {'HvB':1,'QCD':2,'QED':1})

R2GC_120_63 = Coupling(name = 'R2GC_120_63',
                       value = '(ee**2*complex(0,1)*G**2*kpBZL3*kpBZpL3)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_120_64 = Coupling(name = 'R2GC_120_64',
                       value = '(ee**2*complex(0,1)*G**2*kpBZL1*kpBZpL1)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_120_65 = Coupling(name = 'R2GC_120_65',
                       value = '(ee**2*complex(0,1)*G**2*kpBZL2*kpBZpL2)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_120_66 = Coupling(name = 'R2GC_120_66',
                       value = '(ee**2*complex(0,1)*G**2*kpTZL2*kpTZpL2)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_120_67 = Coupling(name = 'R2GC_120_67',
                       value = '(ee**2*complex(0,1)*G**2*kpTZL3*kpTZpL3)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_120_68 = Coupling(name = 'R2GC_120_68',
                       value = '(ee**2*complex(0,1)*G**2*kpTZL1*kpTZpL1)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_121_69 = Coupling(name = 'R2GC_121_69',
                       value = '(ee**2*complex(0,1)*G**2*gAd**2*xiZp**2)/(24.*cw**2*cmath.pi**2*sw**2) + (ee**2*complex(0,1)*G**2*gVd**2*xiZp**2)/(24.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_121_70 = Coupling(name = 'R2GC_121_70',
                       value = '(ee**2*complex(0,1)*G**2*gAu**2*xiZp**2)/(24.*cw**2*cmath.pi**2*sw**2) + (ee**2*complex(0,1)*G**2*gVu**2*xiZp**2)/(24.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvB':2,'QCD':2})

R2GC_121_71 = Coupling(name = 'R2GC_121_71',
                       value = '(ee**2*complex(0,1)*G**2*kpBZpL3**2)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_121_72 = Coupling(name = 'R2GC_121_72',
                       value = '(ee**2*complex(0,1)*G**2*kpBZpL1**2)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_121_73 = Coupling(name = 'R2GC_121_73',
                       value = '(ee**2*complex(0,1)*G**2*kpBZpL2**2)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_121_74 = Coupling(name = 'R2GC_121_74',
                       value = '(ee**2*complex(0,1)*G**2*kpTZpL2**2)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_121_75 = Coupling(name = 'R2GC_121_75',
                       value = '(ee**2*complex(0,1)*G**2*kpTZpL3**2)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_121_76 = Coupling(name = 'R2GC_121_76',
                       value = '(ee**2*complex(0,1)*G**2*kpTZpL1**2)/(96.*cw**2*cmath.pi**2*sw**2)',
                       order = {'HvQ':2,'QCD':2})

R2GC_139_77 = Coupling(name = 'R2GC_139_77',
                       value = '-G**4/(192.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_139_78 = Coupling(name = 'R2GC_139_78',
                       value = 'G**4/(64.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_140_79 = Coupling(name = 'R2GC_140_79',
                       value = '-(complex(0,1)*G**4)/(192.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_140_80 = Coupling(name = 'R2GC_140_80',
                       value = '(complex(0,1)*G**4)/(64.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_141_81 = Coupling(name = 'R2GC_141_81',
                       value = '(complex(0,1)*G**4)/(192.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_141_82 = Coupling(name = 'R2GC_141_82',
                       value = '-(complex(0,1)*G**4)/(64.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_142_83 = Coupling(name = 'R2GC_142_83',
                       value = '-(complex(0,1)*G**4)/(48.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_143_84 = Coupling(name = 'R2GC_143_84',
                       value = '(complex(0,1)*G**4)/(288.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_143_85 = Coupling(name = 'R2GC_143_85',
                       value = '-(complex(0,1)*G**4)/(32.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_144_86 = Coupling(name = 'R2GC_144_86',
                       value = '-(complex(0,1)*G**4)/(16.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_144_87 = Coupling(name = 'R2GC_144_87',
                       value = '(complex(0,1)*G**4)/(4.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_145_88 = Coupling(name = 'R2GC_145_88',
                       value = '(-3*complex(0,1)*G**4)/(64.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_145_89 = Coupling(name = 'R2GC_145_89',
                       value = '(-23*complex(0,1)*G**4)/(64.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_146_90 = Coupling(name = 'R2GC_146_90',
                       value = '(complex(0,1)*G**2)/(12.*cmath.pi**2)',
                       order = {'QCD':2})

R2GC_147_91 = Coupling(name = 'R2GC_147_91',
                       value = '(ee*complex(0,1)*G**2)/(18.*cmath.pi**2)',
                       order = {'QCD':2,'QED':1})

R2GC_149_92 = Coupling(name = 'R2GC_149_92',
                       value = '-(complex(0,1)*G**3)/(6.*cmath.pi**2)',
                       order = {'QCD':3})

R2GC_151_93 = Coupling(name = 'R2GC_151_93',
                       value = '-(ee*complex(0,1)*G**2)/(9.*cmath.pi**2)',
                       order = {'QCD':2,'QED':1})

R2GC_168_94 = Coupling(name = 'R2GC_168_94',
                       value = '-(ee*complex(0,1)*G**2)/(6.*cmath.pi**2*sw*cmath.sqrt(2))',
                       order = {'QCD':2,'QED':1})

R2GC_169_95 = Coupling(name = 'R2GC_169_95',
                       value = '-(ee*complex(0,1)*G**2*xiWp)/(6.*cmath.pi**2*sw*cmath.sqrt(2))',
                       order = {'HvB':1,'QCD':2})

R2GC_175_96 = Coupling(name = 'R2GC_175_96',
                       value = '(complex(0,1)*G**2*kpBHL1)/(3.*cmath.pi**2)',
                       order = {'HvB':1,'QCD':2})

R2GC_176_97 = Coupling(name = 'R2GC_176_97',
                       value = '(complex(0,1)*G**2*kpBHL2)/(3.*cmath.pi**2)',
                       order = {'HvB':1,'QCD':2})

R2GC_177_98 = Coupling(name = 'R2GC_177_98',
                       value = '(complex(0,1)*G**2*kpBHL3)/(3.*cmath.pi**2)',
                       order = {'HvB':1,'QCD':2})

R2GC_178_99 = Coupling(name = 'R2GC_178_99',
                       value = '(complex(0,1)*G**2*kpBHpL1)/(3.*cmath.pi**2)',
                       order = {'HvB':1,'QCD':2})

R2GC_179_100 = Coupling(name = 'R2GC_179_100',
                        value = '(complex(0,1)*G**2*kpBHpL2)/(3.*cmath.pi**2)',
                        order = {'HvB':1,'QCD':2})

R2GC_180_101 = Coupling(name = 'R2GC_180_101',
                        value = '(complex(0,1)*G**2*kpBHpL3)/(3.*cmath.pi**2)',
                        order = {'HvB':1,'QCD':2})

R2GC_181_102 = Coupling(name = 'R2GC_181_102',
                        value = '(complex(0,1)*G**2*MBP)/(6.*cmath.pi**2)',
                        order = {'QCD':2})

R2GC_182_103 = Coupling(name = 'R2GC_182_103',
                        value = '-(ee*complex(0,1)*G**2*kpBWL1)/(6.*cmath.pi**2*sw*cmath.sqrt(2))',
                        order = {'HvQ':1,'QCD':2})

R2GC_183_104 = Coupling(name = 'R2GC_183_104',
                        value = '-(ee*complex(0,1)*G**2*kpBWL2)/(6.*cmath.pi**2*sw*cmath.sqrt(2))',
                        order = {'HvQ':1,'QCD':2})

R2GC_184_105 = Coupling(name = 'R2GC_184_105',
                        value = '-(ee*complex(0,1)*G**2*kpBWpL1)/(6.*cmath.pi**2*sw*cmath.sqrt(2))',
                        order = {'HvQ':1,'QCD':2})

R2GC_185_106 = Coupling(name = 'R2GC_185_106',
                        value = '-(ee*complex(0,1)*G**2*kpBWpL2)/(6.*cmath.pi**2*sw*cmath.sqrt(2))',
                        order = {'HvQ':1,'QCD':2})

R2GC_186_107 = Coupling(name = 'R2GC_186_107',
                        value = '-(ee*complex(0,1)*G**2*kpBZL1)/(12.*cw*cmath.pi**2*sw)',
                        order = {'HvQ':1,'QCD':2})

R2GC_187_108 = Coupling(name = 'R2GC_187_108',
                        value = '-(ee*complex(0,1)*G**2*kpBZL2)/(12.*cw*cmath.pi**2*sw)',
                        order = {'HvQ':1,'QCD':2})

R2GC_188_109 = Coupling(name = 'R2GC_188_109',
                        value = '-(ee*complex(0,1)*G**2*kpBZL3)/(12.*cw*cmath.pi**2*sw)',
                        order = {'HvQ':1,'QCD':2})

R2GC_189_110 = Coupling(name = 'R2GC_189_110',
                        value = '-(ee*complex(0,1)*G**2*kpBZpL1)/(12.*cw*cmath.pi**2*sw)',
                        order = {'HvQ':1,'QCD':2})

R2GC_190_111 = Coupling(name = 'R2GC_190_111',
                        value = '-(ee*complex(0,1)*G**2*kpBZpL2)/(12.*cw*cmath.pi**2*sw)',
                        order = {'HvQ':1,'QCD':2})

R2GC_191_112 = Coupling(name = 'R2GC_191_112',
                        value = '-(ee*complex(0,1)*G**2*kpBZpL3)/(12.*cw*cmath.pi**2*sw)',
                        order = {'HvQ':1,'QCD':2})

R2GC_195_113 = Coupling(name = 'R2GC_195_113',
                        value = '(complex(0,1)*G**2*MT)/(6.*cmath.pi**2)',
                        order = {'QCD':2})

R2GC_197_114 = Coupling(name = 'R2GC_197_114',
                        value = '-(ee*complex(0,1)*G**2*kpBWL3)/(6.*cmath.pi**2*sw*cmath.sqrt(2))',
                        order = {'HvQ':1,'QCD':2})

R2GC_198_115 = Coupling(name = 'R2GC_198_115',
                        value = '-(ee*complex(0,1)*G**2*kpBWpL3)/(6.*cmath.pi**2*sw*cmath.sqrt(2))',
                        order = {'HvQ':1,'QCD':2})

R2GC_200_116 = Coupling(name = 'R2GC_200_116',
                        value = '(ee*complex(0,1)*G**2*sw)/(9.*cw*cmath.pi**2)',
                        order = {'QCD':2,'QED':1})

R2GC_201_117 = Coupling(name = 'R2GC_201_117',
                        value = '(complex(0,1)*G**2*xiHp)/(3.*cmath.pi**2)',
                        order = {'HvB':1,'QCD':2})

R2GC_205_118 = Coupling(name = 'R2GC_205_118',
                        value = '(complex(0,1)*G**2*yt)/(3.*cmath.pi**2*cmath.sqrt(2))',
                        order = {'QCD':2,'QED':1})

R2GC_207_119 = Coupling(name = 'R2GC_207_119',
                        value = 'G**3/(24.*cmath.pi**2)',
                        order = {'QCD':3})

R2GC_207_120 = Coupling(name = 'R2GC_207_120',
                        value = '(11*G**3)/(64.*cmath.pi**2)',
                        order = {'QCD':3})

R2GC_208_121 = Coupling(name = 'R2GC_208_121',
                        value = '(5*complex(0,1)*G**4)/(48.*cmath.pi**2)',
                        order = {'QCD':4})

R2GC_208_122 = Coupling(name = 'R2GC_208_122',
                        value = '(19*complex(0,1)*G**4)/(32.*cmath.pi**2)',
                        order = {'QCD':4})

R2GC_209_123 = Coupling(name = 'R2GC_209_123',
                        value = '(23*complex(0,1)*G**4)/(192.*cmath.pi**2)',
                        order = {'QCD':4})

R2GC_210_124 = Coupling(name = 'R2GC_210_124',
                        value = '(31*complex(0,1)*G**4)/(64.*cmath.pi**2)',
                        order = {'QCD':4})

R2GC_211_125 = Coupling(name = 'R2GC_211_125',
                        value = '(-17*complex(0,1)*G**4)/(64.*cmath.pi**2)',
                        order = {'QCD':4})

R2GC_212_126 = Coupling(name = 'R2GC_212_126',
                        value = '(-7*complex(0,1)*G**4)/(32.*cmath.pi**2)',
                        order = {'QCD':4})

R2GC_213_127 = Coupling(name = 'R2GC_213_127',
                        value = '(7*complex(0,1)*G**4)/(64.*cmath.pi**2)',
                        order = {'QCD':4})

R2GC_217_128 = Coupling(name = 'R2GC_217_128',
                        value = '(complex(0,1)*G**2*kpTHL1)/(3.*cmath.pi**2)',
                        order = {'HvQ':1,'QCD':2})

R2GC_218_129 = Coupling(name = 'R2GC_218_129',
                        value = '(complex(0,1)*G**2*kpTHL2)/(3.*cmath.pi**2)',
                        order = {'HvQ':1,'QCD':2})

R2GC_219_130 = Coupling(name = 'R2GC_219_130',
                        value = '(complex(0,1)*G**2*kpTHL3)/(3.*cmath.pi**2)',
                        order = {'HvQ':1,'QCD':2})

R2GC_220_131 = Coupling(name = 'R2GC_220_131',
                        value = '(complex(0,1)*G**2*kpTHpL1)/(3.*cmath.pi**2)',
                        order = {'HvB':1,'QCD':2})

R2GC_221_132 = Coupling(name = 'R2GC_221_132',
                        value = '(complex(0,1)*G**2*kpTHpL2)/(3.*cmath.pi**2)',
                        order = {'HvB':1,'QCD':2})

R2GC_222_133 = Coupling(name = 'R2GC_222_133',
                        value = '(complex(0,1)*G**2*kpTHpL3)/(3.*cmath.pi**2)',
                        order = {'HvB':1,'QCD':2})

R2GC_223_134 = Coupling(name = 'R2GC_223_134',
                        value = '(complex(0,1)*G**2*kpTHpR3)/(3.*cmath.pi**2)',
                        order = {'HvB':1,'QCD':2})

R2GC_224_135 = Coupling(name = 'R2GC_224_135',
                        value = '(complex(0,1)*G**2*kpTHR3)/(3.*cmath.pi**2)',
                        order = {'HvB':1,'QCD':2})

R2GC_225_136 = Coupling(name = 'R2GC_225_136',
                        value = '(complex(0,1)*G**2*MTP)/(6.*cmath.pi**2)',
                        order = {'QCD':2})

R2GC_226_137 = Coupling(name = 'R2GC_226_137',
                        value = '-(ee*complex(0,1)*G**2*kpTWL1)/(6.*cmath.pi**2*sw*cmath.sqrt(2))',
                        order = {'HvQ':1,'QCD':2})

R2GC_227_138 = Coupling(name = 'R2GC_227_138',
                        value = '-(ee*complex(0,1)*G**2*kpTWL2)/(6.*cmath.pi**2*sw*cmath.sqrt(2))',
                        order = {'HvQ':1,'QCD':2})

R2GC_228_139 = Coupling(name = 'R2GC_228_139',
                        value = '-(ee*complex(0,1)*G**2*kpTWL3)/(6.*cmath.pi**2*sw*cmath.sqrt(2))',
                        order = {'HvQ':1,'QCD':2})

R2GC_229_140 = Coupling(name = 'R2GC_229_140',
                        value = '-(ee*complex(0,1)*G**2*kpTWpL1)/(6.*cmath.pi**2*sw*cmath.sqrt(2))',
                        order = {'HvQ':1,'QCD':2})

R2GC_230_141 = Coupling(name = 'R2GC_230_141',
                        value = '-(ee*complex(0,1)*G**2*kpTWpL2)/(6.*cmath.pi**2*sw*cmath.sqrt(2))',
                        order = {'HvQ':1,'QCD':2})

R2GC_231_142 = Coupling(name = 'R2GC_231_142',
                        value = '-(ee*complex(0,1)*G**2*kpTWpL3)/(6.*cmath.pi**2*sw*cmath.sqrt(2))',
                        order = {'HvQ':1,'QCD':2})

R2GC_232_143 = Coupling(name = 'R2GC_232_143',
                        value = '-(ee*complex(0,1)*G**2*kpTZL1)/(12.*cw*cmath.pi**2*sw)',
                        order = {'HvQ':1,'QCD':2})

R2GC_233_144 = Coupling(name = 'R2GC_233_144',
                        value = '-(ee*complex(0,1)*G**2*kpTZL2)/(12.*cw*cmath.pi**2*sw)',
                        order = {'HvQ':1,'QCD':2})

R2GC_234_145 = Coupling(name = 'R2GC_234_145',
                        value = '-(ee*complex(0,1)*G**2*kpTZL3)/(12.*cw*cmath.pi**2*sw)',
                        order = {'HvQ':1,'QCD':2})

R2GC_235_146 = Coupling(name = 'R2GC_235_146',
                        value = '-(ee*complex(0,1)*G**2*kpTZpL1)/(12.*cw*cmath.pi**2*sw)',
                        order = {'HvQ':1,'QCD':2})

R2GC_236_147 = Coupling(name = 'R2GC_236_147',
                        value = '-(ee*complex(0,1)*G**2*kpTZpL2)/(12.*cw*cmath.pi**2*sw)',
                        order = {'HvQ':1,'QCD':2})

R2GC_237_148 = Coupling(name = 'R2GC_237_148',
                        value = '-(ee*complex(0,1)*G**2*kpTZpL3)/(12.*cw*cmath.pi**2*sw)',
                        order = {'HvQ':1,'QCD':2})

R2GC_76_149 = Coupling(name = 'R2GC_76_149',
                       value = '-(complex(0,1)*G**2)/(16.*cmath.pi**2)',
                       order = {'QCD':2})

R2GC_77_150 = Coupling(name = 'R2GC_77_150',
                       value = '-(complex(0,1)*G**2*MT*xiHp)/(8.*cmath.pi**2)',
                       order = {'HvB':1,'QCD':2})

R2GC_78_151 = Coupling(name = 'R2GC_78_151',
                       value = '-(complex(0,1)*G**2*MT*yt)/(8.*cmath.pi**2*cmath.sqrt(2))',
                       order = {'QCD':2,'QED':1})

R2GC_79_152 = Coupling(name = 'R2GC_79_152',
                       value = '-(ee*complex(0,1)*G**2*sw)/(18.*cw*cmath.pi**2)',
                       order = {'QCD':2,'QED':1})

R2GC_84_153 = Coupling(name = 'R2GC_84_153',
                       value = '(ee*complex(0,1)*G**2*gAd*xiZp)/(6.*cw*cmath.pi**2*sw)',
                       order = {'HvB':1,'QCD':2})

R2GC_85_154 = Coupling(name = 'R2GC_85_154',
                       value = '-(ee*complex(0,1)*G**2*gVd*xiZp)/(6.*cw*cmath.pi**2*sw)',
                       order = {'HvB':1,'QCD':2})

R2GC_92_155 = Coupling(name = 'R2GC_92_155',
                       value = '-(complex(0,1)*G**2*MBP**2)/(8.*cmath.pi**2)',
                       order = {'QCD':2})

R2GC_92_156 = Coupling(name = 'R2GC_92_156',
                       value = '-(complex(0,1)*G**2*MT**2)/(8.*cmath.pi**2)',
                       order = {'QCD':2})

R2GC_92_157 = Coupling(name = 'R2GC_92_157',
                       value = '-(complex(0,1)*G**2*MTP**2)/(8.*cmath.pi**2)',
                       order = {'QCD':2})

R2GC_93_158 = Coupling(name = 'R2GC_93_158',
                       value = '(complex(0,1)*G**2)/(48.*cmath.pi**2)',
                       order = {'QCD':2})

R2GC_94_159 = Coupling(name = 'R2GC_94_159',
                       value = '(ee**2*complex(0,1)*G**2)/(216.*cmath.pi**2)',
                       order = {'QCD':2,'QED':2})

R2GC_94_160 = Coupling(name = 'R2GC_94_160',
                       value = '(ee**2*complex(0,1)*G**2)/(54.*cmath.pi**2)',
                       order = {'QCD':2,'QED':2})

R2GC_95_161 = Coupling(name = 'R2GC_95_161',
                       value = '-(ee*complex(0,1)*G**3)/(144.*cmath.pi**2)',
                       order = {'QCD':3,'QED':1})

R2GC_95_162 = Coupling(name = 'R2GC_95_162',
                       value = '(ee*complex(0,1)*G**3)/(72.*cmath.pi**2)',
                       order = {'QCD':3,'QED':1})

R2GC_96_163 = Coupling(name = 'R2GC_96_163',
                       value = '(cw*ee**2*complex(0,1)*G**2)/(288.*cmath.pi**2*sw) - (ee**2*complex(0,1)*G**2*sw)/(864.*cw*cmath.pi**2)',
                       order = {'QCD':2,'QED':2})

R2GC_96_164 = Coupling(name = 'R2GC_96_164',
                       value = '(cw*ee**2*complex(0,1)*G**2)/(144.*cmath.pi**2*sw) - (5*ee**2*complex(0,1)*G**2*sw)/(432.*cw*cmath.pi**2)',
                       order = {'QCD':2,'QED':2})

R2GC_97_165 = Coupling(name = 'R2GC_97_165',
                       value = '-(cw*ee*complex(0,1)*G**3)/(192.*cmath.pi**2*sw) + (ee*complex(0,1)*G**3*sw)/(576.*cw*cmath.pi**2)',
                       order = {'QCD':3,'QED':1})

R2GC_97_166 = Coupling(name = 'R2GC_97_166',
                       value = '(cw*ee*complex(0,1)*G**3)/(192.*cmath.pi**2*sw) - (5*ee*complex(0,1)*G**3*sw)/(576.*cw*cmath.pi**2)',
                       order = {'QCD':3,'QED':1})

R2GC_98_167 = Coupling(name = 'R2GC_98_167',
                       value = '(-3*cw*ee*complex(0,1)*G**3)/(64.*cmath.pi**2*sw) - (3*ee*complex(0,1)*G**3*sw)/(64.*cw*cmath.pi**2)',
                       order = {'QCD':3,'QED':1})

R2GC_98_168 = Coupling(name = 'R2GC_98_168',
                       value = '(3*cw*ee*complex(0,1)*G**3)/(64.*cmath.pi**2*sw) + (3*ee*complex(0,1)*G**3*sw)/(64.*cw*cmath.pi**2)',
                       order = {'QCD':3,'QED':1})

R2GC_99_169 = Coupling(name = 'R2GC_99_169',
                       value = '(ee*complex(0,1)*G**3*gAd*xiZp)/(16.*cw*cmath.pi**2*sw)',
                       order = {'HvB':1,'QCD':3})

R2GC_99_170 = Coupling(name = 'R2GC_99_170',
                       value = '(ee*complex(0,1)*G**3*gAu*xiZp)/(16.*cw*cmath.pi**2*sw)',
                       order = {'HvB':1,'QCD':3})

UVGC_122_1 = Coupling(name = 'UVGC_122_1',
                      value = {-1:'(51*G**3)/(128.*cmath.pi**2)'},
                      order = {'QCD':3})

UVGC_123_2 = Coupling(name = 'UVGC_123_2',
                      value = {-1:'G**3/(128.*cmath.pi**2)'},
                      order = {'QCD':3})

UVGC_124_3 = Coupling(name = 'UVGC_124_3',
                      value = {-1:'-(complex(0,1)*G**2)/(12.*cmath.pi**2)'},
                      order = {'QCD':2})

UVGC_125_4 = Coupling(name = 'UVGC_125_4',
                      value = {-1:'-(ee*complex(0,1)*G**2)/(36.*cmath.pi**2)'},
                      order = {'QCD':2,'QED':1})

UVGC_126_5 = Coupling(name = 'UVGC_126_5',
                      value = {-1:'(ee*complex(0,1)*G**2)/(36.*cmath.pi**2)'},
                      order = {'QCD':2,'QED':1})

UVGC_127_6 = Coupling(name = 'UVGC_127_6',
                      value = {-1:'(-13*complex(0,1)*G**3)/(48.*cmath.pi**2)'},
                      order = {'QCD':3})

UVGC_129_7 = Coupling(name = 'UVGC_129_7',
                      value = {-1:'(ee*complex(0,1)*G**2)/(18.*cmath.pi**2)'},
                      order = {'QCD':2,'QED':1})

UVGC_134_8 = Coupling(name = 'UVGC_134_8',
                      value = {-1:'-(ee*complex(0,1)*G**2)/(18.*cmath.pi**2)'},
                      order = {'QCD':2,'QED':1})

UVGC_138_9 = Coupling(name = 'UVGC_138_9',
                      value = {-1:'(3*complex(0,1)*G**2)/(64.*cmath.pi**2)'},
                      order = {'QCD':2})

UVGC_138_10 = Coupling(name = 'UVGC_138_10',
                       value = {-1:'(-3*complex(0,1)*G**2)/(64.*cmath.pi**2)'},
                       order = {'QCD':2})

UVGC_139_11 = Coupling(name = 'UVGC_139_11',
                       value = {-1:'(3*G**4)/(512.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_139_12 = Coupling(name = 'UVGC_139_12',
                       value = {-1:'(-3*G**4)/(512.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_140_13 = Coupling(name = 'UVGC_140_13',
                       value = {-1:'(3*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_140_14 = Coupling(name = 'UVGC_140_14',
                       value = {-1:'(-3*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_142_15 = Coupling(name = 'UVGC_142_15',
                       value = {-1:'-(complex(0,1)*G**4)/(128.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_142_16 = Coupling(name = 'UVGC_142_16',
                       value = {-1:'(complex(0,1)*G**4)/(128.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_143_17 = Coupling(name = 'UVGC_143_17',
                       value = {-1:'(-3*complex(0,1)*G**4)/(256.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_143_18 = Coupling(name = 'UVGC_143_18',
                       value = {-1:'(3*complex(0,1)*G**4)/(256.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_144_19 = Coupling(name = 'UVGC_144_19',
                       value = {-1:'-(complex(0,1)*G**4)/(24.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_144_20 = Coupling(name = 'UVGC_144_20',
                       value = {-1:'(47*complex(0,1)*G**4)/(128.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_145_21 = Coupling(name = 'UVGC_145_21',
                       value = {-1:'(-253*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_145_22 = Coupling(name = 'UVGC_145_22',
                       value = {-1:'(5*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_146_23 = Coupling(name = 'UVGC_146_23',
                       value = {-1:'(complex(0,1)*G**2)/(12.*cmath.pi**2)'},
                       order = {'QCD':2})

UVGC_148_24 = Coupling(name = 'UVGC_148_24',
                       value = {-1:'(complex(0,1)*G**3)/(48.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_148_25 = Coupling(name = 'UVGC_148_25',
                       value = {-1:'(-19*complex(0,1)*G**3)/(128.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_148_26 = Coupling(name = 'UVGC_148_26',
                       value = {-1:'-(complex(0,1)*G**3)/(128.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_148_27 = Coupling(name = 'UVGC_148_27',
                       value = {-1:'(complex(0,1)*G**3)/(12.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_168_28 = Coupling(name = 'UVGC_168_28',
                       value = {-1:'(ee*complex(0,1)*G**2)/(24.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'QCD':2,'QED':1})

UVGC_168_29 = Coupling(name = 'UVGC_168_29',
                       value = {-1:'-(ee*complex(0,1)*G**2)/(12.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'QCD':2,'QED':1})

UVGC_169_30 = Coupling(name = 'UVGC_169_30',
                       value = {-1:'(ee*complex(0,1)*G**2*xiWp)/(24.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvB':1,'QCD':2})

UVGC_169_31 = Coupling(name = 'UVGC_169_31',
                       value = {-1:'-(ee*complex(0,1)*G**2*xiWp)/(12.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvB':1,'QCD':2})

UVGC_172_32 = Coupling(name = 'UVGC_172_32',
                       value = {-1:'(complex(0,1)*G**2)/(4.*cmath.pi**2)',0:'(complex(0,1)*G**2)/(3.*cmath.pi**2) - (complex(0,1)*G**2*reglog(MBP/MU_R))/(2.*cmath.pi**2)'},
                       order = {'QCD':2})

UVGC_173_33 = Coupling(name = 'UVGC_173_33',
                       value = {0:'(ee*complex(0,1)*G**2)/(9.*cmath.pi**2) - (ee*complex(0,1)*G**2*reglog(MBP/MU_R))/(6.*cmath.pi**2)'},
                       order = {'QCD':2,'QED':1})

UVGC_174_34 = Coupling(name = 'UVGC_174_34',
                       value = {0:'-(complex(0,1)*G**3)/(3.*cmath.pi**2) + (complex(0,1)*G**3*reglog(MBP/MU_R))/(2.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_175_35 = Coupling(name = 'UVGC_175_35',
                       value = {-1:'(complex(0,1)*G**2*kpBHL1)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpBHL1)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpBHL1*reglog(MBP/MU_R))/(4.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_175_36 = Coupling(name = 'UVGC_175_36',
                       value = {-1:'-(complex(0,1)*G**2*kpBHL1)/(24.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_175_37 = Coupling(name = 'UVGC_175_37',
                       value = {-1:'(complex(0,1)*G**2*kpBHL1)/(3.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_176_38 = Coupling(name = 'UVGC_176_38',
                       value = {-1:'(complex(0,1)*G**2*kpBHL2)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpBHL2)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpBHL2*reglog(MBP/MU_R))/(4.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_176_39 = Coupling(name = 'UVGC_176_39',
                       value = {-1:'-(complex(0,1)*G**2*kpBHL2)/(24.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_176_40 = Coupling(name = 'UVGC_176_40',
                       value = {-1:'(complex(0,1)*G**2*kpBHL2)/(3.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_177_41 = Coupling(name = 'UVGC_177_41',
                       value = {-1:'-(complex(0,1)*G**2*kpBHL3)/(24.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_177_42 = Coupling(name = 'UVGC_177_42',
                       value = {-1:'(complex(0,1)*G**2*kpBHL3)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpBHL3)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpBHL3*reglog(MBP/MU_R))/(4.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_177_43 = Coupling(name = 'UVGC_177_43',
                       value = {-1:'(complex(0,1)*G**2*kpBHL3)/(3.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_178_44 = Coupling(name = 'UVGC_178_44',
                       value = {-1:'(complex(0,1)*G**2*kpBHpL1)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpBHpL1)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpBHpL1*reglog(MBP/MU_R))/(4.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_178_45 = Coupling(name = 'UVGC_178_45',
                       value = {-1:'-(complex(0,1)*G**2*kpBHpL1)/(24.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_178_46 = Coupling(name = 'UVGC_178_46',
                       value = {-1:'(complex(0,1)*G**2*kpBHpL1)/(3.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_179_47 = Coupling(name = 'UVGC_179_47',
                       value = {-1:'(complex(0,1)*G**2*kpBHpL2)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpBHpL2)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpBHpL2*reglog(MBP/MU_R))/(4.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_179_48 = Coupling(name = 'UVGC_179_48',
                       value = {-1:'-(complex(0,1)*G**2*kpBHpL2)/(24.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_179_49 = Coupling(name = 'UVGC_179_49',
                       value = {-1:'(complex(0,1)*G**2*kpBHpL2)/(3.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_180_50 = Coupling(name = 'UVGC_180_50',
                       value = {-1:'-(complex(0,1)*G**2*kpBHpL3)/(24.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_180_51 = Coupling(name = 'UVGC_180_51',
                       value = {-1:'(complex(0,1)*G**2*kpBHpL3)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpBHpL3)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpBHpL3*reglog(MBP/MU_R))/(4.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_180_52 = Coupling(name = 'UVGC_180_52',
                       value = {-1:'(complex(0,1)*G**2*kpBHpL3)/(3.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_181_53 = Coupling(name = 'UVGC_181_53',
                       value = {-1:'(complex(0,1)*G**2*MBP)/(2.*cmath.pi**2)',0:'(2*complex(0,1)*G**2*MBP)/(3.*cmath.pi**2) - (complex(0,1)*G**2*MBP*reglog(MBP/MU_R))/cmath.pi**2'},
                       order = {'QCD':2})

UVGC_182_54 = Coupling(name = 'UVGC_182_54',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBWL1)/(12.*cmath.pi**2*sw*cmath.sqrt(2))',0:'-(ee*complex(0,1)*G**2*kpBWL1)/(6.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*kpBWL1*reglog(MBP/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvQ':1,'QCD':2})

UVGC_182_55 = Coupling(name = 'UVGC_182_55',
                       value = {-1:'(ee*complex(0,1)*G**2*kpBWL1)/(24.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvQ':1,'QCD':2})

UVGC_182_56 = Coupling(name = 'UVGC_182_56',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBWL1)/(12.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvQ':1,'QCD':2})

UVGC_183_57 = Coupling(name = 'UVGC_183_57',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBWL2)/(12.*cmath.pi**2*sw*cmath.sqrt(2))',0:'-(ee*complex(0,1)*G**2*kpBWL2)/(6.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*kpBWL2*reglog(MBP/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvQ':1,'QCD':2})

UVGC_183_58 = Coupling(name = 'UVGC_183_58',
                       value = {-1:'(ee*complex(0,1)*G**2*kpBWL2)/(24.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvQ':1,'QCD':2})

UVGC_183_59 = Coupling(name = 'UVGC_183_59',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBWL2)/(12.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvQ':1,'QCD':2})

UVGC_184_60 = Coupling(name = 'UVGC_184_60',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBWpL1)/(12.*cmath.pi**2*sw*cmath.sqrt(2))',0:'-(ee*complex(0,1)*G**2*kpBWpL1)/(6.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*kpBWpL1*reglog(MBP/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvQ':1,'QCD':2})

UVGC_184_61 = Coupling(name = 'UVGC_184_61',
                       value = {-1:'(ee*complex(0,1)*G**2*kpBWpL1)/(24.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvQ':1,'QCD':2})

UVGC_184_62 = Coupling(name = 'UVGC_184_62',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBWpL1)/(12.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvQ':1,'QCD':2})

UVGC_185_63 = Coupling(name = 'UVGC_185_63',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBWpL2)/(12.*cmath.pi**2*sw*cmath.sqrt(2))',0:'-(ee*complex(0,1)*G**2*kpBWpL2)/(6.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*kpBWpL2*reglog(MBP/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvQ':1,'QCD':2})

UVGC_185_64 = Coupling(name = 'UVGC_185_64',
                       value = {-1:'(ee*complex(0,1)*G**2*kpBWpL2)/(24.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvQ':1,'QCD':2})

UVGC_185_65 = Coupling(name = 'UVGC_185_65',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBWpL2)/(12.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvQ':1,'QCD':2})

UVGC_186_66 = Coupling(name = 'UVGC_186_66',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBZL1)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpBZL1)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpBZL1*reglog(MBP/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_186_67 = Coupling(name = 'UVGC_186_67',
                       value = {-1:'(ee*complex(0,1)*G**2*kpBZL1)/(48.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_186_68 = Coupling(name = 'UVGC_186_68',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBZL1)/(24.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_187_69 = Coupling(name = 'UVGC_187_69',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBZL2)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpBZL2)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpBZL2*reglog(MBP/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_187_70 = Coupling(name = 'UVGC_187_70',
                       value = {-1:'(ee*complex(0,1)*G**2*kpBZL2)/(48.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_187_71 = Coupling(name = 'UVGC_187_71',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBZL2)/(24.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_188_72 = Coupling(name = 'UVGC_188_72',
                       value = {-1:'(ee*complex(0,1)*G**2*kpBZL3)/(48.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_188_73 = Coupling(name = 'UVGC_188_73',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBZL3)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpBZL3)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpBZL3*reglog(MBP/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_188_74 = Coupling(name = 'UVGC_188_74',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBZL3)/(24.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_189_75 = Coupling(name = 'UVGC_189_75',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBZpL1)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpBZpL1)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpBZpL1*reglog(MBP/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_189_76 = Coupling(name = 'UVGC_189_76',
                       value = {-1:'(ee*complex(0,1)*G**2*kpBZpL1)/(48.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_189_77 = Coupling(name = 'UVGC_189_77',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBZpL1)/(24.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_190_78 = Coupling(name = 'UVGC_190_78',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBZpL2)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpBZpL2)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpBZpL2*reglog(MBP/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_190_79 = Coupling(name = 'UVGC_190_79',
                       value = {-1:'(ee*complex(0,1)*G**2*kpBZpL2)/(48.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_190_80 = Coupling(name = 'UVGC_190_80',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBZpL2)/(24.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_191_81 = Coupling(name = 'UVGC_191_81',
                       value = {-1:'(ee*complex(0,1)*G**2*kpBZpL3)/(48.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_191_82 = Coupling(name = 'UVGC_191_82',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBZpL3)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpBZpL3)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpBZpL3*reglog(MBP/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_191_83 = Coupling(name = 'UVGC_191_83',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBZpL3)/(24.*cw*cmath.pi**2*sw)'},
                       order = {'HvQ':1,'QCD':2})

UVGC_192_84 = Coupling(name = 'UVGC_192_84',
                       value = {-1:'(complex(0,1)*G**2)/(4.*cmath.pi**2)',0:'(complex(0,1)*G**2)/(3.*cmath.pi**2) - (complex(0,1)*G**2*reglog(MT/MU_R))/(2.*cmath.pi**2)'},
                       order = {'QCD':2})

UVGC_193_85 = Coupling(name = 'UVGC_193_85',
                       value = {-1:'-(ee*complex(0,1)*G**2)/(9.*cmath.pi**2)',0:'(-2*ee*complex(0,1)*G**2)/(9.*cmath.pi**2) + (ee*complex(0,1)*G**2*reglog(MT/MU_R))/(3.*cmath.pi**2)'},
                       order = {'QCD':2,'QED':1})

UVGC_194_86 = Coupling(name = 'UVGC_194_86',
                       value = {-1:'-(complex(0,1)*G**3)/(6.*cmath.pi**2)',0:'-(complex(0,1)*G**3)/(3.*cmath.pi**2) + (complex(0,1)*G**3*reglog(MT/MU_R))/(2.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_195_87 = Coupling(name = 'UVGC_195_87',
                       value = {-1:'(complex(0,1)*G**2*MT)/(2.*cmath.pi**2)',0:'(2*complex(0,1)*G**2*MT)/(3.*cmath.pi**2) - (complex(0,1)*G**2*MT*reglog(MT/MU_R))/cmath.pi**2'},
                       order = {'QCD':2})

UVGC_196_88 = Coupling(name = 'UVGC_196_88',
                       value = {-1:'-(ee*complex(0,1)*G**2)/(12.*cmath.pi**2*sw*cmath.sqrt(2))',0:'-(ee*complex(0,1)*G**2)/(6.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*reglog(MT/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'QCD':2,'QED':1})

UVGC_197_89 = Coupling(name = 'UVGC_197_89',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBWL3)/(12.*cmath.pi**2*sw*cmath.sqrt(2))',0:'-(ee*complex(0,1)*G**2*kpBWL3)/(6.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*kpBWL3*reglog(MBP/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvQ':1,'QCD':2})

UVGC_197_90 = Coupling(name = 'UVGC_197_90',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBWL3)/(12.*cmath.pi**2*sw*cmath.sqrt(2))',0:'-(ee*complex(0,1)*G**2*kpBWL3)/(6.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*kpBWL3*reglog(MT/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvQ':1,'QCD':2})

UVGC_197_91 = Coupling(name = 'UVGC_197_91',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBWL3)/(12.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvQ':1,'QCD':2})

UVGC_198_92 = Coupling(name = 'UVGC_198_92',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBWpL3)/(12.*cmath.pi**2*sw*cmath.sqrt(2))',0:'-(ee*complex(0,1)*G**2*kpBWpL3)/(6.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*kpBWpL3*reglog(MBP/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvQ':1,'QCD':2})

UVGC_198_93 = Coupling(name = 'UVGC_198_93',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBWpL3)/(12.*cmath.pi**2*sw*cmath.sqrt(2))',0:'-(ee*complex(0,1)*G**2*kpBWpL3)/(6.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*kpBWpL3*reglog(MT/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvQ':1,'QCD':2})

UVGC_198_94 = Coupling(name = 'UVGC_198_94',
                       value = {-1:'-(ee*complex(0,1)*G**2*kpBWpL3)/(12.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvQ':1,'QCD':2})

UVGC_199_95 = Coupling(name = 'UVGC_199_95',
                       value = {-1:'-(cw*ee*complex(0,1)*G**2)/(8.*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*sw)/(24.*cw*cmath.pi**2)',0:'-(cw*ee*complex(0,1)*G**2)/(6.*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*sw)/(18.*cw*cmath.pi**2) + (cw*ee*complex(0,1)*G**2*reglog(MT/MU_R))/(4.*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*sw*reglog(MT/MU_R))/(12.*cw*cmath.pi**2)'},
                       order = {'QCD':2,'QED':1})

UVGC_200_96 = Coupling(name = 'UVGC_200_96',
                       value = {-1:'(ee*complex(0,1)*G**2*sw)/(6.*cw*cmath.pi**2)',0:'(2*ee*complex(0,1)*G**2*sw)/(9.*cw*cmath.pi**2) - (ee*complex(0,1)*G**2*sw*reglog(MT/MU_R))/(3.*cw*cmath.pi**2)'},
                       order = {'QCD':2,'QED':1})

UVGC_201_97 = Coupling(name = 'UVGC_201_97',
                       value = {-1:'(complex(0,1)*G**2*xiHp)/(2.*cmath.pi**2)',0:'(complex(0,1)*G**2*xiHp)/(3.*cmath.pi**2) - (complex(0,1)*G**2*xiHp*reglog(MT/MU_R))/(2.*cmath.pi**2)'},
                       order = {'HvB':1,'QCD':2})

UVGC_202_98 = Coupling(name = 'UVGC_202_98',
                       value = {-1:'-(ee*complex(0,1)*G**2*xiWp)/(12.*cmath.pi**2*sw*cmath.sqrt(2))',0:'-(ee*complex(0,1)*G**2*xiWp)/(6.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*xiWp*reglog(MT/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'HvB':1,'QCD':2})

UVGC_203_99 = Coupling(name = 'UVGC_203_99',
                       value = {-1:'(ee*complex(0,1)*G**2*gAu*xiZp)/(4.*cw*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*gVu*xiZp)/(4.*cw*cmath.pi**2*sw)',0:'(ee*complex(0,1)*G**2*gAu*xiZp)/(3.*cw*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*gVu*xiZp)/(3.*cw*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*gAu*xiZp*reglog(MT/MU_R))/(2.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*gVu*xiZp*reglog(MT/MU_R))/(2.*cw*cmath.pi**2*sw)'},
                       order = {'HvB':1,'QCD':2})

UVGC_204_100 = Coupling(name = 'UVGC_204_100',
                        value = {-1:'-(ee*complex(0,1)*G**2*gAu*xiZp)/(4.*cw*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*gVu*xiZp)/(4.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*gAu*xiZp)/(3.*cw*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*gVu*xiZp)/(3.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*gAu*xiZp*reglog(MT/MU_R))/(2.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*gVu*xiZp*reglog(MT/MU_R))/(2.*cw*cmath.pi**2*sw)'},
                        order = {'HvB':1,'QCD':2})

UVGC_205_101 = Coupling(name = 'UVGC_205_101',
                        value = {-1:'(complex(0,1)*G**2*yt)/(2.*cmath.pi**2*cmath.sqrt(2))',0:'(complex(0,1)*G**2*yt*cmath.sqrt(2))/(3.*cmath.pi**2) - (complex(0,1)*G**2*yt*reglog(MT/MU_R))/(cmath.pi**2*cmath.sqrt(2))'},
                        order = {'QCD':2,'QED':1})

UVGC_206_102 = Coupling(name = 'UVGC_206_102',
                        value = {-1:'-(complex(0,1)*G**2)/(24.*cmath.pi**2)',0:'(complex(0,1)*G**2*reglog(MBP/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':2})

UVGC_206_103 = Coupling(name = 'UVGC_206_103',
                        value = {-1:'-(complex(0,1)*G**2)/(24.*cmath.pi**2)',0:'(complex(0,1)*G**2*reglog(MT/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':2})

UVGC_206_104 = Coupling(name = 'UVGC_206_104',
                        value = {-1:'-(complex(0,1)*G**2)/(24.*cmath.pi**2)',0:'(complex(0,1)*G**2*reglog(MTP/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':2})

UVGC_207_105 = Coupling(name = 'UVGC_207_105',
                        value = {-1:'-G**3/(48.*cmath.pi**2)'},
                        order = {'QCD':3})

UVGC_207_106 = Coupling(name = 'UVGC_207_106',
                        value = {-1:'G**3/(24.*cmath.pi**2)',0:'-(G**3*reglog(MBP/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':3})

UVGC_207_107 = Coupling(name = 'UVGC_207_107',
                        value = {-1:'G**3/(24.*cmath.pi**2)',0:'-(G**3*reglog(MT/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':3})

UVGC_207_108 = Coupling(name = 'UVGC_207_108',
                        value = {-1:'G**3/(24.*cmath.pi**2)',0:'-(G**3*reglog(MTP/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':3})

UVGC_208_109 = Coupling(name = 'UVGC_208_109',
                        value = {-1:'(complex(0,1)*G**4)/(12.*cmath.pi**2)',0:'-(complex(0,1)*G**4*reglog(MBP/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_208_110 = Coupling(name = 'UVGC_208_110',
                        value = {-1:'(147*complex(0,1)*G**4)/(128.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_208_111 = Coupling(name = 'UVGC_208_111',
                        value = {-1:'(3*complex(0,1)*G**4)/(128.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_208_112 = Coupling(name = 'UVGC_208_112',
                        value = {-1:'(complex(0,1)*G**4)/(12.*cmath.pi**2)',0:'-(complex(0,1)*G**4*reglog(MT/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_208_113 = Coupling(name = 'UVGC_208_113',
                        value = {-1:'(complex(0,1)*G**4)/(12.*cmath.pi**2)',0:'-(complex(0,1)*G**4*reglog(MTP/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_209_114 = Coupling(name = 'UVGC_209_114',
                        value = {-1:'(147*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_209_115 = Coupling(name = 'UVGC_209_115',
                        value = {-1:'(21*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_210_116 = Coupling(name = 'UVGC_210_116',
                        value = {-1:'-(complex(0,1)*G**4)/(12.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_210_117 = Coupling(name = 'UVGC_210_117',
                        value = {0:'-(complex(0,1)*G**4*reglog(MBP/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_210_118 = Coupling(name = 'UVGC_210_118',
                        value = {-1:'(523*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_210_119 = Coupling(name = 'UVGC_210_119',
                        value = {-1:'(13*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_210_120 = Coupling(name = 'UVGC_210_120',
                        value = {0:'-(complex(0,1)*G**4*reglog(MT/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_210_121 = Coupling(name = 'UVGC_210_121',
                        value = {0:'-(complex(0,1)*G**4*reglog(MTP/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_211_122 = Coupling(name = 'UVGC_211_122',
                        value = {-1:'(complex(0,1)*G**4)/(24.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_211_123 = Coupling(name = 'UVGC_211_123',
                        value = {-1:'-(complex(0,1)*G**4)/(24.*cmath.pi**2)',0:'(complex(0,1)*G**4*reglog(MBP/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_211_124 = Coupling(name = 'UVGC_211_124',
                        value = {-1:'(-341*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_211_125 = Coupling(name = 'UVGC_211_125',
                        value = {-1:'(-11*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_211_126 = Coupling(name = 'UVGC_211_126',
                        value = {-1:'-(complex(0,1)*G**4)/(24.*cmath.pi**2)',0:'(complex(0,1)*G**4*reglog(MT/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_211_127 = Coupling(name = 'UVGC_211_127',
                        value = {-1:'-(complex(0,1)*G**4)/(24.*cmath.pi**2)',0:'(complex(0,1)*G**4*reglog(MTP/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_212_128 = Coupling(name = 'UVGC_212_128',
                        value = {-1:'(-83*complex(0,1)*G**4)/(128.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_212_129 = Coupling(name = 'UVGC_212_129',
                        value = {-1:'(-5*complex(0,1)*G**4)/(128.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_213_130 = Coupling(name = 'UVGC_213_130',
                        value = {-1:'(complex(0,1)*G**4)/(12.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_213_131 = Coupling(name = 'UVGC_213_131',
                        value = {0:'(complex(0,1)*G**4*reglog(MBP/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_213_132 = Coupling(name = 'UVGC_213_132',
                        value = {-1:'(-85*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_213_133 = Coupling(name = 'UVGC_213_133',
                        value = {-1:'(-19*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_213_134 = Coupling(name = 'UVGC_213_134',
                        value = {0:'(complex(0,1)*G**4*reglog(MT/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_213_135 = Coupling(name = 'UVGC_213_135',
                        value = {0:'(complex(0,1)*G**4*reglog(MTP/MU_R))/(12.*cmath.pi**2)'},
                        order = {'QCD':4})

UVGC_214_136 = Coupling(name = 'UVGC_214_136',
                        value = {-1:'(complex(0,1)*G**2)/(4.*cmath.pi**2)',0:'(complex(0,1)*G**2)/(3.*cmath.pi**2) - (complex(0,1)*G**2*reglog(MTP/MU_R))/(2.*cmath.pi**2)'},
                        order = {'QCD':2})

UVGC_215_137 = Coupling(name = 'UVGC_215_137',
                        value = {0:'(-2*ee*complex(0,1)*G**2)/(9.*cmath.pi**2) + (ee*complex(0,1)*G**2*reglog(MTP/MU_R))/(3.*cmath.pi**2)'},
                        order = {'QCD':2,'QED':1})

UVGC_216_138 = Coupling(name = 'UVGC_216_138',
                        value = {0:'-(complex(0,1)*G**3)/(3.*cmath.pi**2) + (complex(0,1)*G**3*reglog(MTP/MU_R))/(2.*cmath.pi**2)'},
                        order = {'QCD':3})

UVGC_217_139 = Coupling(name = 'UVGC_217_139',
                        value = {-1:'(complex(0,1)*G**2*kpTHL1)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpTHL1)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpTHL1*reglog(MTP/MU_R))/(4.*cmath.pi**2)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_217_140 = Coupling(name = 'UVGC_217_140',
                        value = {-1:'-(complex(0,1)*G**2*kpTHL1)/(24.*cmath.pi**2)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_217_141 = Coupling(name = 'UVGC_217_141',
                        value = {-1:'(complex(0,1)*G**2*kpTHL1)/(3.*cmath.pi**2)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_218_142 = Coupling(name = 'UVGC_218_142',
                        value = {-1:'-(complex(0,1)*G**2*kpTHL2)/(24.*cmath.pi**2)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_218_143 = Coupling(name = 'UVGC_218_143',
                        value = {-1:'(complex(0,1)*G**2*kpTHL2)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpTHL2)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpTHL2*reglog(MTP/MU_R))/(4.*cmath.pi**2)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_218_144 = Coupling(name = 'UVGC_218_144',
                        value = {-1:'(complex(0,1)*G**2*kpTHL2)/(3.*cmath.pi**2)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_219_145 = Coupling(name = 'UVGC_219_145',
                        value = {-1:'(complex(0,1)*G**2*kpTHL3)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpTHL3)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpTHL3*reglog(MT/MU_R))/(4.*cmath.pi**2)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_219_146 = Coupling(name = 'UVGC_219_146',
                        value = {-1:'(complex(0,1)*G**2*kpTHL3)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpTHL3)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpTHL3*reglog(MTP/MU_R))/(4.*cmath.pi**2)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_219_147 = Coupling(name = 'UVGC_219_147',
                        value = {-1:'(complex(0,1)*G**2*kpTHL3)/(3.*cmath.pi**2)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_220_148 = Coupling(name = 'UVGC_220_148',
                        value = {-1:'(complex(0,1)*G**2*kpTHpL1)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpTHpL1)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpTHpL1*reglog(MTP/MU_R))/(4.*cmath.pi**2)'},
                        order = {'HvB':1,'QCD':2})

UVGC_220_149 = Coupling(name = 'UVGC_220_149',
                        value = {-1:'-(complex(0,1)*G**2*kpTHpL1)/(24.*cmath.pi**2)'},
                        order = {'HvB':1,'QCD':2})

UVGC_220_150 = Coupling(name = 'UVGC_220_150',
                        value = {-1:'(complex(0,1)*G**2*kpTHpL1)/(3.*cmath.pi**2)'},
                        order = {'HvB':1,'QCD':2})

UVGC_221_151 = Coupling(name = 'UVGC_221_151',
                        value = {-1:'-(complex(0,1)*G**2*kpTHpL2)/(24.*cmath.pi**2)'},
                        order = {'HvB':1,'QCD':2})

UVGC_221_152 = Coupling(name = 'UVGC_221_152',
                        value = {-1:'(complex(0,1)*G**2*kpTHpL2)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpTHpL2)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpTHpL2*reglog(MTP/MU_R))/(4.*cmath.pi**2)'},
                        order = {'HvB':1,'QCD':2})

UVGC_221_153 = Coupling(name = 'UVGC_221_153',
                        value = {-1:'(complex(0,1)*G**2*kpTHpL2)/(3.*cmath.pi**2)'},
                        order = {'HvB':1,'QCD':2})

UVGC_222_154 = Coupling(name = 'UVGC_222_154',
                        value = {-1:'(complex(0,1)*G**2*kpTHpL3)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpTHpL3)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpTHpL3*reglog(MT/MU_R))/(4.*cmath.pi**2)'},
                        order = {'HvB':1,'QCD':2})

UVGC_222_155 = Coupling(name = 'UVGC_222_155',
                        value = {-1:'(complex(0,1)*G**2*kpTHpL3)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpTHpL3)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpTHpL3*reglog(MTP/MU_R))/(4.*cmath.pi**2)'},
                        order = {'HvB':1,'QCD':2})

UVGC_222_156 = Coupling(name = 'UVGC_222_156',
                        value = {-1:'(complex(0,1)*G**2*kpTHpL3)/(3.*cmath.pi**2)'},
                        order = {'HvB':1,'QCD':2})

UVGC_223_157 = Coupling(name = 'UVGC_223_157',
                        value = {-1:'(complex(0,1)*G**2*kpTHpR3)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpTHpR3)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpTHpR3*reglog(MT/MU_R))/(4.*cmath.pi**2)'},
                        order = {'HvB':1,'QCD':2})

UVGC_223_158 = Coupling(name = 'UVGC_223_158',
                        value = {-1:'(complex(0,1)*G**2*kpTHpR3)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpTHpR3)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpTHpR3*reglog(MTP/MU_R))/(4.*cmath.pi**2)'},
                        order = {'HvB':1,'QCD':2})

UVGC_223_159 = Coupling(name = 'UVGC_223_159',
                        value = {-1:'(complex(0,1)*G**2*kpTHpR3)/(3.*cmath.pi**2)'},
                        order = {'HvB':1,'QCD':2})

UVGC_224_160 = Coupling(name = 'UVGC_224_160',
                        value = {-1:'(complex(0,1)*G**2*kpTHR3)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpTHR3)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpTHR3*reglog(MT/MU_R))/(4.*cmath.pi**2)'},
                        order = {'HvB':1,'QCD':2})

UVGC_224_161 = Coupling(name = 'UVGC_224_161',
                        value = {-1:'(complex(0,1)*G**2*kpTHR3)/(12.*cmath.pi**2)',0:'(complex(0,1)*G**2*kpTHR3)/(6.*cmath.pi**2) - (complex(0,1)*G**2*kpTHR3*reglog(MTP/MU_R))/(4.*cmath.pi**2)'},
                        order = {'HvB':1,'QCD':2})

UVGC_224_162 = Coupling(name = 'UVGC_224_162',
                        value = {-1:'(complex(0,1)*G**2*kpTHR3)/(3.*cmath.pi**2)'},
                        order = {'HvB':1,'QCD':2})

UVGC_225_163 = Coupling(name = 'UVGC_225_163',
                        value = {-1:'(complex(0,1)*G**2*MTP)/(2.*cmath.pi**2)',0:'(2*complex(0,1)*G**2*MTP)/(3.*cmath.pi**2) - (complex(0,1)*G**2*MTP*reglog(MTP/MU_R))/cmath.pi**2'},
                        order = {'QCD':2})

UVGC_226_164 = Coupling(name = 'UVGC_226_164',
                        value = {-1:'(ee*complex(0,1)*G**2*kpTWL1)/(24.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_226_165 = Coupling(name = 'UVGC_226_165',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTWL1)/(12.*cmath.pi**2*sw*cmath.sqrt(2))',0:'-(ee*complex(0,1)*G**2*kpTWL1)/(6.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*kpTWL1*reglog(MTP/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_226_166 = Coupling(name = 'UVGC_226_166',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTWL1)/(12.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_227_167 = Coupling(name = 'UVGC_227_167',
                        value = {-1:'(ee*complex(0,1)*G**2*kpTWL2)/(24.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_227_168 = Coupling(name = 'UVGC_227_168',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTWL2)/(12.*cmath.pi**2*sw*cmath.sqrt(2))',0:'-(ee*complex(0,1)*G**2*kpTWL2)/(6.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*kpTWL2*reglog(MTP/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_227_169 = Coupling(name = 'UVGC_227_169',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTWL2)/(12.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_228_170 = Coupling(name = 'UVGC_228_170',
                        value = {-1:'(ee*complex(0,1)*G**2*kpTWL3)/(24.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_228_171 = Coupling(name = 'UVGC_228_171',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTWL3)/(12.*cmath.pi**2*sw*cmath.sqrt(2))',0:'-(ee*complex(0,1)*G**2*kpTWL3)/(6.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*kpTWL3*reglog(MTP/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_228_172 = Coupling(name = 'UVGC_228_172',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTWL3)/(12.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_229_173 = Coupling(name = 'UVGC_229_173',
                        value = {-1:'(ee*complex(0,1)*G**2*kpTWpL1)/(24.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_229_174 = Coupling(name = 'UVGC_229_174',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTWpL1)/(12.*cmath.pi**2*sw*cmath.sqrt(2))',0:'-(ee*complex(0,1)*G**2*kpTWpL1)/(6.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*kpTWpL1*reglog(MTP/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_229_175 = Coupling(name = 'UVGC_229_175',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTWpL1)/(12.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_230_176 = Coupling(name = 'UVGC_230_176',
                        value = {-1:'(ee*complex(0,1)*G**2*kpTWpL2)/(24.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_230_177 = Coupling(name = 'UVGC_230_177',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTWpL2)/(12.*cmath.pi**2*sw*cmath.sqrt(2))',0:'-(ee*complex(0,1)*G**2*kpTWpL2)/(6.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*kpTWpL2*reglog(MTP/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_230_178 = Coupling(name = 'UVGC_230_178',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTWpL2)/(12.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_231_179 = Coupling(name = 'UVGC_231_179',
                        value = {-1:'(ee*complex(0,1)*G**2*kpTWpL3)/(24.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_231_180 = Coupling(name = 'UVGC_231_180',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTWpL3)/(12.*cmath.pi**2*sw*cmath.sqrt(2))',0:'-(ee*complex(0,1)*G**2*kpTWpL3)/(6.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*kpTWpL3*reglog(MTP/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_231_181 = Coupling(name = 'UVGC_231_181',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTWpL3)/(12.*cmath.pi**2*sw*cmath.sqrt(2))'},
                        order = {'HvQ':1,'QCD':2})

UVGC_232_182 = Coupling(name = 'UVGC_232_182',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZL1)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpTZL1)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpTZL1*reglog(MTP/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_232_183 = Coupling(name = 'UVGC_232_183',
                        value = {-1:'(ee*complex(0,1)*G**2*kpTZL1)/(48.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_232_184 = Coupling(name = 'UVGC_232_184',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZL1)/(24.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_233_185 = Coupling(name = 'UVGC_233_185',
                        value = {-1:'(ee*complex(0,1)*G**2*kpTZL2)/(48.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_233_186 = Coupling(name = 'UVGC_233_186',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZL2)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpTZL2)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpTZL2*reglog(MTP/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_233_187 = Coupling(name = 'UVGC_233_187',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZL2)/(24.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_234_188 = Coupling(name = 'UVGC_234_188',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZL3)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpTZL3)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpTZL3*reglog(MT/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_234_189 = Coupling(name = 'UVGC_234_189',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZL3)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpTZL3)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpTZL3*reglog(MTP/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_234_190 = Coupling(name = 'UVGC_234_190',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZL3)/(24.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_235_191 = Coupling(name = 'UVGC_235_191',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZpL1)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpTZpL1)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpTZpL1*reglog(MTP/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_235_192 = Coupling(name = 'UVGC_235_192',
                        value = {-1:'(ee*complex(0,1)*G**2*kpTZpL1)/(48.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_235_193 = Coupling(name = 'UVGC_235_193',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZpL1)/(24.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_236_194 = Coupling(name = 'UVGC_236_194',
                        value = {-1:'(ee*complex(0,1)*G**2*kpTZpL2)/(48.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_236_195 = Coupling(name = 'UVGC_236_195',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZpL2)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpTZpL2)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpTZpL2*reglog(MTP/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_236_196 = Coupling(name = 'UVGC_236_196',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZpL2)/(24.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_237_197 = Coupling(name = 'UVGC_237_197',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZpL3)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpTZpL3)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpTZpL3*reglog(MT/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_237_198 = Coupling(name = 'UVGC_237_198',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZpL3)/(24.*cw*cmath.pi**2*sw)',0:'-(ee*complex(0,1)*G**2*kpTZpL3)/(12.*cw*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*kpTZpL3*reglog(MTP/MU_R))/(8.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

UVGC_237_199 = Coupling(name = 'UVGC_237_199',
                        value = {-1:'-(ee*complex(0,1)*G**2*kpTZpL3)/(24.*cw*cmath.pi**2*sw)'},
                        order = {'HvQ':1,'QCD':2})

