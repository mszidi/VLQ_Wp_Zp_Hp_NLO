# This file was automatically created by FeynRules 2.3.47
# Mathematica version: 9.0 for Linux x86 (64-bit) (November 20, 2012)
# Date: Sun 20 Jul 2025 09:54:34


from object_library import all_orders, CouplingOrder


HvB = CouplingOrder(name = 'HvB',
                    expansion_order = 99,
                    hierarchy = 1)

HvQ = CouplingOrder(name = 'HvQ',
                    expansion_order = 99,
                    hierarchy = 1)

QCD = CouplingOrder(name = 'QCD',
                    expansion_order = 99,
                    hierarchy = 1,
                    perturbative_expansion = 1)

QED = CouplingOrder(name = 'QED',
                    expansion_order = 99,
                    hierarchy = 2)

