# This file was automatically created by FeynRules 2.3.47
# Mathematica version: 9.0 for Linux x86 (64-bit) (November 20, 2012)
# Date: Sun 20 Jul 2025 09:54:34


from object_library import all_vertices, all_CTvertices, Vertex, CTVertex
import particles as P
import CT_couplings as C
import lorentz as L


V_1 = CTVertex(name = 'V_1',
               type = 'R2',
               particles = [ P.t__tilde__, P.t, P.Hp ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               loop_particles = [ [ [P.g, P.t] ] ],
               couplings = {(0,0,0):C.R2GC_209_129})

V_2 = CTVertex(name = 'V_2',
               type = 'R2',
               particles = [ P.g, P.g, P.g ],
               color = [ 'f(1,2,3)' ],
               lorentz = [ L.VVV2 ],
               loop_particles = [ [ [P.b], [P.bp], [P.c], [P.d], [P.s], [P.t], [P.tp], [P.u] ], [ [P.g] ] ],
               couplings = {(0,0,0):C.R2GC_215_131,(0,0,1):C.R2GC_215_132})

V_3 = CTVertex(name = 'V_3',
               type = 'R2',
               particles = [ P.g, P.g, P.g, P.g ],
               color = [ 'd(-1,1,3)*d(-1,2,4)', 'd(-1,1,3)*f(-1,2,4)', 'd(-1,1,4)*d(-1,2,3)', 'd(-1,1,4)*f(-1,2,3)', 'd(-1,2,3)*f(-1,1,4)', 'd(-1,2,4)*f(-1,1,3)', 'f(-1,1,2)*f(-1,3,4)', 'f(-1,1,3)*f(-1,2,4)', 'f(-1,1,4)*f(-1,2,3)', 'Identity(1,2)*Identity(3,4)', 'Identity(1,3)*Identity(2,4)', 'Identity(1,4)*Identity(2,3)' ],
               lorentz = [ L.VVVV10, L.VVVV2, L.VVVV3, L.VVVV5 ],
               loop_particles = [ [ [P.b], [P.bp], [P.c], [P.d], [P.s], [P.t], [P.tp], [P.u] ], [ [P.g] ] ],
               couplings = {(2,1,0):C.R2GC_142_90,(2,1,1):C.R2GC_142_91,(0,1,0):C.R2GC_142_90,(0,1,1):C.R2GC_142_91,(4,1,0):C.R2GC_140_86,(4,1,1):C.R2GC_140_87,(3,1,0):C.R2GC_140_86,(3,1,1):C.R2GC_140_87,(8,1,0):C.R2GC_141_88,(8,1,1):C.R2GC_141_89,(7,1,0):C.R2GC_146_97,(7,1,1):C.R2GC_219_137,(6,1,0):C.R2GC_145_95,(6,1,1):C.R2GC_220_138,(5,1,0):C.R2GC_140_86,(5,1,1):C.R2GC_140_87,(1,1,0):C.R2GC_140_86,(1,1,1):C.R2GC_140_87,(11,0,0):C.R2GC_144_93,(11,0,1):C.R2GC_144_94,(10,0,0):C.R2GC_144_93,(10,0,1):C.R2GC_144_94,(9,0,1):C.R2GC_143_92,(2,2,0):C.R2GC_142_90,(2,2,1):C.R2GC_142_91,(0,2,0):C.R2GC_142_90,(0,2,1):C.R2GC_142_91,(6,2,0):C.R2GC_216_133,(6,2,1):C.R2GC_216_134,(4,2,0):C.R2GC_140_86,(4,2,1):C.R2GC_140_87,(3,2,0):C.R2GC_140_86,(3,2,1):C.R2GC_140_87,(8,2,0):C.R2GC_141_88,(8,2,1):C.R2GC_221_139,(7,2,0):C.R2GC_146_97,(7,2,1):C.R2GC_146_98,(5,2,0):C.R2GC_140_86,(5,2,1):C.R2GC_140_87,(1,2,0):C.R2GC_140_86,(1,2,1):C.R2GC_140_87,(0,3,0):C.R2GC_142_90,(0,3,1):C.R2GC_142_91,(2,3,0):C.R2GC_142_90,(2,3,1):C.R2GC_142_91,(5,3,0):C.R2GC_140_86,(5,3,1):C.R2GC_140_87,(1,3,0):C.R2GC_140_86,(1,3,1):C.R2GC_140_87,(7,3,0):C.R2GC_217_135,(7,3,1):C.R2GC_142_91,(4,3,0):C.R2GC_140_86,(4,3,1):C.R2GC_140_87,(3,3,0):C.R2GC_140_86,(3,3,1):C.R2GC_140_87,(8,3,0):C.R2GC_141_88,(8,3,1):C.R2GC_218_136,(6,3,0):C.R2GC_145_95,(6,3,1):C.R2GC_145_96})

V_4 = CTVertex(name = 'V_4',
               type = 'R2',
               particles = [ P.bp__tilde__, P.bp, P.a ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFV1 ],
               loop_particles = [ [ [P.bp, P.g] ] ],
               couplings = {(0,0,0):C.R2GC_147_99})

V_5 = CTVertex(name = 'V_5',
               type = 'R2',
               particles = [ P.tp__tilde__, P.tp, P.a ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFV1 ],
               loop_particles = [ [ [P.g, P.tp] ] ],
               couplings = {(0,0,0):C.R2GC_150_102})

V_6 = CTVertex(name = 'V_6',
               type = 'R2',
               particles = [ P.d__tilde__, P.bp, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               loop_particles = [ [ [P.bp, P.d, P.g] ] ],
               couplings = {(0,0,0):C.R2GC_183_108})

V_7 = CTVertex(name = 'V_7',
               type = 'R2',
               particles = [ P.s__tilde__, P.bp, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               loop_particles = [ [ [P.bp, P.g, P.s] ] ],
               couplings = {(0,0,0):C.R2GC_184_109})

V_8 = CTVertex(name = 'V_8',
               type = 'R2',
               particles = [ P.b__tilde__, P.bp, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               loop_particles = [ [ [P.b, P.bp, P.g] ] ],
               couplings = {(0,0,0):C.R2GC_185_110})

V_9 = CTVertex(name = 'V_9',
               type = 'R2',
               particles = [ P.d__tilde__, P.bp, P.Hp ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               loop_particles = [ [ [P.bp, P.d, P.g] ] ],
               couplings = {(0,0,0):C.R2GC_186_111})

V_10 = CTVertex(name = 'V_10',
                type = 'R2',
                particles = [ P.s__tilde__, P.bp, P.Hp ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS2 ],
                loop_particles = [ [ [P.bp, P.g, P.s] ] ],
                couplings = {(0,0,0):C.R2GC_187_112})

V_11 = CTVertex(name = 'V_11',
                type = 'R2',
                particles = [ P.b__tilde__, P.bp, P.Hp ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS2 ],
                loop_particles = [ [ [P.b, P.bp, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_188_113})

V_12 = CTVertex(name = 'V_12',
                type = 'R2',
                particles = [ P.u__tilde__, P.tp, P.H ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS2 ],
                loop_particles = [ [ [P.g, P.tp, P.u] ] ],
                couplings = {(0,0,0):C.R2GC_225_140})

V_13 = CTVertex(name = 'V_13',
                type = 'R2',
                particles = [ P.c__tilde__, P.tp, P.H ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS2 ],
                loop_particles = [ [ [P.c, P.g, P.tp] ] ],
                couplings = {(0,0,0):C.R2GC_226_141})

V_14 = CTVertex(name = 'V_14',
                type = 'R2',
                particles = [ P.t__tilde__, P.tp, P.H ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS2, L.FFS3 ],
                loop_particles = [ [ [P.g, P.t, P.tp] ] ],
                couplings = {(0,0,0):C.R2GC_227_142,(0,1,0):C.R2GC_232_147})

V_15 = CTVertex(name = 'V_15',
                type = 'R2',
                particles = [ P.u__tilde__, P.tp, P.Hp ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS2 ],
                loop_particles = [ [ [P.g, P.tp, P.u] ] ],
                couplings = {(0,0,0):C.R2GC_228_143})

V_16 = CTVertex(name = 'V_16',
                type = 'R2',
                particles = [ P.c__tilde__, P.tp, P.Hp ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS2 ],
                loop_particles = [ [ [P.c, P.g, P.tp] ] ],
                couplings = {(0,0,0):C.R2GC_229_144})

V_17 = CTVertex(name = 'V_17',
                type = 'R2',
                particles = [ P.t__tilde__, P.tp, P.Hp ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS2, L.FFS3 ],
                loop_particles = [ [ [P.g, P.t, P.tp] ] ],
                couplings = {(0,0,0):C.R2GC_230_145,(0,1,0):C.R2GC_231_146})

V_18 = CTVertex(name = 'V_18',
                type = 'R2',
                particles = [ P.tp__tilde__, P.t, P.Hp ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS2, L.FFS3 ],
                loop_particles = [ [ [P.g, P.t, P.tp] ] ],
                couplings = {(0,0,0):C.R2GC_231_146,(0,1,0):C.R2GC_230_145})

V_19 = CTVertex(name = 'V_19',
                type = 'R2',
                particles = [ P.tp__tilde__, P.t, P.H ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS2, L.FFS3 ],
                loop_particles = [ [ [P.g, P.t, P.tp] ] ],
                couplings = {(0,0,0):C.R2GC_232_147,(0,1,0):C.R2GC_227_142})

V_20 = CTVertex(name = 'V_20',
                type = 'R2',
                particles = [ P.b__tilde__, P.b, P.H ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS1 ],
                loop_particles = [ [ [P.b, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_179_107})

V_21 = CTVertex(name = 'V_21',
                type = 'R2',
                particles = [ P.t__tilde__, P.t, P.H ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS1 ],
                loop_particles = [ [ [P.g, P.t] ] ],
                couplings = {(0,0,0):C.R2GC_213_130})

V_22 = CTVertex(name = 'V_22',
                type = 'R2',
                particles = [ P.bp__tilde__, P.d, P.H ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS3 ],
                loop_particles = [ [ [P.bp, P.d, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_183_108})

V_23 = CTVertex(name = 'V_23',
                type = 'R2',
                particles = [ P.bp__tilde__, P.s, P.H ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS3 ],
                loop_particles = [ [ [P.bp, P.g, P.s] ] ],
                couplings = {(0,0,0):C.R2GC_184_109})

V_24 = CTVertex(name = 'V_24',
                type = 'R2',
                particles = [ P.bp__tilde__, P.b, P.H ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS3 ],
                loop_particles = [ [ [P.b, P.bp, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_185_110})

V_25 = CTVertex(name = 'V_25',
                type = 'R2',
                particles = [ P.bp__tilde__, P.d, P.Hp ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS3 ],
                loop_particles = [ [ [P.bp, P.d, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_186_111})

V_26 = CTVertex(name = 'V_26',
                type = 'R2',
                particles = [ P.bp__tilde__, P.s, P.Hp ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS3 ],
                loop_particles = [ [ [P.bp, P.g, P.s] ] ],
                couplings = {(0,0,0):C.R2GC_187_112})

V_27 = CTVertex(name = 'V_27',
                type = 'R2',
                particles = [ P.bp__tilde__, P.b, P.Hp ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS3 ],
                loop_particles = [ [ [P.b, P.bp, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_188_113})

V_28 = CTVertex(name = 'V_28',
                type = 'R2',
                particles = [ P.tp__tilde__, P.u, P.H ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS3 ],
                loop_particles = [ [ [P.g, P.tp, P.u] ] ],
                couplings = {(0,0,0):C.R2GC_225_140})

V_29 = CTVertex(name = 'V_29',
                type = 'R2',
                particles = [ P.tp__tilde__, P.c, P.H ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS3 ],
                loop_particles = [ [ [P.c, P.g, P.tp] ] ],
                couplings = {(0,0,0):C.R2GC_226_141})

V_30 = CTVertex(name = 'V_30',
                type = 'R2',
                particles = [ P.tp__tilde__, P.u, P.Hp ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS3 ],
                loop_particles = [ [ [P.g, P.tp, P.u] ] ],
                couplings = {(0,0,0):C.R2GC_228_143})

V_31 = CTVertex(name = 'V_31',
                type = 'R2',
                particles = [ P.tp__tilde__, P.c, P.Hp ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFS3 ],
                loop_particles = [ [ [P.c, P.g, P.tp] ] ],
                couplings = {(0,0,0):C.R2GC_229_144})

V_32 = CTVertex(name = 'V_32',
                type = 'R2',
                particles = [ P.tp__tilde__, P.tp, P.g ],
                color = [ 'T(3,2,1)' ],
                lorentz = [ L.FFV1 ],
                loop_particles = [ [ [P.g, P.tp] ] ],
                couplings = {(0,0,0):C.R2GC_148_100})

V_33 = CTVertex(name = 'V_33',
                type = 'R2',
                particles = [ P.bp__tilde__, P.bp, P.g ],
                color = [ 'T(3,2,1)' ],
                lorentz = [ L.FFV1 ],
                loop_particles = [ [ [P.bp, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_148_100})

V_34 = CTVertex(name = 'V_34',
                type = 'R2',
                particles = [ P.d__tilde__, P.d, P.Zp ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV5, L.FFV7 ],
                loop_particles = [ [ [P.d, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_89_169,(0,1,0):C.R2GC_90_170})

V_35 = CTVertex(name = 'V_35',
                type = 'R2',
                particles = [ P.s__tilde__, P.s, P.Zp ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3, L.FFV4 ],
                loop_particles = [ [ [P.g, P.s] ] ],
                couplings = {(0,0,0):C.R2GC_112_18,(0,1,0):C.R2GC_111_17})

V_36 = CTVertex(name = 'V_36',
                type = 'R2',
                particles = [ P.b__tilde__, P.b, P.Zp ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3, L.FFV4 ],
                loop_particles = [ [ [P.b, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_112_18,(0,1,0):C.R2GC_111_17})

V_37 = CTVertex(name = 'V_37',
                type = 'R2',
                particles = [ P.u__tilde__, P.u, P.Zp ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3, L.FFV4 ],
                loop_particles = [ [ [P.g, P.u] ] ],
                couplings = {(0,0,0):C.R2GC_108_15,(0,1,0):C.R2GC_107_14})

V_38 = CTVertex(name = 'V_38',
                type = 'R2',
                particles = [ P.c__tilde__, P.c, P.Zp ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3, L.FFV4 ],
                loop_particles = [ [ [P.c, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_108_15,(0,1,0):C.R2GC_107_14})

V_39 = CTVertex(name = 'V_39',
                type = 'R2',
                particles = [ P.t__tilde__, P.t, P.Zp ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3, L.FFV4 ],
                loop_particles = [ [ [P.g, P.t] ] ],
                couplings = {(0,0,0):C.R2GC_108_15,(0,1,0):C.R2GC_107_14})

V_40 = CTVertex(name = 'V_40',
                type = 'R2',
                particles = [ P.bp__tilde__, P.u, P.W__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.bp, P.g, P.u] ] ],
                couplings = {(0,0,0):C.R2GC_190_115})

V_41 = CTVertex(name = 'V_41',
                type = 'R2',
                particles = [ P.bp__tilde__, P.c, P.W__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.bp, P.c, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_191_116})

V_42 = CTVertex(name = 'V_42',
                type = 'R2',
                particles = [ P.bp__tilde__, P.t, P.W__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.bp, P.g, P.t] ] ],
                couplings = {(0,0,0):C.R2GC_205_126})

V_43 = CTVertex(name = 'V_43',
                type = 'R2',
                particles = [ P.d__tilde__, P.tp, P.W__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.d, P.g, P.tp] ] ],
                couplings = {(0,0,0):C.R2GC_234_149})

V_44 = CTVertex(name = 'V_44',
                type = 'R2',
                particles = [ P.s__tilde__, P.tp, P.W__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.g, P.s, P.tp] ] ],
                couplings = {(0,0,0):C.R2GC_235_150})

V_45 = CTVertex(name = 'V_45',
                type = 'R2',
                particles = [ P.b__tilde__, P.tp, P.W__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.b, P.g, P.tp] ] ],
                couplings = {(0,0,0):C.R2GC_236_151})

V_46 = CTVertex(name = 'V_46',
                type = 'R2',
                particles = [ P.u__tilde__, P.bp, P.W__plus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.bp, P.g, P.u] ] ],
                couplings = {(0,0,0):C.R2GC_190_115})

V_47 = CTVertex(name = 'V_47',
                type = 'R2',
                particles = [ P.c__tilde__, P.bp, P.W__plus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.bp, P.c, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_191_116})

V_48 = CTVertex(name = 'V_48',
                type = 'R2',
                particles = [ P.t__tilde__, P.bp, P.W__plus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.bp, P.g, P.t] ] ],
                couplings = {(0,0,0):C.R2GC_205_126})

V_49 = CTVertex(name = 'V_49',
                type = 'R2',
                particles = [ P.tp__tilde__, P.d, P.W__plus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.d, P.g, P.tp] ] ],
                couplings = {(0,0,0):C.R2GC_234_149})

V_50 = CTVertex(name = 'V_50',
                type = 'R2',
                particles = [ P.tp__tilde__, P.s, P.W__plus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.g, P.s, P.tp] ] ],
                couplings = {(0,0,0):C.R2GC_235_150})

V_51 = CTVertex(name = 'V_51',
                type = 'R2',
                particles = [ P.tp__tilde__, P.b, P.W__plus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.b, P.g, P.tp] ] ],
                couplings = {(0,0,0):C.R2GC_236_151})

V_52 = CTVertex(name = 'V_52',
                type = 'R2',
                particles = [ P.d__tilde__, P.u, P.Wp__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.d, P.g, P.u] ] ],
                couplings = {(0,0,0):C.R2GC_168_104})

V_53 = CTVertex(name = 'V_53',
                type = 'R2',
                particles = [ P.s__tilde__, P.c, P.Wp__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.c, P.g, P.s] ] ],
                couplings = {(0,0,0):C.R2GC_168_104})

V_54 = CTVertex(name = 'V_54',
                type = 'R2',
                particles = [ P.b__tilde__, P.t, P.Wp__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.b, P.g, P.t] ] ],
                couplings = {(0,0,0):C.R2GC_168_104})

V_55 = CTVertex(name = 'V_55',
                type = 'R2',
                particles = [ P.bp__tilde__, P.u, P.Wp__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.bp, P.g, P.u] ] ],
                couplings = {(0,0,0):C.R2GC_192_117})

V_56 = CTVertex(name = 'V_56',
                type = 'R2',
                particles = [ P.bp__tilde__, P.c, P.Wp__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.bp, P.c, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_193_118})

V_57 = CTVertex(name = 'V_57',
                type = 'R2',
                particles = [ P.bp__tilde__, P.t, P.Wp__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.bp, P.g, P.t] ] ],
                couplings = {(0,0,0):C.R2GC_206_127})

V_58 = CTVertex(name = 'V_58',
                type = 'R2',
                particles = [ P.d__tilde__, P.tp, P.Wp__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.d, P.g, P.tp] ] ],
                couplings = {(0,0,0):C.R2GC_237_152})

V_59 = CTVertex(name = 'V_59',
                type = 'R2',
                particles = [ P.s__tilde__, P.tp, P.Wp__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.g, P.s, P.tp] ] ],
                couplings = {(0,0,0):C.R2GC_238_153})

V_60 = CTVertex(name = 'V_60',
                type = 'R2',
                particles = [ P.b__tilde__, P.tp, P.Wp__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.b, P.g, P.tp] ] ],
                couplings = {(0,0,0):C.R2GC_239_154})

V_61 = CTVertex(name = 'V_61',
                type = 'R2',
                particles = [ P.u__tilde__, P.d, P.Wp__plus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.d, P.g, P.u] ] ],
                couplings = {(0,0,0):C.R2GC_168_104})

V_62 = CTVertex(name = 'V_62',
                type = 'R2',
                particles = [ P.c__tilde__, P.s, P.Wp__plus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.c, P.g, P.s] ] ],
                couplings = {(0,0,0):C.R2GC_168_104})

V_63 = CTVertex(name = 'V_63',
                type = 'R2',
                particles = [ P.t__tilde__, P.b, P.Wp__plus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.b, P.g, P.t] ] ],
                couplings = {(0,0,0):C.R2GC_168_104})

V_64 = CTVertex(name = 'V_64',
                type = 'R2',
                particles = [ P.u__tilde__, P.bp, P.Wp__plus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.bp, P.g, P.u] ] ],
                couplings = {(0,0,0):C.R2GC_192_117})

V_65 = CTVertex(name = 'V_65',
                type = 'R2',
                particles = [ P.c__tilde__, P.bp, P.Wp__plus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.bp, P.c, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_193_118})

V_66 = CTVertex(name = 'V_66',
                type = 'R2',
                particles = [ P.t__tilde__, P.bp, P.Wp__plus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.bp, P.g, P.t] ] ],
                couplings = {(0,0,0):C.R2GC_206_127})

V_67 = CTVertex(name = 'V_67',
                type = 'R2',
                particles = [ P.tp__tilde__, P.d, P.Wp__plus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.d, P.g, P.tp] ] ],
                couplings = {(0,0,0):C.R2GC_237_152})

V_68 = CTVertex(name = 'V_68',
                type = 'R2',
                particles = [ P.tp__tilde__, P.s, P.Wp__plus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.g, P.s, P.tp] ] ],
                couplings = {(0,0,0):C.R2GC_238_153})

V_69 = CTVertex(name = 'V_69',
                type = 'R2',
                particles = [ P.tp__tilde__, P.b, P.Wp__plus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.b, P.g, P.tp] ] ],
                couplings = {(0,0,0):C.R2GC_239_154})

V_70 = CTVertex(name = 'V_70',
                type = 'R2',
                particles = [ P.d__tilde__, P.bp, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.bp, P.d, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_194_119})

V_71 = CTVertex(name = 'V_71',
                type = 'R2',
                particles = [ P.bp__tilde__, P.d, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.bp, P.d, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_194_119})

V_72 = CTVertex(name = 'V_72',
                type = 'R2',
                particles = [ P.s__tilde__, P.bp, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.bp, P.g, P.s] ] ],
                couplings = {(0,0,0):C.R2GC_195_120})

V_73 = CTVertex(name = 'V_73',
                type = 'R2',
                particles = [ P.bp__tilde__, P.s, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.bp, P.g, P.s] ] ],
                couplings = {(0,0,0):C.R2GC_195_120})

V_74 = CTVertex(name = 'V_74',
                type = 'R2',
                particles = [ P.bp__tilde__, P.b, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.b, P.bp, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_196_121})

V_75 = CTVertex(name = 'V_75',
                type = 'R2',
                particles = [ P.b__tilde__, P.bp, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.b, P.bp, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_196_121})

V_76 = CTVertex(name = 'V_76',
                type = 'R2',
                particles = [ P.u__tilde__, P.tp, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3, L.FFV4 ],
                loop_particles = [ [ [P.g, P.tp, P.u] ] ],
                couplings = {(0,0,0):C.R2GC_240_155,(0,1,0):C.R2GC_249_164})

V_77 = CTVertex(name = 'V_77',
                type = 'R2',
                particles = [ P.tp__tilde__, P.u, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3, L.FFV4 ],
                loop_particles = [ [ [P.g, P.tp, P.u] ] ],
                couplings = {(0,0,0):C.R2GC_240_155,(0,1,0):C.R2GC_249_164})

V_78 = CTVertex(name = 'V_78',
                type = 'R2',
                particles = [ P.tp__tilde__, P.c, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3, L.FFV4 ],
                loop_particles = [ [ [P.c, P.g, P.tp] ] ],
                couplings = {(0,0,0):C.R2GC_241_156,(0,1,0):C.R2GC_250_165})

V_79 = CTVertex(name = 'V_79',
                type = 'R2',
                particles = [ P.c__tilde__, P.tp, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3, L.FFV4 ],
                loop_particles = [ [ [P.c, P.g, P.tp] ] ],
                couplings = {(0,0,0):C.R2GC_241_156,(0,1,0):C.R2GC_250_165})

V_80 = CTVertex(name = 'V_80',
                type = 'R2',
                particles = [ P.tp__tilde__, P.t, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3, L.FFV4 ],
                loop_particles = [ [ [P.g, P.t, P.tp] ] ],
                couplings = {(0,0,0):C.R2GC_242_157,(0,1,0):C.R2GC_251_166})

V_81 = CTVertex(name = 'V_81',
                type = 'R2',
                particles = [ P.t__tilde__, P.tp, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3, L.FFV4 ],
                loop_particles = [ [ [P.g, P.t, P.tp] ] ],
                couplings = {(0,0,0):C.R2GC_242_157,(0,1,0):C.R2GC_251_166})

V_82 = CTVertex(name = 'V_82',
                type = 'R2',
                particles = [ P.d__tilde__, P.bp, P.Zp ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.bp, P.d, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_197_122})

V_83 = CTVertex(name = 'V_83',
                type = 'R2',
                particles = [ P.bp__tilde__, P.d, P.Zp ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.bp, P.d, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_197_122})

V_84 = CTVertex(name = 'V_84',
                type = 'R2',
                particles = [ P.s__tilde__, P.bp, P.Zp ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.bp, P.g, P.s] ] ],
                couplings = {(0,0,0):C.R2GC_198_123})

V_85 = CTVertex(name = 'V_85',
                type = 'R2',
                particles = [ P.bp__tilde__, P.s, P.Zp ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.bp, P.g, P.s] ] ],
                couplings = {(0,0,0):C.R2GC_198_123})

V_86 = CTVertex(name = 'V_86',
                type = 'R2',
                particles = [ P.bp__tilde__, P.b, P.Zp ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.b, P.bp, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_199_124})

V_87 = CTVertex(name = 'V_87',
                type = 'R2',
                particles = [ P.b__tilde__, P.bp, P.Zp ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.b, P.bp, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_199_124})

V_88 = CTVertex(name = 'V_88',
                type = 'R2',
                particles = [ P.u__tilde__, P.tp, P.Zp ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3, L.FFV4 ],
                loop_particles = [ [ [P.g, P.tp, P.u] ] ],
                couplings = {(0,0,0):C.R2GC_243_158,(0,1,0):C.R2GC_246_161})

V_89 = CTVertex(name = 'V_89',
                type = 'R2',
                particles = [ P.tp__tilde__, P.u, P.Zp ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3, L.FFV4 ],
                loop_particles = [ [ [P.g, P.tp, P.u] ] ],
                couplings = {(0,0,0):C.R2GC_243_158,(0,1,0):C.R2GC_246_161})

V_90 = CTVertex(name = 'V_90',
                type = 'R2',
                particles = [ P.tp__tilde__, P.c, P.Zp ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3, L.FFV4 ],
                loop_particles = [ [ [P.c, P.g, P.tp] ] ],
                couplings = {(0,0,0):C.R2GC_244_159,(0,1,0):C.R2GC_247_162})

V_91 = CTVertex(name = 'V_91',
                type = 'R2',
                particles = [ P.c__tilde__, P.tp, P.Zp ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3, L.FFV4 ],
                loop_particles = [ [ [P.c, P.g, P.tp] ] ],
                couplings = {(0,0,0):C.R2GC_244_159,(0,1,0):C.R2GC_247_162})

V_92 = CTVertex(name = 'V_92',
                type = 'R2',
                particles = [ P.tp__tilde__, P.t, P.Zp ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3, L.FFV4 ],
                loop_particles = [ [ [P.g, P.t, P.tp] ] ],
                couplings = {(0,0,0):C.R2GC_245_160,(0,1,0):C.R2GC_248_163})

V_93 = CTVertex(name = 'V_93',
                type = 'R2',
                particles = [ P.t__tilde__, P.tp, P.Zp ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3, L.FFV4 ],
                loop_particles = [ [ [P.g, P.t, P.tp] ] ],
                couplings = {(0,0,0):C.R2GC_245_160,(0,1,0):C.R2GC_248_163})

V_94 = CTVertex(name = 'V_94',
                type = 'R2',
                particles = [ P.u__tilde__, P.u, P.a ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                loop_particles = [ [ [P.g, P.u] ] ],
                couplings = {(0,0,0):C.R2GC_150_102})

V_95 = CTVertex(name = 'V_95',
                type = 'R2',
                particles = [ P.c__tilde__, P.c, P.a ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                loop_particles = [ [ [P.c, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_150_102})

V_96 = CTVertex(name = 'V_96',
                type = 'R2',
                particles = [ P.t__tilde__, P.t, P.a ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                loop_particles = [ [ [P.g, P.t] ] ],
                couplings = {(0,0,0):C.R2GC_150_102})

V_97 = CTVertex(name = 'V_97',
                type = 'R2',
                particles = [ P.d__tilde__, P.d, P.a ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                loop_particles = [ [ [P.d, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_147_99})

V_98 = CTVertex(name = 'V_98',
                type = 'R2',
                particles = [ P.s__tilde__, P.s, P.a ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                loop_particles = [ [ [P.g, P.s] ] ],
                couplings = {(0,0,0):C.R2GC_147_99})

V_99 = CTVertex(name = 'V_99',
                type = 'R2',
                particles = [ P.b__tilde__, P.b, P.a ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                loop_particles = [ [ [P.b, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_147_99})

V_100 = CTVertex(name = 'V_100',
                 type = 'R2',
                 particles = [ P.u__tilde__, P.u, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV1 ],
                 loop_particles = [ [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.R2GC_148_100})

V_101 = CTVertex(name = 'V_101',
                 type = 'R2',
                 particles = [ P.c__tilde__, P.c, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV1 ],
                 loop_particles = [ [ [P.c, P.g] ] ],
                 couplings = {(0,0,0):C.R2GC_148_100})

V_102 = CTVertex(name = 'V_102',
                 type = 'R2',
                 particles = [ P.t__tilde__, P.t, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV1 ],
                 loop_particles = [ [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.R2GC_148_100})

V_103 = CTVertex(name = 'V_103',
                 type = 'R2',
                 particles = [ P.d__tilde__, P.d, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV1 ],
                 loop_particles = [ [ [P.d, P.g] ] ],
                 couplings = {(0,0,0):C.R2GC_148_100})

V_104 = CTVertex(name = 'V_104',
                 type = 'R2',
                 particles = [ P.s__tilde__, P.s, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV1 ],
                 loop_particles = [ [ [P.g, P.s] ] ],
                 couplings = {(0,0,0):C.R2GC_148_100})

V_105 = CTVertex(name = 'V_105',
                 type = 'R2',
                 particles = [ P.b__tilde__, P.b, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV1 ],
                 loop_particles = [ [ [P.b, P.g] ] ],
                 couplings = {(0,0,0):C.R2GC_148_100})

V_106 = CTVertex(name = 'V_106',
                 type = 'R2',
                 particles = [ P.d__tilde__, P.u, P.W__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.d, P.g, P.u] ] ],
                 couplings = {(0,0,0):C.R2GC_167_103})

V_107 = CTVertex(name = 'V_107',
                 type = 'R2',
                 particles = [ P.s__tilde__, P.c, P.W__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.c, P.g, P.s] ] ],
                 couplings = {(0,0,0):C.R2GC_167_103})

V_108 = CTVertex(name = 'V_108',
                 type = 'R2',
                 particles = [ P.b__tilde__, P.t, P.W__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.b, P.g, P.t] ] ],
                 couplings = {(0,0,0):C.R2GC_167_103})

V_109 = CTVertex(name = 'V_109',
                 type = 'R2',
                 particles = [ P.u__tilde__, P.d, P.W__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.d, P.g, P.u] ] ],
                 couplings = {(0,0,0):C.R2GC_167_103})

V_110 = CTVertex(name = 'V_110',
                 type = 'R2',
                 particles = [ P.c__tilde__, P.s, P.W__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.c, P.g, P.s] ] ],
                 couplings = {(0,0,0):C.R2GC_167_103})

V_111 = CTVertex(name = 'V_111',
                 type = 'R2',
                 particles = [ P.t__tilde__, P.b, P.W__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.b, P.g, P.t] ] ],
                 couplings = {(0,0,0):C.R2GC_167_103})

V_112 = CTVertex(name = 'V_112',
                 type = 'R2',
                 particles = [ P.u__tilde__, P.u, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.R2GC_106_13,(0,1,0):C.R2GC_208_128})

V_113 = CTVertex(name = 'V_113',
                 type = 'R2',
                 particles = [ P.c__tilde__, P.c, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.c, P.g] ] ],
                 couplings = {(0,0,0):C.R2GC_106_13,(0,1,0):C.R2GC_208_128})

V_114 = CTVertex(name = 'V_114',
                 type = 'R2',
                 particles = [ P.t__tilde__, P.t, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.R2GC_106_13,(0,1,0):C.R2GC_208_128})

V_115 = CTVertex(name = 'V_115',
                 type = 'R2',
                 particles = [ P.d__tilde__, P.d, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.d, P.g] ] ],
                 couplings = {(0,0,0):C.R2GC_109_16,(0,1,0):C.R2GC_176_106})

V_116 = CTVertex(name = 'V_116',
                 type = 'R2',
                 particles = [ P.s__tilde__, P.s, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.g, P.s] ] ],
                 couplings = {(0,0,0):C.R2GC_109_16,(0,1,0):C.R2GC_176_106})

V_117 = CTVertex(name = 'V_117',
                 type = 'R2',
                 particles = [ P.b__tilde__, P.b, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.b, P.g] ] ],
                 couplings = {(0,0,0):C.R2GC_109_16,(0,1,0):C.R2GC_176_106})

V_118 = CTVertex(name = 'V_118',
                 type = 'R2',
                 particles = [ P.u__tilde__, P.u ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF1 ],
                 loop_particles = [ [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.R2GC_149_101})

V_119 = CTVertex(name = 'V_119',
                 type = 'R2',
                 particles = [ P.c__tilde__, P.c ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF1 ],
                 loop_particles = [ [ [P.c, P.g] ] ],
                 couplings = {(0,0,0):C.R2GC_149_101})

V_120 = CTVertex(name = 'V_120',
                 type = 'R2',
                 particles = [ P.t__tilde__, P.t ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF2, L.FF3, L.FF4, L.FF6 ],
                 loop_particles = [ [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.R2GC_203_125,(0,2,0):C.R2GC_203_125,(0,1,0):C.R2GC_149_101,(0,3,0):C.R2GC_149_101})

V_121 = CTVertex(name = 'V_121',
                 type = 'R2',
                 particles = [ P.d__tilde__, P.d ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF1 ],
                 loop_particles = [ [ [P.d, P.g] ] ],
                 couplings = {(0,0,0):C.R2GC_149_101})

V_122 = CTVertex(name = 'V_122',
                 type = 'R2',
                 particles = [ P.s__tilde__, P.s ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF1 ],
                 loop_particles = [ [ [P.g, P.s] ] ],
                 couplings = {(0,0,0):C.R2GC_149_101})

V_123 = CTVertex(name = 'V_123',
                 type = 'R2',
                 particles = [ P.b__tilde__, P.b ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF5, L.FF7 ],
                 loop_particles = [ [ [P.b, P.g] ] ],
                 couplings = {(0,0,0):C.R2GC_174_105,(0,1,0):C.R2GC_149_101})

V_124 = CTVertex(name = 'V_124',
                 type = 'R2',
                 particles = [ P.tp__tilde__, P.tp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF5, L.FF7 ],
                 loop_particles = [ [ [P.g, P.tp] ] ],
                 couplings = {(0,0,0):C.R2GC_233_148,(0,1,0):C.R2GC_149_101})

V_125 = CTVertex(name = 'V_125',
                 type = 'R2',
                 particles = [ P.bp__tilde__, P.bp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF5, L.FF7 ],
                 loop_particles = [ [ [P.bp, P.g] ] ],
                 couplings = {(0,0,0):C.R2GC_189_114,(0,1,0):C.R2GC_149_101})

V_126 = CTVertex(name = 'V_126',
                 type = 'R2',
                 particles = [ P.g, P.g ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VV2, L.VV3, L.VV4 ],
                 loop_particles = [ [ [P.b] ], [ [P.bp] ], [ [P.b], [P.bp], [P.c], [P.d], [P.s], [P.t], [P.tp], [P.u] ], [ [P.g] ], [ [P.t] ], [ [P.tp] ] ],
                 couplings = {(0,2,3):C.R2GC_83_167,(0,0,0):C.R2GC_96_173,(0,0,1):C.R2GC_96_174,(0,0,4):C.R2GC_96_175,(0,0,5):C.R2GC_96_176,(0,1,2):C.R2GC_97_177})

V_127 = CTVertex(name = 'V_127',
                 type = 'R2',
                 particles = [ P.g, P.g, P.H ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VVS1 ],
                 loop_particles = [ [ [P.b] ], [ [P.t] ] ],
                 couplings = {(0,0,0):C.R2GC_95_171,(0,0,1):C.R2GC_95_172})

V_128 = CTVertex(name = 'V_128',
                 type = 'R2',
                 particles = [ P.g, P.g, P.Hp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VVS1 ],
                 loop_particles = [ [ [P.t] ] ],
                 couplings = {(0,0,0):C.R2GC_84_168})

V_129 = CTVertex(name = 'V_129',
                 type = 'R2',
                 particles = [ P.g, P.g, P.Zp, P.Zp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VVVV10 ],
                 loop_particles = [ [ [P.b, P.bp] ], [ [P.b], [P.d], [P.s] ], [ [P.bp, P.d] ], [ [P.bp, P.s] ], [ [P.c, P.tp] ], [ [P.c], [P.t], [P.u] ], [ [P.tp, P.u] ], [ [P.t, P.tp] ] ],
                 couplings = {(0,0,1):C.R2GC_122_62,(0,0,5):C.R2GC_122_63,(0,0,0):C.R2GC_122_64,(0,0,2):C.R2GC_122_65,(0,0,3):C.R2GC_122_66,(0,0,4):C.R2GC_122_67,(0,0,7):C.R2GC_122_68,(0,0,6):C.R2GC_122_69})

V_130 = CTVertex(name = 'V_130',
                 type = 'R2',
                 particles = [ P.g, P.g, P.W__plus__, P.Wp__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VVVV10 ],
                 loop_particles = [ [ [P.bp, P.c] ], [ [P.bp, P.t] ], [ [P.bp, P.u] ], [ [P.b, P.tp] ], [ [P.b, P.t], [P.c, P.s], [P.d, P.u] ], [ [P.d, P.tp] ], [ [P.s, P.tp] ] ],
                 couplings = {(0,0,4):C.R2GC_114_26,(0,0,3):C.R2GC_114_27,(0,0,0):C.R2GC_114_28,(0,0,1):C.R2GC_114_29,(0,0,2):C.R2GC_114_30,(0,0,5):C.R2GC_114_31,(0,0,6):C.R2GC_114_32})

V_131 = CTVertex(name = 'V_131',
                 type = 'R2',
                 particles = [ P.g, P.g, P.Wp__minus__, P.Wp__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VVVV10 ],
                 loop_particles = [ [ [P.bp, P.c] ], [ [P.bp, P.t] ], [ [P.bp, P.u] ], [ [P.b, P.tp] ], [ [P.b, P.t], [P.c, P.s], [P.d, P.u] ], [ [P.d, P.tp] ], [ [P.s, P.tp] ] ],
                 couplings = {(0,0,4):C.R2GC_115_33,(0,0,3):C.R2GC_115_34,(0,0,0):C.R2GC_115_35,(0,0,1):C.R2GC_115_36,(0,0,2):C.R2GC_115_37,(0,0,5):C.R2GC_115_38,(0,0,6):C.R2GC_115_39})

V_132 = CTVertex(name = 'V_132',
                 type = 'R2',
                 particles = [ P.g, P.g, P.Z, P.Zp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VVVV10 ],
                 loop_particles = [ [ [P.b, P.bp] ], [ [P.b], [P.d], [P.s] ], [ [P.bp, P.d] ], [ [P.bp, P.s] ], [ [P.c, P.tp] ], [ [P.c], [P.t], [P.u] ], [ [P.tp, P.u] ], [ [P.t, P.tp] ] ],
                 couplings = {(0,0,1):C.R2GC_123_70,(0,0,5):C.R2GC_123_71,(0,0,0):C.R2GC_123_72,(0,0,2):C.R2GC_123_73,(0,0,3):C.R2GC_123_74,(0,0,4):C.R2GC_123_75,(0,0,7):C.R2GC_123_76,(0,0,6):C.R2GC_123_77})

V_133 = CTVertex(name = 'V_133',
                 type = 'R2',
                 particles = [ P.a, P.g, P.g, P.Zp ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VVVV10 ],
                 loop_particles = [ [ [P.b], [P.d], [P.s] ], [ [P.c], [P.t], [P.u] ] ],
                 couplings = {(0,0,0):C.R2GC_104_9,(0,0,1):C.R2GC_104_10})

V_134 = CTVertex(name = 'V_134',
                 type = 'R2',
                 particles = [ P.g, P.g, P.g, P.Zp ],
                 color = [ 'd(1,2,3)', 'f(1,2,3)' ],
                 lorentz = [ L.VVVV1, L.VVVV10 ],
                 loop_particles = [ [ [P.b], [P.d], [P.s] ], [ [P.c], [P.t], [P.u] ] ],
                 couplings = {(1,0,0):C.R2GC_103_7,(1,0,1):C.R2GC_103_8,(0,1,0):C.R2GC_105_11,(0,1,1):C.R2GC_105_12})

V_135 = CTVertex(name = 'V_135',
                 type = 'R2',
                 particles = [ P.g, P.g, P.W__minus__, P.W__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VVVV10 ],
                 loop_particles = [ [ [P.bp, P.c] ], [ [P.bp, P.t] ], [ [P.bp, P.u] ], [ [P.b, P.tp] ], [ [P.b, P.t], [P.c, P.s], [P.d, P.u] ], [ [P.d, P.tp] ], [ [P.s, P.tp] ] ],
                 couplings = {(0,0,4):C.R2GC_113_19,(0,0,3):C.R2GC_113_20,(0,0,0):C.R2GC_113_21,(0,0,1):C.R2GC_113_22,(0,0,2):C.R2GC_113_23,(0,0,5):C.R2GC_113_24,(0,0,6):C.R2GC_113_25})

V_136 = CTVertex(name = 'V_136',
                 type = 'R2',
                 particles = [ P.g, P.g, P.W__minus__, P.Wp__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VVVV10 ],
                 loop_particles = [ [ [P.bp, P.c] ], [ [P.bp, P.t] ], [ [P.bp, P.u] ], [ [P.b, P.tp] ], [ [P.b, P.t], [P.c, P.s], [P.d, P.u] ], [ [P.d, P.tp] ], [ [P.s, P.tp] ] ],
                 couplings = {(0,0,4):C.R2GC_114_26,(0,0,3):C.R2GC_114_27,(0,0,0):C.R2GC_114_28,(0,0,1):C.R2GC_114_29,(0,0,2):C.R2GC_114_30,(0,0,5):C.R2GC_114_31,(0,0,6):C.R2GC_114_32})

V_137 = CTVertex(name = 'V_137',
                 type = 'R2',
                 particles = [ P.g, P.g, P.Z, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VVVV10 ],
                 loop_particles = [ [ [P.b, P.bp] ], [ [P.b], [P.d], [P.s] ], [ [P.bp, P.d] ], [ [P.bp, P.s] ], [ [P.c, P.tp] ], [ [P.c], [P.t], [P.u] ], [ [P.tp, P.u] ], [ [P.t, P.tp] ] ],
                 couplings = {(0,0,1):C.R2GC_124_78,(0,0,5):C.R2GC_124_79,(0,0,0):C.R2GC_124_80,(0,0,2):C.R2GC_124_81,(0,0,3):C.R2GC_124_82,(0,0,4):C.R2GC_124_83,(0,0,7):C.R2GC_124_84,(0,0,6):C.R2GC_124_85})

V_138 = CTVertex(name = 'V_138',
                 type = 'R2',
                 particles = [ P.a, P.g, P.g, P.Z ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VVVV10 ],
                 loop_particles = [ [ [P.b], [P.d], [P.s] ], [ [P.c], [P.t], [P.u] ] ],
                 couplings = {(0,0,0):C.R2GC_100_1,(0,0,1):C.R2GC_100_2})

V_139 = CTVertex(name = 'V_139',
                 type = 'R2',
                 particles = [ P.a, P.a, P.g, P.g ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVVV10 ],
                 loop_particles = [ [ [P.b], [P.bp], [P.d], [P.s] ], [ [P.c], [P.t], [P.tp], [P.u] ] ],
                 couplings = {(0,0,0):C.R2GC_98_178,(0,0,1):C.R2GC_98_179})

V_140 = CTVertex(name = 'V_140',
                 type = 'R2',
                 particles = [ P.g, P.g, P.g, P.Z ],
                 color = [ 'd(1,2,3)', 'f(1,2,3)' ],
                 lorentz = [ L.VVVV1, L.VVVV10 ],
                 loop_particles = [ [ [P.b], [P.d], [P.s] ], [ [P.c], [P.t], [P.u] ] ],
                 couplings = {(1,0,0):C.R2GC_102_5,(1,0,1):C.R2GC_102_6,(0,1,0):C.R2GC_101_3,(0,1,1):C.R2GC_101_4})

V_141 = CTVertex(name = 'V_141',
                 type = 'R2',
                 particles = [ P.a, P.g, P.g, P.g ],
                 color = [ 'd(2,3,4)' ],
                 lorentz = [ L.VVVV10 ],
                 loop_particles = [ [ [P.b], [P.bp], [P.d], [P.s] ], [ [P.c], [P.t], [P.tp], [P.u] ] ],
                 couplings = {(0,0,0):C.R2GC_99_180,(0,0,1):C.R2GC_99_181})

V_142 = CTVertex(name = 'V_142',
                 type = 'R2',
                 particles = [ P.g, P.g, P.H, P.H ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b] ], [ [P.b, P.bp] ], [ [P.bp, P.d] ], [ [P.bp, P.s] ], [ [P.c, P.tp] ], [ [P.t] ], [ [P.tp, P.u] ], [ [P.t, P.tp] ] ],
                 couplings = {(0,0,0):C.R2GC_119_40,(0,0,5):C.R2GC_119_41,(0,0,1):C.R2GC_119_42,(0,0,2):C.R2GC_119_43,(0,0,3):C.R2GC_119_44,(0,0,4):C.R2GC_119_45,(0,0,7):C.R2GC_119_46,(0,0,6):C.R2GC_119_47})

V_143 = CTVertex(name = 'V_143',
                 type = 'R2',
                 particles = [ P.g, P.g, P.H, P.Hp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.bp] ], [ [P.bp, P.d] ], [ [P.bp, P.s] ], [ [P.c, P.tp] ], [ [P.t] ], [ [P.tp, P.u] ], [ [P.t, P.tp] ] ],
                 couplings = {(0,0,4):C.R2GC_120_48,(0,0,0):C.R2GC_120_49,(0,0,1):C.R2GC_120_50,(0,0,2):C.R2GC_120_51,(0,0,3):C.R2GC_120_52,(0,0,6):C.R2GC_120_53,(0,0,5):C.R2GC_120_54})

V_144 = CTVertex(name = 'V_144',
                 type = 'R2',
                 particles = [ P.g, P.g, P.Hp, P.Hp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.bp] ], [ [P.bp, P.d] ], [ [P.bp, P.s] ], [ [P.c, P.tp] ], [ [P.t] ], [ [P.tp, P.u] ], [ [P.t, P.tp] ] ],
                 couplings = {(0,0,4):C.R2GC_121_55,(0,0,0):C.R2GC_121_56,(0,0,1):C.R2GC_121_57,(0,0,2):C.R2GC_121_58,(0,0,3):C.R2GC_121_59,(0,0,6):C.R2GC_121_60,(0,0,5):C.R2GC_121_61})

V_145 = CTVertex(name = 'V_145',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.t, P.Hp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS1 ],
                 loop_particles = [ [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.UVGC_209_108})

V_146 = CTVertex(name = 'V_146',
                 type = 'UV',
                 particles = [ P.g, P.g, P.g ],
                 color = [ 'f(1,2,3)' ],
                 lorentz = [ L.VVV1, L.VVV2, L.VVV3 ],
                 loop_particles = [ [ [P.b] ], [ [P.bp] ], [ [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.t] ], [ [P.tp] ] ],
                 couplings = {(0,1,0):C.UVGC_215_118,(0,1,1):C.UVGC_215_119,(0,1,2):C.UVGC_215_120,(0,1,5):C.UVGC_215_121,(0,1,6):C.UVGC_215_122,(0,2,3):C.UVGC_125_1,(0,0,4):C.UVGC_126_2})

V_147 = CTVertex(name = 'V_147',
                 type = 'UV',
                 particles = [ P.g, P.g, P.g, P.g ],
                 color = [ 'd(-1,1,3)*d(-1,2,4)', 'd(-1,1,3)*f(-1,2,4)', 'd(-1,1,4)*d(-1,2,3)', 'd(-1,1,4)*f(-1,2,3)', 'd(-1,2,3)*f(-1,1,4)', 'd(-1,2,4)*f(-1,1,3)', 'f(-1,1,2)*f(-1,3,4)', 'f(-1,1,3)*f(-1,2,4)', 'f(-1,1,4)*f(-1,2,3)', 'Identity(1,2)*Identity(3,4)', 'Identity(1,3)*Identity(2,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.VVVV10, L.VVVV2, L.VVVV3, L.VVVV5 ],
                 loop_particles = [ [ [P.b] ], [ [P.bp] ], [ [P.b], [P.bp], [P.c], [P.d], [P.s], [P.t], [P.tp], [P.u] ], [ [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.t] ], [ [P.tp] ] ],
                 couplings = {(2,1,4):C.UVGC_141_14,(2,1,5):C.UVGC_141_13,(0,1,4):C.UVGC_141_14,(0,1,5):C.UVGC_141_13,(4,1,4):C.UVGC_140_11,(4,1,5):C.UVGC_140_12,(3,1,4):C.UVGC_140_11,(3,1,5):C.UVGC_140_12,(8,1,4):C.UVGC_141_13,(8,1,5):C.UVGC_141_14,(7,1,0):C.UVGC_219_138,(7,1,1):C.UVGC_219_139,(7,1,3):C.UVGC_219_140,(7,1,4):C.UVGC_219_141,(7,1,5):C.UVGC_219_142,(7,1,6):C.UVGC_219_143,(7,1,7):C.UVGC_219_144,(6,1,0):C.UVGC_219_138,(6,1,1):C.UVGC_219_139,(6,1,3):C.UVGC_219_140,(6,1,4):C.UVGC_220_145,(6,1,5):C.UVGC_220_146,(6,1,6):C.UVGC_219_143,(6,1,7):C.UVGC_219_144,(5,1,4):C.UVGC_140_11,(5,1,5):C.UVGC_140_12,(1,1,4):C.UVGC_140_11,(1,1,5):C.UVGC_140_12,(11,0,4):C.UVGC_144_17,(11,0,5):C.UVGC_144_18,(10,0,4):C.UVGC_144_17,(10,0,5):C.UVGC_144_18,(9,0,4):C.UVGC_143_15,(9,0,5):C.UVGC_143_16,(2,2,4):C.UVGC_141_14,(2,2,5):C.UVGC_141_13,(0,2,4):C.UVGC_141_14,(0,2,5):C.UVGC_141_13,(6,2,0):C.UVGC_216_123,(6,2,1):C.UVGC_216_124,(6,2,4):C.UVGC_216_125,(6,2,5):C.UVGC_216_126,(6,2,6):C.UVGC_216_127,(6,2,7):C.UVGC_216_128,(4,2,4):C.UVGC_140_11,(4,2,5):C.UVGC_140_12,(3,2,4):C.UVGC_140_11,(3,2,5):C.UVGC_140_12,(8,2,0):C.UVGC_221_147,(8,2,1):C.UVGC_221_148,(8,2,3):C.UVGC_221_149,(8,2,4):C.UVGC_221_150,(8,2,5):C.UVGC_221_151,(8,2,6):C.UVGC_221_152,(8,2,7):C.UVGC_221_153,(7,2,2):C.UVGC_145_19,(7,2,4):C.UVGC_146_21,(7,2,5):C.UVGC_146_22,(5,2,4):C.UVGC_140_11,(5,2,5):C.UVGC_140_12,(1,2,4):C.UVGC_140_11,(1,2,5):C.UVGC_140_12,(0,3,4):C.UVGC_141_14,(0,3,5):C.UVGC_141_13,(2,3,4):C.UVGC_141_14,(2,3,5):C.UVGC_141_13,(5,3,4):C.UVGC_140_11,(5,3,5):C.UVGC_140_12,(1,3,4):C.UVGC_140_11,(1,3,5):C.UVGC_140_12,(7,3,0):C.UVGC_216_123,(7,3,1):C.UVGC_216_124,(7,3,4):C.UVGC_217_129,(7,3,5):C.UVGC_217_130,(7,3,6):C.UVGC_216_127,(7,3,7):C.UVGC_216_128,(4,3,4):C.UVGC_140_11,(4,3,5):C.UVGC_140_12,(3,3,4):C.UVGC_140_11,(3,3,5):C.UVGC_140_12,(8,3,0):C.UVGC_218_131,(8,3,1):C.UVGC_218_132,(8,3,3):C.UVGC_218_133,(8,3,4):C.UVGC_218_134,(8,3,5):C.UVGC_218_135,(8,3,6):C.UVGC_218_136,(8,3,7):C.UVGC_218_137,(6,3,2):C.UVGC_145_19,(6,3,4):C.UVGC_145_20,(6,3,5):C.UVGC_143_15})

V_148 = CTVertex(name = 'V_148',
                 type = 'UV',
                 particles = [ P.bp__tilde__, P.bp, P.a ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV7, L.FFV8 ],
                 loop_particles = [ [ [P.bp, P.g] ] ],
                 couplings = {(0,1,0):C.UVGC_127_3,(0,0,0):C.UVGC_181_43})

V_149 = CTVertex(name = 'V_149',
                 type = 'UV',
                 particles = [ P.tp__tilde__, P.tp, P.a ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV7, L.FFV8 ],
                 loop_particles = [ [ [P.g, P.tp] ] ],
                 couplings = {(0,1,0):C.UVGC_135_8,(0,0,0):C.UVGC_223_155})

V_150 = CTVertex(name = 'V_150',
                 type = 'UV',
                 particles = [ P.d__tilde__, P.bp, P.H ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS2 ],
                 loop_particles = [ [ [P.bp, P.d, P.g] ], [ [P.bp, P.g] ], [ [P.d, P.g] ] ],
                 couplings = {(0,0,1):C.UVGC_183_45,(0,0,2):C.UVGC_183_46,(0,0,0):C.UVGC_183_47})

V_151 = CTVertex(name = 'V_151',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.bp, P.H ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS2 ],
                 loop_particles = [ [ [P.bp, P.g] ], [ [P.bp, P.g, P.s] ], [ [P.g, P.s] ] ],
                 couplings = {(0,0,0):C.UVGC_184_48,(0,0,2):C.UVGC_184_49,(0,0,1):C.UVGC_184_50})

V_152 = CTVertex(name = 'V_152',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.bp, P.H ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS2 ],
                 loop_particles = [ [ [P.b, P.bp, P.g] ], [ [P.b, P.g] ], [ [P.bp, P.g] ] ],
                 couplings = {(0,0,1):C.UVGC_185_51,(0,0,2):C.UVGC_185_52,(0,0,0):C.UVGC_185_53})

V_153 = CTVertex(name = 'V_153',
                 type = 'UV',
                 particles = [ P.d__tilde__, P.bp, P.Hp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS2 ],
                 loop_particles = [ [ [P.bp, P.d, P.g] ], [ [P.bp, P.g] ], [ [P.d, P.g] ] ],
                 couplings = {(0,0,1):C.UVGC_186_54,(0,0,2):C.UVGC_186_55,(0,0,0):C.UVGC_186_56})

V_154 = CTVertex(name = 'V_154',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.bp, P.Hp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS2 ],
                 loop_particles = [ [ [P.bp, P.g] ], [ [P.bp, P.g, P.s] ], [ [P.g, P.s] ] ],
                 couplings = {(0,0,0):C.UVGC_187_57,(0,0,2):C.UVGC_187_58,(0,0,1):C.UVGC_187_59})

V_155 = CTVertex(name = 'V_155',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.bp, P.Hp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS2 ],
                 loop_particles = [ [ [P.b, P.bp, P.g] ], [ [P.b, P.g] ], [ [P.bp, P.g] ] ],
                 couplings = {(0,0,1):C.UVGC_188_60,(0,0,2):C.UVGC_188_61,(0,0,0):C.UVGC_188_62})

V_156 = CTVertex(name = 'V_156',
                 type = 'UV',
                 particles = [ P.u__tilde__, P.tp, P.H ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS2 ],
                 loop_particles = [ [ [P.g, P.tp] ], [ [P.g, P.tp, P.u] ], [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_225_157,(0,0,2):C.UVGC_225_158,(0,0,1):C.UVGC_225_159})

V_157 = CTVertex(name = 'V_157',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.tp, P.H ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS2 ],
                 loop_particles = [ [ [P.c, P.g] ], [ [P.c, P.g, P.tp] ], [ [P.g, P.tp] ] ],
                 couplings = {(0,0,0):C.UVGC_226_160,(0,0,2):C.UVGC_226_161,(0,0,1):C.UVGC_226_162})

V_158 = CTVertex(name = 'V_158',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.tp, P.H ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS2, L.FFS3 ],
                 loop_particles = [ [ [P.g, P.t] ], [ [P.g, P.tp] ], [ [P.g, P.t, P.tp] ] ],
                 couplings = {(0,0,0):C.UVGC_227_163,(0,0,1):C.UVGC_227_164,(0,0,2):C.UVGC_227_165,(0,1,0):C.UVGC_232_178,(0,1,1):C.UVGC_232_179,(0,1,2):C.UVGC_232_180})

V_159 = CTVertex(name = 'V_159',
                 type = 'UV',
                 particles = [ P.u__tilde__, P.tp, P.Hp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS2 ],
                 loop_particles = [ [ [P.g, P.tp] ], [ [P.g, P.tp, P.u] ], [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_228_166,(0,0,2):C.UVGC_228_167,(0,0,1):C.UVGC_228_168})

V_160 = CTVertex(name = 'V_160',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.tp, P.Hp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS2 ],
                 loop_particles = [ [ [P.c, P.g] ], [ [P.c, P.g, P.tp] ], [ [P.g, P.tp] ] ],
                 couplings = {(0,0,0):C.UVGC_229_169,(0,0,2):C.UVGC_229_170,(0,0,1):C.UVGC_229_171})

V_161 = CTVertex(name = 'V_161',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.tp, P.Hp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS2, L.FFS3 ],
                 loop_particles = [ [ [P.g, P.t] ], [ [P.g, P.tp] ], [ [P.g, P.t, P.tp] ] ],
                 couplings = {(0,0,0):C.UVGC_230_172,(0,0,1):C.UVGC_230_173,(0,0,2):C.UVGC_230_174,(0,1,0):C.UVGC_231_175,(0,1,1):C.UVGC_231_176,(0,1,2):C.UVGC_231_177})

V_162 = CTVertex(name = 'V_162',
                 type = 'UV',
                 particles = [ P.tp__tilde__, P.t, P.Hp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS2, L.FFS3 ],
                 loop_particles = [ [ [P.g, P.t] ], [ [P.g, P.tp] ], [ [P.g, P.t, P.tp] ] ],
                 couplings = {(0,0,0):C.UVGC_231_175,(0,0,1):C.UVGC_231_176,(0,0,2):C.UVGC_231_177,(0,1,0):C.UVGC_230_172,(0,1,1):C.UVGC_230_173,(0,1,2):C.UVGC_230_174})

V_163 = CTVertex(name = 'V_163',
                 type = 'UV',
                 particles = [ P.tp__tilde__, P.t, P.H ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS2, L.FFS3 ],
                 loop_particles = [ [ [P.g, P.t] ], [ [P.g, P.tp] ], [ [P.g, P.t, P.tp] ] ],
                 couplings = {(0,0,0):C.UVGC_232_178,(0,0,1):C.UVGC_232_179,(0,0,2):C.UVGC_232_180,(0,1,0):C.UVGC_227_163,(0,1,1):C.UVGC_227_164,(0,1,2):C.UVGC_227_165})

V_164 = CTVertex(name = 'V_164',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.b, P.H ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS1 ],
                 loop_particles = [ [ [P.b, P.g] ] ],
                 couplings = {(0,0,0):C.UVGC_179_41})

V_165 = CTVertex(name = 'V_165',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.t, P.H ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS1 ],
                 loop_particles = [ [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.UVGC_213_113})

V_166 = CTVertex(name = 'V_166',
                 type = 'UV',
                 particles = [ P.bp__tilde__, P.d, P.H ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS3 ],
                 loop_particles = [ [ [P.bp, P.d, P.g] ], [ [P.bp, P.g] ], [ [P.d, P.g] ] ],
                 couplings = {(0,0,1):C.UVGC_183_45,(0,0,2):C.UVGC_183_46,(0,0,0):C.UVGC_183_47})

V_167 = CTVertex(name = 'V_167',
                 type = 'UV',
                 particles = [ P.bp__tilde__, P.s, P.H ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS3 ],
                 loop_particles = [ [ [P.bp, P.g] ], [ [P.bp, P.g, P.s] ], [ [P.g, P.s] ] ],
                 couplings = {(0,0,0):C.UVGC_184_48,(0,0,2):C.UVGC_184_49,(0,0,1):C.UVGC_184_50})

V_168 = CTVertex(name = 'V_168',
                 type = 'UV',
                 particles = [ P.bp__tilde__, P.b, P.H ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS3 ],
                 loop_particles = [ [ [P.b, P.bp, P.g] ], [ [P.b, P.g] ], [ [P.bp, P.g] ] ],
                 couplings = {(0,0,1):C.UVGC_185_51,(0,0,2):C.UVGC_185_52,(0,0,0):C.UVGC_185_53})

V_169 = CTVertex(name = 'V_169',
                 type = 'UV',
                 particles = [ P.bp__tilde__, P.d, P.Hp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS3 ],
                 loop_particles = [ [ [P.bp, P.d, P.g] ], [ [P.bp, P.g] ], [ [P.d, P.g] ] ],
                 couplings = {(0,0,1):C.UVGC_186_54,(0,0,2):C.UVGC_186_55,(0,0,0):C.UVGC_186_56})

V_170 = CTVertex(name = 'V_170',
                 type = 'UV',
                 particles = [ P.bp__tilde__, P.s, P.Hp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS3 ],
                 loop_particles = [ [ [P.bp, P.g] ], [ [P.bp, P.g, P.s] ], [ [P.g, P.s] ] ],
                 couplings = {(0,0,0):C.UVGC_187_57,(0,0,2):C.UVGC_187_58,(0,0,1):C.UVGC_187_59})

V_171 = CTVertex(name = 'V_171',
                 type = 'UV',
                 particles = [ P.bp__tilde__, P.b, P.Hp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS3 ],
                 loop_particles = [ [ [P.b, P.bp, P.g] ], [ [P.b, P.g] ], [ [P.bp, P.g] ] ],
                 couplings = {(0,0,1):C.UVGC_188_60,(0,0,2):C.UVGC_188_61,(0,0,0):C.UVGC_188_62})

V_172 = CTVertex(name = 'V_172',
                 type = 'UV',
                 particles = [ P.tp__tilde__, P.u, P.H ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS3 ],
                 loop_particles = [ [ [P.g, P.tp] ], [ [P.g, P.tp, P.u] ], [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_225_157,(0,0,2):C.UVGC_225_158,(0,0,1):C.UVGC_225_159})

V_173 = CTVertex(name = 'V_173',
                 type = 'UV',
                 particles = [ P.tp__tilde__, P.c, P.H ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS3 ],
                 loop_particles = [ [ [P.c, P.g] ], [ [P.c, P.g, P.tp] ], [ [P.g, P.tp] ] ],
                 couplings = {(0,0,0):C.UVGC_226_160,(0,0,2):C.UVGC_226_161,(0,0,1):C.UVGC_226_162})

V_174 = CTVertex(name = 'V_174',
                 type = 'UV',
                 particles = [ P.tp__tilde__, P.u, P.Hp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS3 ],
                 loop_particles = [ [ [P.g, P.tp] ], [ [P.g, P.tp, P.u] ], [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_228_166,(0,0,2):C.UVGC_228_167,(0,0,1):C.UVGC_228_168})

V_175 = CTVertex(name = 'V_175',
                 type = 'UV',
                 particles = [ P.tp__tilde__, P.c, P.Hp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS3 ],
                 loop_particles = [ [ [P.c, P.g] ], [ [P.c, P.g, P.tp] ], [ [P.g, P.tp] ] ],
                 couplings = {(0,0,0):C.UVGC_229_169,(0,0,2):C.UVGC_229_170,(0,0,1):C.UVGC_229_171})

V_176 = CTVertex(name = 'V_176',
                 type = 'UV',
                 particles = [ P.tp__tilde__, P.tp, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV6, L.FFV7 ],
                 loop_particles = [ [ [P.b] ], [ [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.tp] ] ],
                 couplings = {(0,0,4):C.UVGC_128_4,(0,1,0):C.UVGC_151_24,(0,1,1):C.UVGC_151_25,(0,1,2):C.UVGC_151_26,(0,1,3):C.UVGC_151_27,(0,1,4):C.UVGC_224_156})

V_177 = CTVertex(name = 'V_177',
                 type = 'UV',
                 particles = [ P.bp__tilde__, P.bp, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV6, L.FFV7 ],
                 loop_particles = [ [ [P.b] ], [ [P.bp, P.g] ], [ [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ] ],
                 couplings = {(0,0,1):C.UVGC_128_4,(0,1,0):C.UVGC_151_24,(0,1,2):C.UVGC_151_25,(0,1,3):C.UVGC_151_26,(0,1,4):C.UVGC_151_27,(0,1,1):C.UVGC_182_44})

V_178 = CTVertex(name = 'V_178',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.b, P.Zp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.b, P.g] ] ],
                 couplings = {(0,0,0):C.UVGC_177_39,(0,1,0):C.UVGC_178_40})

V_179 = CTVertex(name = 'V_179',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.t, P.Zp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.UVGC_211_111,(0,1,0):C.UVGC_212_112})

V_180 = CTVertex(name = 'V_180',
                 type = 'UV',
                 particles = [ P.bp__tilde__, P.u, P.W__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.bp, P.g] ], [ [P.bp, P.g, P.u] ], [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_190_64,(0,0,2):C.UVGC_190_65,(0,0,1):C.UVGC_190_66})

V_181 = CTVertex(name = 'V_181',
                 type = 'UV',
                 particles = [ P.bp__tilde__, P.c, P.W__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.bp, P.c, P.g] ], [ [P.bp, P.g] ], [ [P.c, P.g] ] ],
                 couplings = {(0,0,1):C.UVGC_191_67,(0,0,2):C.UVGC_191_68,(0,0,0):C.UVGC_191_69})

V_182 = CTVertex(name = 'V_182',
                 type = 'UV',
                 particles = [ P.bp__tilde__, P.t, P.W__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.bp, P.g] ], [ [P.bp, P.g, P.t] ], [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.UVGC_205_100,(0,0,2):C.UVGC_205_101,(0,0,1):C.UVGC_205_102})

V_183 = CTVertex(name = 'V_183',
                 type = 'UV',
                 particles = [ P.d__tilde__, P.tp, P.W__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.d, P.g] ], [ [P.d, P.g, P.tp] ], [ [P.g, P.tp] ] ],
                 couplings = {(0,0,0):C.UVGC_234_182,(0,0,2):C.UVGC_234_183,(0,0,1):C.UVGC_234_184})

V_184 = CTVertex(name = 'V_184',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.tp, P.W__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.g, P.s] ], [ [P.g, P.s, P.tp] ], [ [P.g, P.tp] ] ],
                 couplings = {(0,0,0):C.UVGC_235_185,(0,0,2):C.UVGC_235_186,(0,0,1):C.UVGC_235_187})

V_185 = CTVertex(name = 'V_185',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.tp, P.W__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.b, P.g] ], [ [P.b, P.g, P.tp] ], [ [P.g, P.tp] ] ],
                 couplings = {(0,0,0):C.UVGC_236_188,(0,0,2):C.UVGC_236_189,(0,0,1):C.UVGC_236_190})

V_186 = CTVertex(name = 'V_186',
                 type = 'UV',
                 particles = [ P.u__tilde__, P.bp, P.W__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.bp, P.g] ], [ [P.bp, P.g, P.u] ], [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_190_64,(0,0,2):C.UVGC_190_65,(0,0,1):C.UVGC_190_66})

V_187 = CTVertex(name = 'V_187',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.bp, P.W__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.bp, P.c, P.g] ], [ [P.bp, P.g] ], [ [P.c, P.g] ] ],
                 couplings = {(0,0,1):C.UVGC_191_67,(0,0,2):C.UVGC_191_68,(0,0,0):C.UVGC_191_69})

V_188 = CTVertex(name = 'V_188',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.bp, P.W__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.bp, P.g] ], [ [P.bp, P.g, P.t] ], [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.UVGC_205_100,(0,0,2):C.UVGC_205_101,(0,0,1):C.UVGC_205_102})

V_189 = CTVertex(name = 'V_189',
                 type = 'UV',
                 particles = [ P.tp__tilde__, P.d, P.W__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.d, P.g] ], [ [P.d, P.g, P.tp] ], [ [P.g, P.tp] ] ],
                 couplings = {(0,0,0):C.UVGC_234_182,(0,0,2):C.UVGC_234_183,(0,0,1):C.UVGC_234_184})

V_190 = CTVertex(name = 'V_190',
                 type = 'UV',
                 particles = [ P.tp__tilde__, P.s, P.W__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.g, P.s] ], [ [P.g, P.s, P.tp] ], [ [P.g, P.tp] ] ],
                 couplings = {(0,0,0):C.UVGC_235_185,(0,0,2):C.UVGC_235_186,(0,0,1):C.UVGC_235_187})

V_191 = CTVertex(name = 'V_191',
                 type = 'UV',
                 particles = [ P.tp__tilde__, P.b, P.W__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.b, P.g] ], [ [P.b, P.g, P.tp] ], [ [P.g, P.tp] ] ],
                 couplings = {(0,0,0):C.UVGC_236_188,(0,0,2):C.UVGC_236_189,(0,0,1):C.UVGC_236_190})

V_192 = CTVertex(name = 'V_192',
                 type = 'UV',
                 particles = [ P.d__tilde__, P.u, P.Wp__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.d, P.g], [P.g, P.u] ], [ [P.d, P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_168_31,(0,0,1):C.UVGC_168_32})

V_193 = CTVertex(name = 'V_193',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.c, P.Wp__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.c, P.g], [P.g, P.s] ], [ [P.c, P.g, P.s] ] ],
                 couplings = {(0,0,0):C.UVGC_168_31,(0,0,1):C.UVGC_168_32})

V_194 = CTVertex(name = 'V_194',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.t, P.Wp__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.b, P.g] ], [ [P.b, P.g, P.t] ], [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.UVGC_210_109,(0,0,2):C.UVGC_210_110,(0,0,1):C.UVGC_168_32})

V_195 = CTVertex(name = 'V_195',
                 type = 'UV',
                 particles = [ P.bp__tilde__, P.u, P.Wp__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.bp, P.g] ], [ [P.bp, P.g, P.u] ], [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_192_70,(0,0,2):C.UVGC_192_71,(0,0,1):C.UVGC_192_72})

V_196 = CTVertex(name = 'V_196',
                 type = 'UV',
                 particles = [ P.bp__tilde__, P.c, P.Wp__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.bp, P.c, P.g] ], [ [P.bp, P.g] ], [ [P.c, P.g] ] ],
                 couplings = {(0,0,1):C.UVGC_193_73,(0,0,2):C.UVGC_193_74,(0,0,0):C.UVGC_193_75})

V_197 = CTVertex(name = 'V_197',
                 type = 'UV',
                 particles = [ P.bp__tilde__, P.t, P.Wp__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.bp, P.g] ], [ [P.bp, P.g, P.t] ], [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.UVGC_206_103,(0,0,2):C.UVGC_206_104,(0,0,1):C.UVGC_206_105})

V_198 = CTVertex(name = 'V_198',
                 type = 'UV',
                 particles = [ P.d__tilde__, P.tp, P.Wp__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.d, P.g] ], [ [P.d, P.g, P.tp] ], [ [P.g, P.tp] ] ],
                 couplings = {(0,0,0):C.UVGC_237_191,(0,0,2):C.UVGC_237_192,(0,0,1):C.UVGC_237_193})

V_199 = CTVertex(name = 'V_199',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.tp, P.Wp__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.g, P.s] ], [ [P.g, P.s, P.tp] ], [ [P.g, P.tp] ] ],
                 couplings = {(0,0,0):C.UVGC_238_194,(0,0,2):C.UVGC_238_195,(0,0,1):C.UVGC_238_196})

V_200 = CTVertex(name = 'V_200',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.tp, P.Wp__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.b, P.g] ], [ [P.b, P.g, P.tp] ], [ [P.g, P.tp] ] ],
                 couplings = {(0,0,0):C.UVGC_239_197,(0,0,2):C.UVGC_239_198,(0,0,1):C.UVGC_239_199})

V_201 = CTVertex(name = 'V_201',
                 type = 'UV',
                 particles = [ P.u__tilde__, P.d, P.Wp__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.d, P.g], [P.g, P.u] ], [ [P.d, P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_168_31,(0,0,1):C.UVGC_168_32})

V_202 = CTVertex(name = 'V_202',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.s, P.Wp__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.c, P.g], [P.g, P.s] ], [ [P.c, P.g, P.s] ] ],
                 couplings = {(0,0,0):C.UVGC_168_31,(0,0,1):C.UVGC_168_32})

V_203 = CTVertex(name = 'V_203',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.b, P.Wp__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.b, P.g] ], [ [P.b, P.g, P.t] ], [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.UVGC_210_109,(0,0,2):C.UVGC_210_110,(0,0,1):C.UVGC_168_32})

V_204 = CTVertex(name = 'V_204',
                 type = 'UV',
                 particles = [ P.u__tilde__, P.bp, P.Wp__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.bp, P.g] ], [ [P.bp, P.g, P.u] ], [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_192_70,(0,0,2):C.UVGC_192_71,(0,0,1):C.UVGC_192_72})

V_205 = CTVertex(name = 'V_205',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.bp, P.Wp__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.bp, P.c, P.g] ], [ [P.bp, P.g] ], [ [P.c, P.g] ] ],
                 couplings = {(0,0,1):C.UVGC_193_73,(0,0,2):C.UVGC_193_74,(0,0,0):C.UVGC_193_75})

V_206 = CTVertex(name = 'V_206',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.bp, P.Wp__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.bp, P.g] ], [ [P.bp, P.g, P.t] ], [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.UVGC_206_103,(0,0,2):C.UVGC_206_104,(0,0,1):C.UVGC_206_105})

V_207 = CTVertex(name = 'V_207',
                 type = 'UV',
                 particles = [ P.tp__tilde__, P.d, P.Wp__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.d, P.g] ], [ [P.d, P.g, P.tp] ], [ [P.g, P.tp] ] ],
                 couplings = {(0,0,0):C.UVGC_237_191,(0,0,2):C.UVGC_237_192,(0,0,1):C.UVGC_237_193})

V_208 = CTVertex(name = 'V_208',
                 type = 'UV',
                 particles = [ P.tp__tilde__, P.s, P.Wp__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.g, P.s] ], [ [P.g, P.s, P.tp] ], [ [P.g, P.tp] ] ],
                 couplings = {(0,0,0):C.UVGC_238_194,(0,0,2):C.UVGC_238_195,(0,0,1):C.UVGC_238_196})

V_209 = CTVertex(name = 'V_209',
                 type = 'UV',
                 particles = [ P.tp__tilde__, P.b, P.Wp__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.b, P.g] ], [ [P.b, P.g, P.tp] ], [ [P.g, P.tp] ] ],
                 couplings = {(0,0,0):C.UVGC_239_197,(0,0,2):C.UVGC_239_198,(0,0,1):C.UVGC_239_199})

V_210 = CTVertex(name = 'V_210',
                 type = 'UV',
                 particles = [ P.d__tilde__, P.bp, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.bp, P.d, P.g] ], [ [P.bp, P.g] ], [ [P.d, P.g] ] ],
                 couplings = {(0,0,1):C.UVGC_194_76,(0,0,2):C.UVGC_194_77,(0,0,0):C.UVGC_194_78})

V_211 = CTVertex(name = 'V_211',
                 type = 'UV',
                 particles = [ P.bp__tilde__, P.d, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.bp, P.d, P.g] ], [ [P.bp, P.g] ], [ [P.d, P.g] ] ],
                 couplings = {(0,0,1):C.UVGC_194_76,(0,0,2):C.UVGC_194_77,(0,0,0):C.UVGC_194_78})

V_212 = CTVertex(name = 'V_212',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.bp, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.bp, P.g] ], [ [P.bp, P.g, P.s] ], [ [P.g, P.s] ] ],
                 couplings = {(0,0,0):C.UVGC_195_79,(0,0,2):C.UVGC_195_80,(0,0,1):C.UVGC_195_81})

V_213 = CTVertex(name = 'V_213',
                 type = 'UV',
                 particles = [ P.bp__tilde__, P.s, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.bp, P.g] ], [ [P.bp, P.g, P.s] ], [ [P.g, P.s] ] ],
                 couplings = {(0,0,0):C.UVGC_195_79,(0,0,2):C.UVGC_195_80,(0,0,1):C.UVGC_195_81})

V_214 = CTVertex(name = 'V_214',
                 type = 'UV',
                 particles = [ P.bp__tilde__, P.b, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.b, P.bp, P.g] ], [ [P.b, P.g] ], [ [P.bp, P.g] ] ],
                 couplings = {(0,0,1):C.UVGC_196_82,(0,0,2):C.UVGC_196_83,(0,0,0):C.UVGC_196_84})

V_215 = CTVertex(name = 'V_215',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.bp, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.b, P.bp, P.g] ], [ [P.b, P.g] ], [ [P.bp, P.g] ] ],
                 couplings = {(0,0,1):C.UVGC_196_82,(0,0,2):C.UVGC_196_83,(0,0,0):C.UVGC_196_84})

V_216 = CTVertex(name = 'V_216',
                 type = 'UV',
                 particles = [ P.u__tilde__, P.tp, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.g, P.tp] ], [ [P.g, P.tp, P.u] ], [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_240_200,(0,0,2):C.UVGC_240_201,(0,0,1):C.UVGC_240_202,(0,1,0):C.UVGC_249_227,(0,1,2):C.UVGC_249_228,(0,1,1):C.UVGC_249_229})

V_217 = CTVertex(name = 'V_217',
                 type = 'UV',
                 particles = [ P.tp__tilde__, P.u, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.g, P.tp] ], [ [P.g, P.tp, P.u] ], [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_240_200,(0,0,2):C.UVGC_240_201,(0,0,1):C.UVGC_240_202,(0,1,0):C.UVGC_249_227,(0,1,2):C.UVGC_249_228,(0,1,1):C.UVGC_249_229})

V_218 = CTVertex(name = 'V_218',
                 type = 'UV',
                 particles = [ P.tp__tilde__, P.c, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.c, P.g] ], [ [P.c, P.g, P.tp] ], [ [P.g, P.tp] ] ],
                 couplings = {(0,0,0):C.UVGC_241_203,(0,0,2):C.UVGC_241_204,(0,0,1):C.UVGC_241_205,(0,1,0):C.UVGC_250_230,(0,1,2):C.UVGC_250_231,(0,1,1):C.UVGC_250_232})

V_219 = CTVertex(name = 'V_219',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.tp, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.c, P.g] ], [ [P.c, P.g, P.tp] ], [ [P.g, P.tp] ] ],
                 couplings = {(0,0,0):C.UVGC_241_203,(0,0,2):C.UVGC_241_204,(0,0,1):C.UVGC_241_205,(0,1,0):C.UVGC_250_230,(0,1,2):C.UVGC_250_231,(0,1,1):C.UVGC_250_232})

V_220 = CTVertex(name = 'V_220',
                 type = 'UV',
                 particles = [ P.tp__tilde__, P.t, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.g, P.t] ], [ [P.g, P.tp] ], [ [P.g, P.t, P.tp] ] ],
                 couplings = {(0,0,0):C.UVGC_242_206,(0,0,1):C.UVGC_242_207,(0,0,2):C.UVGC_242_208,(0,1,0):C.UVGC_251_233,(0,1,1):C.UVGC_251_234,(0,1,2):C.UVGC_251_235})

V_221 = CTVertex(name = 'V_221',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.tp, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.g, P.t] ], [ [P.g, P.tp] ], [ [P.g, P.t, P.tp] ] ],
                 couplings = {(0,0,0):C.UVGC_242_206,(0,0,1):C.UVGC_242_207,(0,0,2):C.UVGC_242_208,(0,1,0):C.UVGC_251_233,(0,1,1):C.UVGC_251_234,(0,1,2):C.UVGC_251_235})

V_222 = CTVertex(name = 'V_222',
                 type = 'UV',
                 particles = [ P.d__tilde__, P.bp, P.Zp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.bp, P.d, P.g] ], [ [P.bp, P.g] ], [ [P.d, P.g] ] ],
                 couplings = {(0,0,1):C.UVGC_197_85,(0,0,2):C.UVGC_197_86,(0,0,0):C.UVGC_197_87})

V_223 = CTVertex(name = 'V_223',
                 type = 'UV',
                 particles = [ P.bp__tilde__, P.d, P.Zp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.bp, P.d, P.g] ], [ [P.bp, P.g] ], [ [P.d, P.g] ] ],
                 couplings = {(0,0,1):C.UVGC_197_85,(0,0,2):C.UVGC_197_86,(0,0,0):C.UVGC_197_87})

V_224 = CTVertex(name = 'V_224',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.bp, P.Zp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.bp, P.g] ], [ [P.bp, P.g, P.s] ], [ [P.g, P.s] ] ],
                 couplings = {(0,0,0):C.UVGC_198_88,(0,0,2):C.UVGC_198_89,(0,0,1):C.UVGC_198_90})

V_225 = CTVertex(name = 'V_225',
                 type = 'UV',
                 particles = [ P.bp__tilde__, P.s, P.Zp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.bp, P.g] ], [ [P.bp, P.g, P.s] ], [ [P.g, P.s] ] ],
                 couplings = {(0,0,0):C.UVGC_198_88,(0,0,2):C.UVGC_198_89,(0,0,1):C.UVGC_198_90})

V_226 = CTVertex(name = 'V_226',
                 type = 'UV',
                 particles = [ P.bp__tilde__, P.b, P.Zp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.b, P.bp, P.g] ], [ [P.b, P.g] ], [ [P.bp, P.g] ] ],
                 couplings = {(0,0,1):C.UVGC_199_91,(0,0,2):C.UVGC_199_92,(0,0,0):C.UVGC_199_93})

V_227 = CTVertex(name = 'V_227',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.bp, P.Zp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.b, P.bp, P.g] ], [ [P.b, P.g] ], [ [P.bp, P.g] ] ],
                 couplings = {(0,0,1):C.UVGC_199_91,(0,0,2):C.UVGC_199_92,(0,0,0):C.UVGC_199_93})

V_228 = CTVertex(name = 'V_228',
                 type = 'UV',
                 particles = [ P.u__tilde__, P.tp, P.Zp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.g, P.tp] ], [ [P.g, P.tp, P.u] ], [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_243_209,(0,0,2):C.UVGC_243_210,(0,0,1):C.UVGC_243_211,(0,1,0):C.UVGC_246_218,(0,1,2):C.UVGC_246_219,(0,1,1):C.UVGC_246_220})

V_229 = CTVertex(name = 'V_229',
                 type = 'UV',
                 particles = [ P.tp__tilde__, P.u, P.Zp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.g, P.tp] ], [ [P.g, P.tp, P.u] ], [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_243_209,(0,0,2):C.UVGC_243_210,(0,0,1):C.UVGC_243_211,(0,1,0):C.UVGC_246_218,(0,1,2):C.UVGC_246_219,(0,1,1):C.UVGC_246_220})

V_230 = CTVertex(name = 'V_230',
                 type = 'UV',
                 particles = [ P.tp__tilde__, P.c, P.Zp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.c, P.g] ], [ [P.c, P.g, P.tp] ], [ [P.g, P.tp] ] ],
                 couplings = {(0,0,0):C.UVGC_244_212,(0,0,2):C.UVGC_244_213,(0,0,1):C.UVGC_244_214,(0,1,0):C.UVGC_247_221,(0,1,2):C.UVGC_247_222,(0,1,1):C.UVGC_247_223})

V_231 = CTVertex(name = 'V_231',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.tp, P.Zp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.c, P.g] ], [ [P.c, P.g, P.tp] ], [ [P.g, P.tp] ] ],
                 couplings = {(0,0,0):C.UVGC_244_212,(0,0,2):C.UVGC_244_213,(0,0,1):C.UVGC_244_214,(0,1,0):C.UVGC_247_221,(0,1,2):C.UVGC_247_222,(0,1,1):C.UVGC_247_223})

V_232 = CTVertex(name = 'V_232',
                 type = 'UV',
                 particles = [ P.tp__tilde__, P.t, P.Zp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.g, P.t] ], [ [P.g, P.tp] ], [ [P.g, P.t, P.tp] ] ],
                 couplings = {(0,0,0):C.UVGC_245_215,(0,0,1):C.UVGC_245_216,(0,0,2):C.UVGC_245_217,(0,1,0):C.UVGC_248_224,(0,1,1):C.UVGC_248_225,(0,1,2):C.UVGC_248_226})

V_233 = CTVertex(name = 'V_233',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.tp, P.Zp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.g, P.t] ], [ [P.g, P.tp] ], [ [P.g, P.t, P.tp] ] ],
                 couplings = {(0,0,0):C.UVGC_245_215,(0,0,1):C.UVGC_245_216,(0,0,2):C.UVGC_245_217,(0,1,0):C.UVGC_248_224,(0,1,1):C.UVGC_248_225,(0,1,2):C.UVGC_248_226})

V_234 = CTVertex(name = 'V_234',
                 type = 'UV',
                 particles = [ P.u__tilde__, P.u, P.a ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV1, L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_135_8,(0,1,0):C.UVGC_130_6,(0,2,0):C.UVGC_130_6})

V_235 = CTVertex(name = 'V_235',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.c, P.a ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV1, L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.c, P.g] ] ],
                 couplings = {(0,0,0):C.UVGC_135_8,(0,1,0):C.UVGC_130_6,(0,2,0):C.UVGC_130_6})

V_236 = CTVertex(name = 'V_236',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.t, P.a ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV1, L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.UVGC_135_8,(0,1,0):C.UVGC_201_95,(0,2,0):C.UVGC_201_95})

V_237 = CTVertex(name = 'V_237',
                 type = 'UV',
                 particles = [ P.d__tilde__, P.d, P.a ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV1, L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.d, P.g] ] ],
                 couplings = {(0,0,0):C.UVGC_127_3,(0,1,0):C.UVGC_132_7,(0,2,0):C.UVGC_132_7})

V_238 = CTVertex(name = 'V_238',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.s, P.a ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV1, L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.g, P.s] ] ],
                 couplings = {(0,0,0):C.UVGC_127_3,(0,1,0):C.UVGC_132_7,(0,2,0):C.UVGC_132_7})

V_239 = CTVertex(name = 'V_239',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.b, P.a ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV1, L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.b, P.g] ] ],
                 couplings = {(0,0,0):C.UVGC_127_3,(0,1,0):C.UVGC_172_34,(0,2,0):C.UVGC_172_34})

V_240 = CTVertex(name = 'V_240',
                 type = 'UV',
                 particles = [ P.u__tilde__, P.u, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV1, L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.b] ], [ [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.u] ] ],
                 couplings = {(0,0,4):C.UVGC_128_4,(0,1,0):C.UVGC_151_24,(0,1,1):C.UVGC_151_25,(0,1,2):C.UVGC_151_26,(0,1,3):C.UVGC_151_27,(0,1,4):C.UVGC_151_28,(0,2,0):C.UVGC_151_24,(0,2,1):C.UVGC_151_25,(0,2,2):C.UVGC_151_26,(0,2,3):C.UVGC_151_27,(0,2,4):C.UVGC_151_28})

V_241 = CTVertex(name = 'V_241',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.c, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV1, L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.b] ], [ [P.c], [P.d], [P.s], [P.u] ], [ [P.c, P.g] ], [ [P.g] ], [ [P.ghG] ] ],
                 couplings = {(0,0,2):C.UVGC_128_4,(0,1,0):C.UVGC_151_24,(0,1,1):C.UVGC_151_25,(0,1,3):C.UVGC_151_26,(0,1,4):C.UVGC_151_27,(0,1,2):C.UVGC_151_28,(0,2,0):C.UVGC_151_24,(0,2,1):C.UVGC_151_25,(0,2,3):C.UVGC_151_26,(0,2,4):C.UVGC_151_27,(0,2,2):C.UVGC_151_28})

V_242 = CTVertex(name = 'V_242',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.t, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV1, L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.b] ], [ [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.t] ] ],
                 couplings = {(0,0,4):C.UVGC_128_4,(0,1,0):C.UVGC_151_24,(0,1,1):C.UVGC_151_25,(0,1,2):C.UVGC_151_26,(0,1,3):C.UVGC_151_27,(0,1,4):C.UVGC_202_96,(0,2,0):C.UVGC_151_24,(0,2,1):C.UVGC_151_25,(0,2,2):C.UVGC_151_26,(0,2,3):C.UVGC_151_27,(0,2,4):C.UVGC_202_96})

V_243 = CTVertex(name = 'V_243',
                 type = 'UV',
                 particles = [ P.d__tilde__, P.d, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV1, L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.b] ], [ [P.c], [P.d], [P.s], [P.u] ], [ [P.d, P.g] ], [ [P.g] ], [ [P.ghG] ] ],
                 couplings = {(0,0,2):C.UVGC_128_4,(0,1,0):C.UVGC_151_24,(0,1,1):C.UVGC_151_25,(0,1,3):C.UVGC_151_26,(0,1,4):C.UVGC_151_27,(0,1,2):C.UVGC_151_28,(0,2,0):C.UVGC_151_24,(0,2,1):C.UVGC_151_25,(0,2,3):C.UVGC_151_26,(0,2,4):C.UVGC_151_27,(0,2,2):C.UVGC_151_28})

V_244 = CTVertex(name = 'V_244',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.s, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV1, L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.b] ], [ [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.s] ] ],
                 couplings = {(0,0,4):C.UVGC_128_4,(0,1,0):C.UVGC_151_24,(0,1,1):C.UVGC_151_25,(0,1,2):C.UVGC_151_26,(0,1,3):C.UVGC_151_27,(0,1,4):C.UVGC_151_28,(0,2,0):C.UVGC_151_24,(0,2,1):C.UVGC_151_25,(0,2,2):C.UVGC_151_26,(0,2,3):C.UVGC_151_27,(0,2,4):C.UVGC_151_28})

V_245 = CTVertex(name = 'V_245',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.b, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV1, L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.b] ], [ [P.b, P.g] ], [ [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ] ],
                 couplings = {(0,0,1):C.UVGC_128_4,(0,1,0):C.UVGC_151_24,(0,1,2):C.UVGC_151_25,(0,1,3):C.UVGC_151_26,(0,1,4):C.UVGC_151_27,(0,1,1):C.UVGC_173_35,(0,2,0):C.UVGC_151_24,(0,2,2):C.UVGC_151_25,(0,2,3):C.UVGC_151_26,(0,2,4):C.UVGC_151_27,(0,2,1):C.UVGC_173_35})

V_246 = CTVertex(name = 'V_246',
                 type = 'UV',
                 particles = [ P.d__tilde__, P.u, P.W__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.d, P.g], [P.g, P.u] ], [ [P.d, P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_167_29,(0,0,1):C.UVGC_167_30})

V_247 = CTVertex(name = 'V_247',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.c, P.W__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.c, P.g], [P.g, P.s] ], [ [P.c, P.g, P.s] ] ],
                 couplings = {(0,0,0):C.UVGC_167_29,(0,0,1):C.UVGC_167_30})

V_248 = CTVertex(name = 'V_248',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.t, P.W__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.b, P.g] ], [ [P.b, P.g, P.t] ], [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.UVGC_204_98,(0,0,2):C.UVGC_204_99,(0,0,1):C.UVGC_167_30})

V_249 = CTVertex(name = 'V_249',
                 type = 'UV',
                 particles = [ P.u__tilde__, P.d, P.W__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.d, P.g], [P.g, P.u] ], [ [P.d, P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_167_29,(0,0,1):C.UVGC_167_30})

V_250 = CTVertex(name = 'V_250',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.s, P.W__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.c, P.g], [P.g, P.s] ], [ [P.c, P.g, P.s] ] ],
                 couplings = {(0,0,0):C.UVGC_167_29,(0,0,1):C.UVGC_167_30})

V_251 = CTVertex(name = 'V_251',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.b, P.W__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.b, P.g] ], [ [P.b, P.g, P.t] ], [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.UVGC_204_98,(0,0,2):C.UVGC_204_99,(0,0,1):C.UVGC_167_30})

V_252 = CTVertex(name = 'V_252',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.t, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.UVGC_207_106,(0,1,0):C.UVGC_208_107})

V_253 = CTVertex(name = 'V_253',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.b, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.b, P.g] ] ],
                 couplings = {(0,0,0):C.UVGC_175_37,(0,1,0):C.UVGC_176_38})

V_254 = CTVertex(name = 'V_254',
                 type = 'UV',
                 particles = [ P.u__tilde__, P.u ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF1, L.FF3, L.FF6 ],
                 loop_particles = [ [ [P.g, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_149_23,(0,1,0):C.UVGC_129_5,(0,2,0):C.UVGC_129_5})

V_255 = CTVertex(name = 'V_255',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.c ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF1, L.FF3, L.FF6 ],
                 loop_particles = [ [ [P.c, P.g] ] ],
                 couplings = {(0,0,0):C.UVGC_149_23,(0,1,0):C.UVGC_129_5,(0,2,0):C.UVGC_129_5})

V_256 = CTVertex(name = 'V_256',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.t ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF2, L.FF3, L.FF4, L.FF6 ],
                 loop_particles = [ [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.UVGC_203_97,(0,2,0):C.UVGC_203_97,(0,1,0):C.UVGC_200_94,(0,3,0):C.UVGC_200_94})

V_257 = CTVertex(name = 'V_257',
                 type = 'UV',
                 particles = [ P.d__tilde__, P.d ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF1, L.FF3, L.FF6 ],
                 loop_particles = [ [ [P.d, P.g] ] ],
                 couplings = {(0,0,0):C.UVGC_149_23,(0,1,0):C.UVGC_129_5,(0,2,0):C.UVGC_129_5})

V_258 = CTVertex(name = 'V_258',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.s ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF1, L.FF3, L.FF6 ],
                 loop_particles = [ [ [P.g, P.s] ] ],
                 couplings = {(0,0,0):C.UVGC_149_23,(0,1,0):C.UVGC_129_5,(0,2,0):C.UVGC_129_5})

V_259 = CTVertex(name = 'V_259',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.b ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF5, L.FF7 ],
                 loop_particles = [ [ [P.b, P.g] ] ],
                 couplings = {(0,0,0):C.UVGC_174_36,(0,1,0):C.UVGC_171_33})

V_260 = CTVertex(name = 'V_260',
                 type = 'UV',
                 particles = [ P.tp__tilde__, P.tp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF5, L.FF7 ],
                 loop_particles = [ [ [P.g, P.tp] ] ],
                 couplings = {(0,0,0):C.UVGC_233_181,(0,1,0):C.UVGC_222_154})

V_261 = CTVertex(name = 'V_261',
                 type = 'UV',
                 particles = [ P.bp__tilde__, P.bp ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF5, L.FF7 ],
                 loop_particles = [ [ [P.bp, P.g] ] ],
                 couplings = {(0,0,0):C.UVGC_189_63,(0,1,0):C.UVGC_180_42})

V_262 = CTVertex(name = 'V_262',
                 type = 'UV',
                 particles = [ P.g, P.g ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VV1, L.VV5 ],
                 loop_particles = [ [ [P.b] ], [ [P.bp] ], [ [P.g] ], [ [P.ghG] ], [ [P.t] ], [ [P.tp] ] ],
                 couplings = {(0,1,0):C.UVGC_214_114,(0,1,1):C.UVGC_214_115,(0,1,4):C.UVGC_214_116,(0,1,5):C.UVGC_214_117,(0,0,2):C.UVGC_139_9,(0,0,3):C.UVGC_139_10})

